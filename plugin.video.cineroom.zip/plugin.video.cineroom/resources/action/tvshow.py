import sys
import urllib.parse
import xbmcgui
import xbmcplugin
from resources.lib.utils import get_all_videos
import urllib.request
import threading
from urllib.parse import urlencode, parse_qsl
import json
from resources.action.favorites import load_favorites

HANDLE = int(sys.argv[1])
URL = sys.argv[0]

def get_url(**kwargs):
    """
    Cria uma URL para chamar o plugin recursivamente a partir dos argumentos fornecidos.
    """
    return '{}?{}'.format(URL, urlencode(kwargs))

GENRES_SERIES = [
    {'name': 'Ação', 'key': 'Ação'},
    {'name': 'Animação', 'key': 'Animação'},
    {'name': 'Aventura', 'key': 'Aventura'}, 
    {'name': 'Cinema TV', 'key': 'Cinema TV'},
    {'name': 'Comédia', 'key': 'Comédia'},
    {'name': 'Crime', 'key': 'Crime'},
    {'name': 'Documentário', 'key': 'Documentário'},
    {'name': 'Drama', 'key': 'Drama'},
    {'name': 'Fantasia', 'key': 'Fantasia'}, 
    {'name': 'Faroeste', 'key': 'Faroeste'},
    {'name': 'Ficção Cientifica', 'key': 'Ficção Cientifica'},
    {'name': 'Família', 'key': 'Família'},
    {'name': 'Guerra', 'key': 'Guerra'},
    {'name': 'História', 'key': 'História'},
    {'name': 'Mistério', 'key': 'Mistério'}, 
    {'name': 'Música', 'key': 'Música'},
    {'name': 'Romance', 'key': 'Romance'},
    {'name': 'Terror', 'key': 'Terror'},
    {'name': 'Thriller', 'key': 'Thriller'}
    # Adicione mais gêneros conforme necessário
]

def list_series_genres():
    """
    Lista os gêneros de séries pré-definidos.
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Gêneros de Séries')
    xbmcplugin.setContent(HANDLE, "genres")

    for genre in GENRES_SERIES:
        list_item = xbmcgui.ListItem(label=genre['name'])
        list_item.setInfo('video', {'title': genre['name']})
        
        # Gera a URL para listar séries do gênero específico
        url = get_url(action='list_series_by_genre', genre=genre['key'])
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    

def list_series_by_genre(genre):
    """
    Lista as séries de um determinado gênero.
    """
    xbmcplugin.setPluginCategory(HANDLE, f'Séries - {genre}')
    xbmcplugin.setContent(HANDLE, 'tvshows')

    series = get_all_videos()  # Ou use get_series() se for a função correta
    if not series:
        xbmcgui.Dialog().ok("Erro", "Nenhuma série encontrada.")
        return

    # Lista para armazenar as séries filtradas
    filtered_series = []
    seen_titles = set()  # Conjunto para evitar duplicatas com base no título

    for serie in series:
        if (
            serie.get('type') == 'tvshow' and  # Garante que é uma série
            genre in serie.get('genres', []) and  # Verifica se o gênero está presente
            serie.get('title') not in seen_titles  # Evita séries duplicadas pelo título
        ):
            seen_titles.add(serie['title'])
            filtered_series.append(serie)

    # Verifica se há séries filtradas
    if not filtered_series:
        xbmcgui.Dialog().ok("Aviso", f"Nenhuma série encontrada para o gênero {genre}.")
        return

    # Exibe as séries filtradas
    for serie in filtered_series:
        list_item = xbmcgui.ListItem(label=serie['title'])
        list_item.setArt({'poster': serie['poster'], 'fanart': serie['backdrop']})
        list_item.setInfo('video', {
            'title': serie['title'],
            'plot': serie.get('synopsis', ''),
            'rating': serie.get('rating', 0),
            'year': serie.get('year', 0),
            'studio': ', '.join(serie.get('studio', [])),
            'genre': ', '.join(serie.get('genres', [])),
            'sinopse': serie.get("synopsis", serie.get("sinopse", "Sem sinopse disponível")),  
            "aired": serie.get("premiered", "Ano não disponível"),                        
            'mediatype': 'tvshow'
        })

        # Gera a URL para listar temporadas da série
        url = get_url(action='list_seasons', serie=json.dumps(serie))
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    # Adiciona métodos de ordenação
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)

    xbmcplugin.endOfDirectory(HANDLE)
    
    
def list_series_studios():
    """
    Lista os estúdios de séries disponíveis (lista pré-definida).
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Estúdios de Séries')
    xbmcplugin.setContent(HANDLE, "genres")

    # Lista de estúdios pré-definida
    STUDIOS = [
        "Netflix",
        "HBO",
        "HBO Max",
        "Amazon",
        "Disney+",
        "Apple TV+",
        "Paramount+",
        "Hulu",
        "Globoplay",
        "Crunchyroll",
        "Disney Channel",
        "Cartoon Network",
        "Outros"
    ]

    # Exibe os estúdios na interface
    for studio in STUDIOS:
        list_item = xbmcgui.ListItem(label=studio)
        list_item.setInfo('video', {'title': studio})
        
        # Gera a URL para listar séries do estúdio específico
        url = get_url(action='list_series_by_studio', studio=studio)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def list_series_by_studio(studio):
    """
    Lista as séries de um determinado estúdio.
    """
    xbmcplugin.setPluginCategory(HANDLE, f'Séries - {studio}')
    xbmcplugin.setContent(HANDLE, 'tvshows')

    # Obtém todos os vídeos
    series = get_all_videos()
    if not series:
        xbmcgui.Dialog().ok("Erro", "Nenhuma série encontrada.")
        return

    # Filtra as séries do estúdio selecionado
    filtered_series = []
    for serie in series:
        if (
            serie.get('type') == 'tvshow' and  # Garante que é uma série
            isinstance(serie.get('studio'), list) and  # Verifica se 'studio' é uma lista
            studio in serie['studio']  # Verifica se o estúdio está na lista
        ):
            filtered_series.append(serie)

    # Verifica se há séries filtradas
    if not filtered_series:
        xbmcgui.Dialog().ok("Aviso", f"Nenhuma série encontrada para o estúdio {studio}.")
        return

    # Exibe as séries filtradas
    for serie in filtered_series:
        list_item = xbmcgui.ListItem(label=serie['title'])
        list_item.setArt({'poster': serie['poster'], 'fanart': serie['backdrop']})
        list_item.setInfo('video', {
            'title': serie['title'],
            'plot': serie.get('synopsis', ''),
            'rating': serie.get('rating', 0),
            'year': serie.get('year', 0),
            'studio': ', '.join(serie.get('studio', [])),  # Junta os estúdios em uma string
            'genre': ', '.join(serie.get('genres', [])),
            'sinopse': serie.get("synopsis", serie.get("sinopse", "Sem sinopse disponível")),  
            "aired": serie.get("premiered", "Ano não disponível"),            
            'mediatype': 'tvshow'
        })

        # Gera a URL para listar temporadas da série
        url = get_url(action='list_seasons', serie=json.dumps(serie))
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    # Adiciona métodos de ordenação
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)

    xbmcplugin.endOfDirectory(HANDLE)
    
def list_series_by_rating(page=1, items_per_page=100):
    """
    Lista as séries ordenadas por avaliação (rating) em ordem decrescente, com paginação.
    :param page: Número da página atual (deve ser um inteiro).
    :param items_per_page: Número de itens por página (deve ser um inteiro).
    """
    # Converte `page` e `items_per_page` para inteiros
    try:
        page = int(page)
        items_per_page = int(items_per_page)
    except (ValueError, TypeError):
        page = 1  # Valor padrão em caso de erro
        items_per_page = 50  # Valor padrão em caso de erro

    # Obtém todos os vídeos (séries e filmes)
    videos = get_all_videos()
    if not videos:
        xbmcgui.Dialog().ok("Erro", "Nenhum vídeo encontrado.")
        return

    # Filtra apenas as séries (type == 'tvshow')
    series = [video for video in videos if video.get('type') == 'tvshow']

    # Garante que todos os ratings sejam números válidos (substitui None ou valores inválidos por 0)
    for serie in series:
        serie['rating'] = float(serie.get('rating', 0))

    # Ordena as séries por rating (decrescente)
    series.sort(key=lambda x: x['rating'], reverse=True)

    # Verifica se há séries filtradas
    if not series:
        xbmcgui.Dialog().ok("Aviso", "Nenhuma série encontrada.")
        return

    # Configura a categoria e o conteúdo do plugin
    xbmcplugin.setPluginCategory(HANDLE, 'Melhor Avaliação')
    xbmcplugin.setContent(HANDLE, 'tvshows')

    # Calcula o índice inicial e final para a página atual
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page
    paginated_series = series[start_index:end_index]

    # Exibe as séries ordenadas por rating
    for serie in paginated_series:
        list_item = xbmcgui.ListItem(label=serie['title'])
        list_item.setArt({'poster': serie['poster'], 'fanart': serie['backdrop']})
        
        # Define as informações da série, incluindo o rating
        list_item.setInfo('video', {
            'title': serie['title'],
            'plot': serie.get('synopsis', ''),
            'rating': serie['rating'],  # Passa o rating para o ListItem
            'year': serie.get('year', 0),
            'studio': ', '.join(serie.get('studio', [])),
            'genre': ', '.join(serie.get('genres', [])),
            'sinopse': serie.get("synopsis", serie.get("sinopse", "Sem sinopse disponível")),  
            "aired": serie.get("premiered", "Ano não disponível"),            
            'mediatype': 'tvshow'
        })

        # Gera a URL para listar temporadas da série
        url = get_url(action='list_seasons', serie=json.dumps(serie))

        # Adiciona menu de contexto para favoritos
        favorites = load_favorites()
        if any(fav['title'] == serie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(serie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(serie))})')
            ])

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    # Adiciona controles de paginação (anterior/próxima página)
    if start_index > 0:
        # Botão "Página Anterior"
        prev_page_item = xbmcgui.ListItem(label="<< Página Anterior")
        prev_page_url = get_url(action='list_series_by_rating', page=page - 1, items_per_page=items_per_page)
        xbmcplugin.addDirectoryItem(HANDLE, prev_page_url, prev_page_item, isFolder=True)

    if end_index < len(series):
        # Botão "Próxima Página"
        next_page_item = xbmcgui.ListItem(label="Próxima Página >>")
        next_page_url = get_url(action='list_series_by_rating', page=page + 1, items_per_page=items_per_page)
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, isFolder=True)

    # Adiciona métodos de ordenação
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)
    
def list_series_by_specific_year(year):
    """
    Filtra e lista as séries de um ano específico.
    :param year: O ano para filtrar as séries (int).
    """
    # Define o título da categoria
    title = f"Séries de {year}"

    # Obtém todos os vídeos (séries e filmes)
    videos = get_all_videos()  # Ou use get_series() se for a função correta

    # Filtra as séries pelo ano especificado
    filtered_series = [
        video for video in videos
        if video.get('type') == 'tvshow' and video.get('year') == year
    ]

    # Verifica se há séries filtradas
    if not filtered_series:
        xbmcgui.Dialog().ok("Aviso", f"Nenhuma série encontrada para {title}.")
        return

    # Configura a categoria e o conteúdo do plugin
    xbmcplugin.setPluginCategory(HANDLE, title)
    xbmcplugin.setContent(HANDLE, 'tvshows')

    # Adiciona as séries filtradas à lista
    for serie in filtered_series:
        list_item = xbmcgui.ListItem(label=serie['title'])
        list_item.setArt({'poster': serie['poster'], 'fanart': serie['backdrop']})
        list_item.setInfo('video', {
            'title': serie['title'],
            'plot': serie.get('synopsis', ''),
            'rating': serie.get('rating', 0),
            'year': serie.get('year', 0),
            'studio': ', '.join(serie.get('studio', [])),
            'genre': ', '.join(serie.get('genres', [])),
            "aired": serie.get("premiered", "Ano não disponível"),
            'sinopse': serie.get("synopsis", serie.get("sinopse", "Sem sinopse disponível")),   
            'mediatype': 'tvshow'
        })

        # Gera a URL para listar temporadas da série
        url = get_url(action='list_seasons', serie=json.dumps(serie))

        # Adiciona menu de contexto para favoritos
        favorites = load_favorites()
        if any(fav['title'] == serie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(serie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(serie))})')
            ])

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    # Adiciona métodos de ordenação
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)
    
def list_series_by_popularity(page=1, items_per_page=100):
    """
    Lista as séries ordenadas por popularidade em ordem decrescente, com paginação.
    :param page: Número da página atual (deve ser um inteiro).
    :param items_per_page: Número de itens por página (deve ser um inteiro).
    """
    # Converte `page` e `items_per_page` para inteiros
    try:
        page = int(page)
        items_per_page = int(items_per_page)
    except (ValueError, TypeError):
        page = 1  # Valor padrão em caso de erro
        items_per_page = 50  # Valor padrão em caso de erro

    # Obtém todos os vídeos
    videos = get_all_videos()  # Ou use get_series() se for a função correta

    # Filtra apenas séries
    series = [video for video in videos if video.get('type') == 'tvshow']

    # Remove séries duplicadas com base no tmdb_id
    unique_series = []
    seen_ids = set()  # Conjunto para armazenar IDs já vistos
    for serie in series:
        tmdb_id = serie.get('tmdb_id')
        if tmdb_id and tmdb_id not in seen_ids:
            unique_series.append(serie)
            seen_ids.add(tmdb_id)

    # Ordena as séries por popularidade em ordem decrescente
    unique_series.sort(key=lambda x: x.get('popularity', 0), reverse=True)

    # Verifica se há séries
    if not unique_series:
        xbmcgui.Dialog().ok("Aviso", "Nenhuma série encontrada.")
        return

    # Configura a categoria e o conteúdo do plugin
    xbmcplugin.setPluginCategory(HANDLE, 'Séries Mais Populares')
    xbmcplugin.setContent(HANDLE, 'tvshows')

    # Calcula o índice inicial e final para a página atual
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page
    paginated_series = unique_series[start_index:end_index]

    # Adiciona as séries da página atual à lista
    for serie in paginated_series:
        list_item = xbmcgui.ListItem(label=serie['title'])
        list_item.setArt({'poster': serie['poster'], 'fanart': serie['backdrop']})
        list_item.setInfo('video', {
            'title': serie['title'],
            'plot': serie.get('synopsis', ''),
            'rating': serie.get('rating', 0),
            'year': serie.get('year', 0),
            'aired': serie.get("premiered", "Ano não disponível"),
            'studio': ', '.join(serie.get('studio', [])),
            'sinopse': serie.get("synopsis", serie.get("sinopse", "Sem sinopse disponível")),          
            'genre': ', '.join(serie.get('genres', [])),
            'mediatype': 'tvshow'
        })

        # Gera a URL para listar temporadas da série
        url = get_url(action='list_seasons', serie=json.dumps(serie))

        # Adiciona menu de contexto para favoritos
        favorites = load_favorites()
        if any(fav['title'] == serie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(serie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(serie))})')
            ])

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    # Adiciona controles de paginação (anterior/próxima página)
    if start_index > 0:
        # Botão "Página Anterior"
        prev_page_item = xbmcgui.ListItem(label="<< Página Anterior")
        prev_page_url = get_url(action='list_series_by_popularity', page=page - 1, items_per_page=items_per_page)
        xbmcplugin.addDirectoryItem(HANDLE, prev_page_url, prev_page_item, isFolder=True)

    if end_index < len(unique_series):
        # Botão "Próxima Página"
        next_page_item = xbmcgui.ListItem(label="Próxima Página >>")
        next_page_url = get_url(action='list_series_by_popularity', page=page + 1, items_per_page=items_per_page)
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, isFolder=True)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)
    
def list_anime_series():
    """
    Lista as séries que têm "Anime" no campo de gêneros.
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Animes')
    xbmcplugin.setContent(HANDLE, 'tvshows')

    # Obtém todos os vídeos (séries e filmes)
    videos = get_all_videos()
    if not videos:
        xbmcgui.Dialog().ok("Erro", "Nenhum vídeo encontrado.")
        return

    # Filtra apenas as séries que têm "Anime" no campo de gêneros
    anime_series = [
        video for video in videos
        if video.get('type') == 'tvshow' and 'Anime' in video.get('genres', [])
    ]

    # Verifica se há séries filtradas
    if not anime_series:
        xbmcgui.Dialog().ok("Aviso", "Nenhuma série de anime encontrada.")
        return

    # Exibe as séries de anime
    for serie in anime_series:
        list_item = xbmcgui.ListItem(label=serie['title'])
        list_item.setArt({'poster': serie['poster'], 'fanart': serie['backdrop']})
        list_item.setInfo('video', {
            'title': serie['title'],
            'plot': serie.get('synopsis', ''),
            'rating': serie.get('rating', 0),
            'year': serie.get('year', 0),
            'aired': serie.get("premiered", "Ano não disponível"),
            'sinopse': serie.get("synopsis", serie.get("sinopse", "Sem sinopse disponível")), 
            'studio': ', '.join(serie.get('studio', [])),
            'genre': ', '.join(serie.get('genres', [])),
            'mediatype': 'tvshow'
        })

        # Gera a URL para listar temporadas da série
        url = get_url(action='list_seasons', serie=json.dumps(serie))

        # Adiciona menu de contexto para favoritos
        favorites = load_favorites()
        if any(fav['title'] == serie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(serie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(serie))})')
            ])

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    # Adiciona métodos de ordenação
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE) 
    
def list_novela_series():
    """
    Lista as séries que têm "Novela" no campo de gêneros.
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Novelas')
    xbmcplugin.setContent(HANDLE, 'tvshows')

    # Obtém todos os vídeos (séries e filmes)
    videos = get_all_videos()
    if not videos:
        xbmcgui.Dialog().ok("Erro", "Nenhum vídeo encontrado.")
        return

    # Filtra apenas as séries que têm "Novela" no campo de gêneros
    novela_series = [
        video for video in videos
        if video.get('type') == 'tvshow' and 'Novela' in video.get('genres', [])
    ]

    # Verifica se há séries filtradas
    if not novela_series:
        xbmcgui.Dialog().ok("Aviso", "Nenhuma novela encontrada.")
        return

    # Exibe as séries de novela
    for serie in novela_series:
        list_item = xbmcgui.ListItem(label=serie['title'])
        list_item.setArt({'poster': serie['poster'], 'fanart': serie['backdrop']})
        list_item.setInfo('video', {
            'title': serie['title'],
            'plot': serie.get('synopsis', ''),
            'rating': serie.get('rating', 0),
            'year': serie.get('year', 0),
            'aired': serie.get("premiered", "Ano não disponível"),
            'sinopse': serie.get("synopsis", serie.get("sinopse", "Sem sinopse disponível")),
            'studio': ', '.join(serie.get('studio', [])),
            'genre': ', '.join(serie.get('genres', [])),
            'mediatype': 'tvshow'
        })

        # Gera a URL para listar temporadas da novela
        url = get_url(action='list_seasons', serie=json.dumps(serie))

        # Adiciona menu de contexto para favoritos
        favorites = load_favorites()
        if any(fav['title'] == serie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(serie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(serie))})')
            ])

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    # Adiciona métodos de ordenação
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)
    
 
def list_recently_added_series():
    """
    Lista as séries adicionadas recentemente, ordenadas por data de adição.
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Séries Adicionadas Recentemente')
    xbmcplugin.setContent(HANDLE, 'tvshows')

    # Obtém todos os vídeos (séries e filmes)
    videos = get_all_videos()
    if not videos:
        xbmcgui.Dialog().ok("Erro", "Nenhum vídeo encontrado.")
        return

    # Filtra apenas as séries que têm a tag 'date_added' e que não sejam None
    series_with_date = [
        video for video in videos
        if video.get('type') == 'tvshow' and video.get('date_added') is not None
    ]

    # Remove duplicados com base no tmdb_id (ou outro identificador único)
    unique_series = []
    seen_ids = set()  # Conjunto para armazenar IDs já vistos
    for serie in series_with_date:
        tmdb_id = serie.get('tmdb_id')
        if tmdb_id and tmdb_id not in seen_ids:
            unique_series.append(serie)
            seen_ids.add(tmdb_id)

    # Ordena as séries por data de adição (mais recentes primeiro)
    try:
        unique_series.sort(key=lambda x: x['date_added'], reverse=True)
    except KeyError as e:
        xbmc.log(f"Erro ao ordenar séries: Campo 'date_added' ausente em uma das séries. Detalhes: {e}", xbmc.LOGERROR)
        return
    except Exception as e:
        xbmc.log(f"Erro ao ordenar séries: {e}", xbmc.LOGERROR)
        return

    # Verifica se há séries
    if not unique_series:
        xbmcgui.Dialog().ok("Aviso", "Nenhuma série adicionada recentemente encontrada.")
        return

    # Exibe as séries adicionadas recentemente
    for serie in unique_series:
        list_item = xbmcgui.ListItem(label=serie['title'])
        list_item.setArt({'poster': serie['poster'], 'fanart': serie['backdrop']})
        list_item.setInfo('video', {
            'title': serie['title'],
            'plot': serie.get('synopsis', ''),
            'rating': serie.get('rating', 0),
            'year': serie.get('year', 0),
            'aired': serie.get("premiered", "Ano não disponível"),
            'sinopse': serie.get("synopsis", serie.get("sinopse", "Sem sinopse disponível")),
            'studio': ', '.join(serie.get('studio', [])),
            'genre': ', '.join(serie.get('genres', [])),
            'dateadded': serie.get('date_added', ''),
            'mediatype': 'tvshow'
        })

        # Gera a URL para listar temporadas da série
        url = get_url(action='list_seasons', serie=json.dumps(serie))

        # Adiciona menu de contexto para favoritos
        favorites = load_favorites()
        if any(fav['title'] == serie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(serie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(serie))})')
            ])

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    # Adiciona métodos de ordenação
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATEADDED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)    
    
def list_kids_series():
    """
    Lista as séries classificadas como infantis (Kids).
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Infantil')
    xbmcplugin.setContent(HANDLE, 'tvshows')

    # Obtém todos os vídeos (séries e filmes)
    videos = get_all_videos()
    if not videos:
        xbmcgui.Dialog().ok("Erro", "Nenhum vídeo encontrado.")
        return

    # Filtra apenas as séries classificadas como infantis
    kids_series = [
        video for video in videos
        if video.get('type') == 'tvshow' and video.get('classification') in ['L', 'Kids']
    ]

    # Remove duplicados com base no tmdb_id (ou outro identificador único)
    unique_series = []
    seen_ids = set()  # Conjunto para armazenar IDs já vistos
    for serie in kids_series:
        tmdb_id = serie.get('tmdb_id')
        if tmdb_id and tmdb_id not in seen_ids:
            unique_series.append(serie)
            seen_ids.add(tmdb_id)

    # Verifica se há séries infantis
    if not unique_series:
        xbmcgui.Dialog().ok("Aviso", "Nenhuma série infantil encontrada.")
        return

    # Exibe as séries infantis
    for serie in unique_series:
        list_item = xbmcgui.ListItem(label=serie['title'])
        list_item.setArt({'poster': serie['poster'], 'fanart': serie['backdrop']})
        list_item.setInfo('video', {
            'title': serie['title'],
            'plot': serie.get('synopsis', ''),
            'rating': serie.get('rating', 0),
            'year': serie.get('year', 0),
            'aired': serie.get("premiered", "Ano não disponível"),
            'sinopse': serie.get("synopsis", serie.get("sinopse", "Sem sinopse disponível")),
            'studio': ', '.join(serie.get('studio', [])),
            'genre': ', '.join(serie.get('genres', [])),
            'mediatype': 'tvshow'
        })

        # Gera a URL para listar temporadas da série
        url = get_url(action='list_seasons', serie=json.dumps(serie))

        # Adiciona menu de contexto para favoritos
        favorites = load_favorites()
        if any(fav['title'] == serie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(serie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(serie))})')
            ])

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    # Adiciona métodos de ordenação
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)    
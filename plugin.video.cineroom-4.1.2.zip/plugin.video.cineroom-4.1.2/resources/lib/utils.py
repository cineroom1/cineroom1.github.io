import urllib.request
import json

URL = "plugin://plugin.video.cineroom"


def get_json_data(url):
    """Carrega dados JSON de uma URL sem usar requests."""
    try:
        with urllib.request.urlopen(url) as response:
            return json.load(response)  # Seu formato já usa json.load(response)
    except Exception as e:
        xbmcgui.Dialog().ok("Erro", f"Não foi possível carregar os dados.\n{str(e)}")
        return None



def get_url(**kwargs):
    """
    Cria uma URL para chamar o plugin de forma recursiva com os argumentos fornecidos.

    :param kwargs: Argumentos no formato chave=valor
    :return: URL para chamada do plugin
    """
    from urllib.parse import urlencode
    return f"{URL}?{urlencode(kwargs)}"
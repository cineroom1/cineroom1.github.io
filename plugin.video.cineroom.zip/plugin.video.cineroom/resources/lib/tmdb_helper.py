import urllib.request
import json

TMDB_API_KEY = "f0b9cd2de131c900f5bb03a0a5776342"

def get_movie_details(tmdb_id):
    """Busca os detalhes do filme no TMDb usando o ID."""
    url = f"https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={TMDB_API_KEY}&language=pt-BR"
    
    try:
        with urllib.request.urlopen(url) as response:
            data = response.read().decode("utf-8")
            movie = json.loads(data)

            return {
                "title": movie.get("title", "Título Desconhecido"),
                "poster": f"https://image.tmdb.org/t/p/w500{movie.get('poster_path', '')}" if movie.get("poster_path") else "",
                "backdrop": f"https://image.tmdb.org/t/p/w1280{movie.get('backdrop_path', '')}" if movie.get("backdrop_path") else "",
                "sinopse": movie.get("overview", "Sem sinopse disponível"),
                "studio": movie["production_companies"][0]["name"] if movie.get("production_companies") else "Desconhecido",
                "year": movie.get("release_date", "0000")[:4],
                "rating": movie.get("vote_average", 0),
                "genres": ", ".join([genre["name"] for genre in movie.get("genres", [])])
            }

    except Exception as e:
        print(f"Erro ao buscar filme no TMDb: {e}")
        return {}

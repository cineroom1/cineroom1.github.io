import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import json
from resources.lib.utils import get_all_videos
import urllib.request
from resources.action.video_listing import create_video_item
from resources.action.favorites import load_favorites

HANDLE = int(sys.argv[1])

# Lista de estúdios predefinidos
ESTUDIOS_FILMES = [
    "Universal Pictures", "Warner Bros.", "Paramount Pictures", "Sony Pictures",
    "20th Century Studios", "Walt Disney Pictures", "Pixar", "DreamWorks Animation",
    "Columbia Pictures", "Legendary Pictures", "DC Comics", "A24", "Marvel Studios",
    "MGM", "Lionsgate", "New Line Cinema", "Original Film", "Fox 2000 Pictures",
    "Sunday Night Productions", "Blue Sky Studios", "Lucasfilm Ltd.",
    "Blumhouse Productions", "Skydance Media", "Studio Ghibli"
]

GENRES = [
    {'name': 'Ação', 'key': 'Ação'},
    {'name': 'Animação', 'key': 'Animação'},
    {'name': 'Aventura', 'key': 'Aventura'}, 
    {'name': 'Cinema TV', 'key': 'Cinema TV'},
    {'name': 'Comédia', 'key': 'Comédia'},
    {'name': 'Crime', 'key': 'Crime'},
    {'name': 'Documentário', 'key': 'Documentário'},
    {'name': 'Drama', 'key': 'Drama'},
    {'name': 'Fantasia', 'key': 'Fantasia'}, 
    {'name': 'Faroeste', 'key': 'Faroeste'},
    {'name': 'Ficção Científica', 'key': 'Ficção científica'},
    {'name': 'Família', 'key': 'Família'},
    {'name': 'Guerra', 'key': 'Guerra'},
    {'name': 'História', 'key': 'História'},
    {'name': 'Mistério', 'key': 'Mistério'}, 
    {'name': 'Música', 'key': 'Música'},
    {'name': 'Romance', 'key': 'Romance'},
    {'name': 'Terror', 'key': 'Terror'},
    {'name': 'Thriller', 'key': 'Thriller'}
]

# Lista de anos pré-programados (últimos 20 anos, por exemplo)
ANOS_FILMES = [str(year) for year in range(2024, 1939, -1)] 

def get_url(action, **kwargs):
    """
    Gera uma URL para chamar ações dentro do addon.
    """
    return f"{sys.argv[0]}?action={action}&{urllib.parse.urlencode(kwargs)}"

def filter_and_list_movies(criteria, value, title):
    """
    Filtra e lista os filmes com base em um critério (gênero ou estúdio).
    """
    xbmcplugin.setPluginCategory(HANDLE, f'Filmes - {title}')
    xbmcplugin.setContent(HANDLE, 'movies')

    movies = get_all_videos()  # Ou use get_movies() se for a função correta
    seen_movies = set()  # Conjunto para armazenar tmdb_id e evitar duplicatas
    filtered_movies = []

    for movie in movies:
        if (
            movie.get('type') == 'movie' and  # Garante que é um filme
            criteria(movie, value) and  # Verifica o critério (gênero ou estúdio)
            movie.get('tmdb_id') not in seen_movies  # Evita filmes duplicados
        ):
            seen_movies.add(movie['tmdb_id'])
            filtered_movies.append(movie)

    if not filtered_movies:
        xbmcgui.Dialog().ok("Aviso", f"Nenhum filme encontrado para {title}.")
        return

    for movie in filtered_movies:
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setArt({'poster': movie['poster'], 'fanart': movie['backdrop']})
        list_item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('synopsis', ''),
            'rating': movie.get('rating', 0),
            'year': movie.get('year', 0),
            'studio': ', '.join(movie.get('studio', [])),  # Exibe todos os estúdios
            'duration': movie.get("runtime", 0),
            'genre': ', '.join(movie.get('genres', [])),
            "aired": movie.get("premiered", "Ano não disponível"),
            'mediatype': 'movie'
        })

        url = get_url(action='play', video=','.join(movie['url'])) if 'url' in movie else ''
        list_item.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)

    xbmcplugin.endOfDirectory(HANDLE)

def list_movies_by_genre(genre):
    """
    Lista os filmes de um determinado gênero.
    """
    def genre_criteria(movie, value):
        return value in ', '.join(movie.get('genres', [])).split(', ')
    
    filter_and_list_movies(genre_criteria, genre, f'Gênero: {genre}')

def list_movies_by_studio(studio):
    """
    Lista os filmes de um determinado estúdio.
    """
    def studio_criteria(movie, value):
        # Remove espaços extras e converte para minúsculas
        value = value.strip().lower()
        studios = movie.get('studio', [])
        
        # Verifica se o estúdio está na lista de estúdios do filme
        return value in [s.strip().lower() for s in studios]
    
    # Filtra e lista os filmes
    filter_and_list_movies(studio_criteria, studio, f'Filmes do Estúdio: {studio}')

def list_categories(categories, category_type):
    """
    Lista categorias (gêneros ou estúdios) e gera URLs para listar os filmes correspondentes.
    """
    xbmcplugin.setPluginCategory(HANDLE, category_type)
    xbmcplugin.setContent(HANDLE, "genres")

    for category in categories:
        list_item = xbmcgui.ListItem(label=category['name'] if isinstance(category, dict) else category)
        list_item.setInfo('video', {'title': category['name'] if isinstance(category, dict) else category})
        
        # Gera a URL para listar filmes da categoria específica
        url = get_url(
            action=f'list_movies_by_{category_type.lower()}',
            genre=category['key'] if isinstance(category, dict) else category
        )
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def list_genres():
    """
    Lista os gêneros de filmes pré-definidos.
    """
    list_categories(GENRES, 'genre')

def list_studios():
    """
    Lista todos os estúdios pré-programados e permite que o usuário escolha um.
    """
    # Configura a categoria e o conteúdo do plugin
    xbmcplugin.setPluginCategory(HANDLE, 'Estúdios')
    xbmcplugin.setContent(HANDLE, 'studios')

    # Adiciona os estúdios pré-programados à lista
    for studio in ESTUDIOS_FILMES:
        list_item = xbmcgui.ListItem(label=studio)
        list_item.setInfo('video', {'title': studio})
        
        # Gera a URL para listar filmes do estúdio específico
        url = get_url(action='list_movies_by_studio', studio=studio)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)
    
def list_movies_by_year(year):
    """
    Lista os filmes de um determinado ano.
    """
    def year_criteria(movie, value):
        return movie.get('year', 0) == value  # Compara diretamente o ano do filme com o valor passado
    
    filter_and_list_movies(year_criteria, int(year), f'Ano: {year}')

def list_years():
    """
    Lista os anos pré-programados para filtrar os filmes.
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Anos')
    xbmcplugin.setContent(HANDLE, "years")

    for year in ANOS_FILMES:
        list_item = xbmcgui.ListItem(label=str(year))
        list_item.setInfo('video', {'title': str(year)})
        
        # Gera a URL para listar filmes do ano específico
        url = get_url(action='list_movies_by_year', year=year)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    
def filter_and_list_movies(criteria, value, title):
    """
    Filtra e lista os filmes com base em um critério (gênero, estúdio ou ano).
    """
    xbmcplugin.setPluginCategory(HANDLE, f'Filmes - {title}')
    xbmcplugin.setContent(HANDLE, 'movies')

    movies = get_all_videos()  # Ou use get_movies() se for a função correta
    seen_movies = set()  # Conjunto para armazenar tmdb_id e evitar duplicatas
    filtered_movies = []

    for movie in movies:
        if (
            movie.get('type') == 'movie' and  # Garante que é um filme
            criteria(movie, value) and  # Verifica o critério (gênero, estúdio ou ano)
            movie.get('tmdb_id') not in seen_movies  # Evita filmes duplicados
        ):
            seen_movies.add(movie['tmdb_id'])
            filtered_movies.append(movie)

    if not filtered_movies:
        xbmcgui.Dialog().ok("Aviso", f"Nenhum filme encontrado para {title}.")
        return

    for movie in filtered_movies:
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setArt({'poster': movie['poster'], 'fanart': movie['backdrop']})
        list_item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('synopsis', ''),
            'rating': movie.get('rating', 0),
            'year': movie.get('year', 0),
            'studio': ', '.join(movie.get('studio', [])),  # Exibe todos os estúdios
            'duration': movie.get("runtime", 0),
            'genre': ', '.join(movie.get('genres', [])),
            "aired": movie.get("premiered", "Ano não disponível"),
            'mediatype': 'movie'
        })

        url = get_url(action='play', video=','.join(movie['url'])) if 'url' in movie else ''
        list_item.setProperty("IsPlayable", "true")
        
        favorites = load_favorites()
        
        if any(fav['title'] == movie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(movie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(movie))})')
            ])
        
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    # Adiciona métodos de ordenação suportados pelo Kodi
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    xbmcplugin.endOfDirectory(HANDLE)
    
    
def list_movies_by_specific_year(year):
    """
    Filtra e lista os filmes de um ano específico.
    :param year: O ano para filtrar os filmes (int).
    """
    # Define o título da categoria
    title = f"Filmes de {year}"

    # Obtém todos os filmes
    movies = get_all_videos()  # Ou use get_movies() se for a função correta

    # Filtra os filmes pelo ano especificado
    filtered_movies = [
        movie for movie in movies
        if movie.get('type') == 'movie' and movie.get('year') == year
    ]

    # Verifica se há filmes filtrados
    if not filtered_movies:
        xbmcgui.Dialog().ok("Aviso", f"Nenhum filme encontrado para {title}.")
        return

    # Configura a categoria e o conteúdo do plugin
    xbmcplugin.setPluginCategory(HANDLE, title)
    xbmcplugin.setContent(HANDLE, 'movies')

    # Adiciona os filmes filtrados à lista
    for movie in filtered_movies:
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setArt({'poster': movie['poster'], 'fanart': movie['backdrop']})
        list_item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('synopsis', ''),
            'rating': movie.get('rating', 0),
            'year': movie.get('year', 0),
            'studio': movie.get('studio', ''),
            'duration': movie.get("runtime", 0),
            'genre': ', '.join(movie.get('genres', [])),
            "aired": movie.get("premiered", "Ano não disponível"),
            'mediatype': 'movie'
        })

        # Gera a URL para reprodução
        url = get_url(action='play', video=','.join(movie['url'])) if 'url' in movie else ''
        list_item.setProperty("IsPlayable", "true")
        
        favorites = load_favorites()
        
        if any(fav['title'] == movie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(movie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(movie))})')
            ])
        
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    # Adiciona métodos de ordenação
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)
    
def generate_url(action, **kwargs):
    return f"{sys.argv[0]}?action={action}&{urllib.parse.urlencode(kwargs)}"    
    
def list_movies_by_rating(page=1, items_per_page=100):
    """
    Lista os filmes ordenados por avaliação (nota) em ordem decrescente, com paginação.
    :param page: Número da página atual (deve ser um inteiro).
    :param items_per_page: Número de itens por página (deve ser um inteiro).
    """
    # Converte `page` e `items_per_page` para inteiros
    try:
        page = int(page)
        items_per_page = int(items_per_page)
    except (ValueError, TypeError):
        page = 1  # Valor padrão em caso de erro
        items_per_page = 100  # Valor padrão em caso de erro

    # Obtém todos os filmes
    movies = get_all_videos()  # Ou use get_movies() se for a função correta

    # Filtra apenas filmes
    movies = [movie for movie in movies if movie.get('type') == 'movie']

    # Remove filmes duplicados com base no tmdb_id
    unique_movies = []
    seen_ids = set()  # Conjunto para armazenar IDs já vistos
    for movie in movies:
        tmdb_id = movie.get('tmdb_id')
        if tmdb_id and tmdb_id not in seen_ids:
            unique_movies.append(movie)
            seen_ids.add(tmdb_id)

    # Ordena os filmes por avaliação (nota) em ordem decrescente
    unique_movies.sort(key=lambda x: x.get('rating', 0), reverse=True)

    # Verifica se há filmes
    if not unique_movies:
        xbmcgui.Dialog().ok("Aviso", f"Nenhum filme encontrado para {title}.")
        return

    # Configura a categoria e o conteúdo do plugin
    xbmcplugin.setPluginCategory(HANDLE, 'Melhor Avaliação')
    xbmcplugin.setContent(HANDLE, 'movies')

    # Calcula o índice inicial e final para a página atual
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page
    paginated_movies = unique_movies[start_index:end_index]

    # Adiciona os filmes da página atual à lista
    for movie in paginated_movies:
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setArt({'poster': movie['poster'], 'fanart': movie['backdrop']})
        list_item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('synopsis', ''),
            'rating': movie.get('rating', 0),
            'year': movie.get('year', 0),
            'studio': movie.get('studio', ''),
            'duration': movie.get("runtime", 0),
            'genre': ', '.join(movie.get('genres', [])),
            "aired": movie.get("premiered", "Ano não disponível"),
            'mediatype': 'movie'
        })

        # Gera a URL para reprodução
        url = get_url(action='play', video=','.join(movie['url'])) if 'url' in movie else ''
        list_item.setProperty("IsPlayable", "true")
        
        
        # Adiciona menu de contexto para favoritos
        favorites = load_favorites()
        
        if any(fav['title'] == movie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(movie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(movie))})')
            ])
        
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)


    # Adiciona controles de paginação (anterior/próxima página)
    if start_index > 0:
        # Botão "Página Anterior"
        prev_page_item = xbmcgui.ListItem(label="<< Página Anterior")
        prev_page_url = get_url(action='list_movies_by_rating', page=page - 1, items_per_page=items_per_page)
        xbmcplugin.addDirectoryItem(HANDLE, prev_page_url, prev_page_item, isFolder=True)

    if end_index < len(unique_movies):
        # Botão "Próxima Página"
        next_page_item = xbmcgui.ListItem(label="Próxima Página >>")
        next_page_url = get_url(action='list_movies_by_rating', page=page + 1, items_per_page=items_per_page)
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, isFolder=True)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)
    
def list_actors():
    """
    Lista todos os atores disponíveis com suas imagens e permite ao usuário escolher um para ver os filmes/séries correspondentes.
    """
    # Obtém todos os vídeos
    try:
        all_videos = get_all_videos()
    except Exception as e:
        xbmcgui.Dialog().ok("Erro", f"Erro ao obter vídeos: {str(e)}")
        return

    # Extrai todos os atores únicos com suas imagens
    actors = {}  # Dicionário para armazenar atores e suas imagens
    for video in all_videos:
        for actor in video.get("actors", []):  # Extrai atores do campo "actors"
            actor_name = actor.get('name', 'Desconhecido')
            actor_photo = actor.get('photo', '')  # Extrai a foto do ator
            if actor_name:  # Ignora atores sem nome
                # Se o ator já existe, mantém a primeira foto encontrada
                if actor_name not in actors:
                    actors[actor_name] = actor_photo

    # Verifica se há atores
    if not actors:
        xbmcgui.Dialog().ok("Aviso", "Nenhum ator encontrado.")
        return

    # Configura a categoria e o conteúdo do plugin
    xbmcplugin.setPluginCategory(HANDLE, 'Atores')
    xbmcplugin.setContent(HANDLE, 'videos')

    # Adiciona os atores à lista com suas imagens
    for actor_name, actor_photo in sorted(actors.items()):  # Ordena os atores alfabeticamente
        list_item = xbmcgui.ListItem(label=actor_name)
        list_item.setInfo('video', {'title': actor_name})

        # Define a imagem do ator como thumbnail
        if actor_photo:
            list_item.setArt({'thumb': actor_photo, 'icon': actor_photo})

        # Gera a URL para listar filmes/séries com o ator selecionado
        url = get_url(action='list_movies_by_actor', actor=actor_name)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies_by_actor(actor_name):
    """
    Lista os filmes/séries em que um ator específico participou.
    :param actor_name: Nome do ator a ser pesquisado.
    """
    # Obtém todos os vídeos
    try:
        all_videos = get_all_videos()
    except Exception as e:
        xbmcgui.Dialog().ok("Erro", f"Erro ao obter vídeos: {str(e)}")
        return

    # Filtra os vídeos em que o ator participou
    filtered_videos = []
    for video in all_videos:
        actors = video.get("actors", [])  # Extrai atores do campo "actors"
        if any(actor.get('name', '').lower() == actor_name.lower() for actor in actors):
            filtered_videos.append(video)

    # Verifica se há vídeos filtrados
    if not filtered_videos:
        xbmcgui.Dialog().ok("Resultado", f"Nenhum vídeo encontrado com o ator: {actor_name}")
        return

    # Configura a categoria e o conteúdo do plugin
    xbmcplugin.setPluginCategory(HANDLE, f'Filmes com: {actor_name}')
    xbmcplugin.setContent(HANDLE, 'movies')

    # Adiciona os vídeos filtrados à lista
    for video in filtered_videos:
        list_item, url, is_folder = create_video_item(video)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)
    
    
def list_movies_by_popularity(page=1, items_per_page=100):
    """
    Lista os filmes ordenados por popularidade em ordem decrescente, com paginação.
    :param page: Número da página atual (deve ser um inteiro).
    :param items_per_page: Número de itens por página (deve ser um inteiro).
    """
    # Converte `page` e `items_per_page` para inteiros
    try:
        page = int(page)
        items_per_page = int(items_per_page)
    except (ValueError, TypeError):
        page = 1  # Valor padrão em caso de erro
        items_per_page = 100  # Valor padrão em caso de erro

    # Obtém todos os filmes
    movies = get_all_videos()  # Ou use get_movies() se for a função correta

    # Filtra apenas filmes
    movies = [movie for movie in movies if movie.get('type') == 'movie']

    # Remove filmes duplicados com base no tmdb_id
    unique_movies = []
    seen_ids = set()  # Conjunto para armazenar IDs já vistos
    for movie in movies:
        tmdb_id = movie.get('tmdb_id')
        if tmdb_id and tmdb_id not in seen_ids:
            unique_movies.append(movie)
            seen_ids.add(tmdb_id)

    # Ordena os filmes por popularidade em ordem decrescente
    unique_movies.sort(key=lambda x: x.get('popularity', 0), reverse=True)

    # Verifica se há filmes
    if not unique_movies:
        xbmcgui.Dialog().ok("Aviso", "Nenhum filme encontrado.")
        return

    # Configura a categoria e o conteúdo do plugin
    xbmcplugin.setPluginCategory(HANDLE, 'Mais Populares')
    xbmcplugin.setContent(HANDLE, 'movies')

    # Calcula o índice inicial e final para a página atual
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page
    paginated_movies = unique_movies[start_index:end_index]

    # Adiciona os filmes da página atual à lista
    for movie in paginated_movies:
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setArt({'poster': movie['poster'], 'fanart': movie['backdrop']})
        list_item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('synopsis', ''),
            'rating': movie.get('rating', 0),
            'year': movie.get('year', 0),
            'studio': ', '.join(movie.get('studio', [])),
            'duration': movie.get("runtime", 0),
            'genre': ', '.join(movie.get('genres', [])),
            "aired": movie.get("premiered", "Ano não disponível"),
            'mediatype': 'movie'
        })

        # Gera a URL para reprodução
        url = get_url(action='play', video=','.join(movie['url'])) if 'url' in movie else ''
        list_item.setProperty("IsPlayable", "true")
        # Adiciona menu de contexto para favoritos
        favorites = load_favorites()
        
        if any(fav['title'] == movie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(movie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(movie))})')
            ])
        
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    # Adiciona controles de paginação (anterior/próxima página)
    if start_index > 0:
        # Botão "Página Anterior"
        prev_page_item = xbmcgui.ListItem(label="<< Página Anterior")
        prev_page_url = get_url(action='list_movies_by_popularity', page=page - 1, items_per_page=items_per_page)
        xbmcplugin.addDirectoryItem(HANDLE, prev_page_url, prev_page_item, isFolder=True)

    if end_index < len(unique_movies):
        # Botão "Próxima Página"
        next_page_item = xbmcgui.ListItem(label="Próxima Página >>")
        next_page_url = get_url(action='list_movies_by_popularity', page=page + 1, items_per_page=items_per_page)
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, isFolder=True)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)  

def list_movies_in_cinemas():
    """
    Lista os filmes com o gênero HDCAM na categoria "Nos Cinemas".
    """
    # Obtém todos os filmes
    movies = get_all_videos()  # Ou use get_movies() se for a função correta

    # Filtra apenas filmes com o gênero HDCAM
    hdcam_movies = [movie for movie in movies if movie.get('type') == 'movie' and 'HDCAM' in movie.get('genres', [])]

    # Remove filmes duplicados com base no tmdb_id
    unique_movies = []
    seen_ids = set()  # Conjunto para armazenar IDs já vistos
    for movie in hdcam_movies:
        tmdb_id = movie.get('tmdb_id')
        if tmdb_id and tmdb_id not in seen_ids:
            unique_movies.append(movie)
            seen_ids.add(tmdb_id)

    # Verifica se há filmes
    if not unique_movies:
        xbmcgui.Dialog().ok("Aviso", "Nenhum filme em HDCAM encontrado.")
        return

    # Configura a categoria e o conteúdo do plugin
    xbmcplugin.setPluginCategory(HANDLE, 'Nos Cinemas')
    xbmcplugin.setContent(HANDLE, 'movies')

    # Adiciona todos os filmes à lista (sem paginação)
    for movie in unique_movies:
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setArt({'poster': movie['poster'], 'fanart': movie['backdrop']})
        list_item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('synopsis', ''),
            'rating': movie.get('rating', 0),
            'year': movie.get('year', 0),
            'studio': movie.get('studio', ''),
            'duration': movie.get("runtime", 0),
            'genre': ', '.join(movie.get('genres', [])),
            "aired": movie.get("premiered", "Ano não disponível"),
            'mediatype': 'movie'
        })

        # Gera a URL para reprodução
        url = get_url(action='play', video=','.join(movie['url'])) if 'url' in movie else ''
        list_item.setProperty("IsPlayable", "true")

        # Adiciona menu de contexto para favoritos
        favorites = load_favorites()
        if any(fav['title'] == movie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(movie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(movie))})')
            ])

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)

from datetime import datetime


def list_recently_added():
    """
    Lista os filmes ou séries adicionados recentemente, ordenados por data de adição.
    """
    # Obtém todos os filmes
    movies = get_all_videos()  # Ou use get_movies() se for a função correta

    # Filtra apenas filmes com a tag 'date_added' e que não sejam None
    movies_with_date = [movie for movie in movies if movie.get('date_added') is not None]

    # Remove duplicados com base no tmdb_id (ou outro identificador único)
    unique_movies = []
    seen_ids = set()  # Conjunto para armazenar IDs já vistos
    for movie in movies_with_date:
        tmdb_id = movie.get('tmdb_id')
        if tmdb_id and tmdb_id not in seen_ids:
            unique_movies.append(movie)
            seen_ids.add(tmdb_id)


    # Verifica se há filmes
    if not unique_movies:
        xbmcgui.Dialog().ok("Aviso", "Nenhum filme adicionado recentemente encontrado.")
        return

    # Configura a categoria e o conteúdo do plugin
    xbmcplugin.setPluginCategory(HANDLE, 'Adicionados Recentemente')
    xbmcplugin.setContent(HANDLE, 'movies')  # Ou 'tvshows' para séries


    # Adiciona todos os filmes à lista (já ordenados por date_added)
    for movie in unique_movies:
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setArt({'poster': movie['poster'], 'fanart': movie['backdrop']})
        list_item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('synopsis', ''),
            'rating': movie.get('rating', 0),
            'year': movie.get('year', 0),
            'studio': movie.get('studio', ''),
            'duration': movie.get("runtime", 0),
            'genre': ', '.join(movie.get('genres', [])),
            "aired": movie.get("premiered", "Ano não disponível"),
            'dateadded': movie.get('date_added', ''),
            'mediatype': 'movie'
        })

        # Gera a URL para reprodução
        url = get_url(action='play', video=','.join(movie['url'])) if 'url' in movie else ''
        list_item.setProperty("IsPlayable", "true")

        # Adiciona menu de contexto para favoritos
        favorites = load_favorites()
        if any(fav['title'] == movie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(movie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(movie))})')
            ])

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
            # Adiciona o método de ordenação por data de adição
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATEADDED)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)
# video_listing.py
import urllib.request
import json
import xbmcgui
import xbmcplugin
import sys
from urllib.parse import urlencode, parse_qsl
from resources.action.favorites import load_favorites



HANDLE = int(sys.argv[1])
URL = sys.argv[0]


def get_url(**kwargs):
    """
    Cria uma URL para chamar o plugin recursivamente a partir dos argumentos fornecidos.
    """
    # Serializa objetos JSON, se necessário
    if 'serie' in kwargs and isinstance(kwargs['serie'], dict):
        kwargs['serie'] = json.dumps(kwargs['serie'])
    return '{}?{}'.format(URL, urlencode(kwargs))


MEDIA_TYPES = {
    'movie': {'content_type': 'movies', 'playable': True, 'folder': False},
    'tvshow': {'content_type': 'tvshows', 'playable': False, 'folder': True},
    'set': {'content_type': 'movies', 'playable': False, 'folder': True}
}

def load_videos(external_link):
    """Carrega os vídeos a partir de uma URL externa."""
    try:
        with urllib.request.urlopen(external_link) as response:
            return json.load(response)
    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Erro ao carregar vídeos: {e}')
        return None

def check_maintenance(data):
    """Verifica se a lista está em manutenção."""
    if isinstance(data[0], dict) and data[0].get("status", "").lower() == "off":
        xbmcgui.Dialog().notification("Aguarde...", "A lista está em manutenção!", xbmcgui.NOTIFICATION_WARNING, 3000)
        return True
    return False

def set_content_type(videos):
    """Define o tipo de conteúdo com base nos vídeos."""
    types = {video['type'] for video in videos}
    if types == {'movie'}:
        xbmcplugin.setContent(HANDLE, 'movies')
    elif types == {'tvshow'}:
        xbmcplugin.setContent(HANDLE, 'tvshows')
    elif types == {'set'}:
        xbmcplugin.setContent(HANDLE, 'movies')
    else:
        xbmcplugin.setContent(HANDLE, 'movies')

def create_video_item(video):
    """
    Cria um ListItem para exibir na interface do Kodi.
    """
    
    list_item = xbmcgui.ListItem(label=video['title'])
    list_item.setArt({
        'poster': video.get('poster', ''),
        'thumb': video.get('poster', ''),
        'fanart': video.get('backdrop', '')
    })

    mediatype = video['type']
    media_info = MEDIA_TYPES.get(mediatype, {})
    is_folder = media_info.get('folder', False)

    list_item.setProperty('IsPlayable', 'true' if media_info.get('playable', False) else 'false')

    if mediatype == 'movie':
        url = get_url(action='play', video=','.join(video['url'])) if 'url' in video else ''
    elif mediatype == 'set':
        url = get_url(action='list_collection', collection=json.dumps(video))
    elif mediatype == 'tvshow':  # Caso seja uma série
        url = get_url(action='list_seasons', serie=video)
    else:
        url = ''

    # Define as informações do vídeo
    list_item.setInfo('video', {
        'title': video['title'],
        'rating': video.get('rating', 0),
        'year': video.get('year', 0),
        'studio': video.get('studio', ''),
        'genre': ', '.join(video.get('genres', [])),
        'director': video.get("director", "Desconhecido"),
        'duration': video.get("runtime", 0),
        "aired": video.get("premiered", "Ano não disponível"),
        'sinopse': video.get("synopsis", video.get("sinopse", "Sem sinopse disponível")), 
        'mediatype': mediatype
    })

    # Adiciona o elenco (cast)
    actors = video.get("actors", [])
    cast = [{'name': actor.get('name', 'Desconhecido'), 'thumbnail': actor.get('photo', '')} for actor in actors]
    list_item.setCast(cast)

    list_item.setProperty('mediatype', mediatype)

    # Adiciona menu de contexto para favoritos
    favorites = load_favorites()
    if any(fav['title'] == video['title'] for fav in favorites):
        list_item.addContextMenuItems([
            ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(video))})')
        ])
    else:
        list_item.addContextMenuItems([
            ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(video))})')
        ])

    return list_item, url, is_folder

def list_videos(external_link, sort_method=None, page=1, items_per_page=100):
    """
    Lista os vídeos de uma subcategoria, tanto filmes quanto séries.
    """
    print(f"Debug: list_videos chamada com page={page}, sort_method={sort_method}, external_link={external_link}")  # Debug

    data = load_videos(external_link)
    if not data:
        return

    if check_maintenance(data):
        return

    videos = data[1:] if isinstance(data[0], dict) and "status" in data[0] else data
    set_content_type(videos)

    # Aplica a ordenação com base no sort_method
    if sort_method == 'year':
        videos.sort(key=lambda x: x.get('year', 0), reverse=True)
    elif sort_method == 'rating':
        videos.sort(key=lambda x: x.get('rating', 0), reverse=True)
    elif sort_method == 'label':
        videos.sort(key=lambda x: x.get('title', '').lower())
    elif sort_method == 'genre':
        videos.sort(key=lambda x: x.get('genre', '').lower())

    # Calcula o índice inicial e final para a página atual
    start_index = max(0, (page - 1) * items_per_page)
    end_index = min(len(videos), start_index + items_per_page)
    paginated_videos = videos[start_index:end_index]

    print(f"Debug: Exibindo vídeos {start_index + 1} a {end_index} de {len(videos)}")  # Debug

    for video in paginated_videos:
        if 'title' not in video or 'type' not in video:
            continue  # Ignora vídeos inválidos

        list_item, url, is_folder = create_video_item(video)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    # Adiciona controles de paginação
    if start_index > 0:
        prev_page_item = xbmcgui.ListItem(label='<< Página Anterior')
        prev_page_url = get_url(action='list_videos', external_link=external_link, sort_method=sort_method, page=page-1, items_per_page=items_per_page)
        print(f"Debug: URL da página anterior: {prev_page_url}")  # Debug
        xbmcplugin.addDirectoryItem(HANDLE, prev_page_url, prev_page_item, isFolder=True)

    if end_index < len(videos):
        next_page_item = xbmcgui.ListItem(label='Próxima Página >>')
        next_page_url = get_url(action='list_videos', external_link=external_link, sort_method=sort_method, page=page+1, items_per_page=items_per_page)
        next_page_item.setArt({"icon": "https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/1700740365615.png"})
        print(f"Debug: URL da próxima página: {next_page_url}")  # Debug
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    
import json  # Certifique-se de que o módulo json está importado

def list_collection(collection_json):
    """
    Lista os filmes de uma coleção.
    """
    if not collection_json:
        xbmcgui.Dialog().notification('Erro', 'Coleção não encontrada!', xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        # Decodifica o JSON da coleção
        collection_data = json.loads(collection_json)
    except Exception as e:
        xbmcgui.Dialog().notification('Erro', f'Erro ao carregar coleção: {e}', xbmcgui.NOTIFICATION_ERROR)
        return

    # Define o tipo de conteúdo como 'movies'
    xbmcplugin.setContent(HANDLE, 'movies')

    # Itera sobre os filmes da coleção
    for movie in collection_data.get('movies', []):
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setArt({'poster': movie['poster'], 'thumb': movie['poster'], 'fanart': movie['backdrop']})
        list_item.setProperty('IsPlayable', 'true')

        # Passa a lista de URLs para a função play_video
        url = get_url(action='play', video=','.join(movie['url'])) if 'url' in movie else ''

        # Define informações do filme
        list_item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('plot', ''),
            'rating': movie.get('rate', 0),
            'year': movie.get('year', 0),
            'genre': ', '.join(movie.get('genres', [])),
            'mediatype': 'movie'
        })

        # Define o mediatype corretamente
        list_item.setProperty('mediatype', 'movie')

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

def list_seasons(serie):
    """
    Lista as temporadas de uma série.
    """
    # Desserializa o objeto da série (se for uma string JSON)
    if isinstance(serie, str):
        try:
            serie = json.loads(serie)
        except json.JSONDecodeError:
            xbmcgui.Dialog().ok('Erro', 'Dados da série inválidos!')
            return

    # Verifica se o objeto da série é válido
    if not isinstance(serie, dict) or not serie:
        xbmcgui.Dialog().ok('Erro', 'Dados da série inválidos ou não encontrados!')
        return

    temporadas = serie.get('temporadas', [])
    
    xbmcplugin.setContent(HANDLE, 'seasons')
    for temporada in temporadas:
        list_item = xbmcgui.ListItem(label=temporada['title'])
        list_item.setArt({'poster': temporada.get('poster', ''), 'thumb': temporada.get('poster', '')})
        url = get_url(action='list_episodes', serie=json.dumps(serie), season_title=temporada['title'])

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def list_episodes(serie, season_title):
    """
    Lista os episódios de uma temporada específica de uma série.
    """
    # Desserializa o objeto da série (se for uma string JSON)
    if isinstance(serie, str):
        try:
            serie = json.loads(serie)
        except json.JSONDecodeError:
            xbmcgui.Dialog().ok('Erro', 'Dados da série inválidos!')
            return

    # Verifica se o objeto da série é válido
    if not isinstance(serie, dict) or not serie:
        xbmcgui.Dialog().ok('Erro', 'Série não encontrada!')
        return

    # Procura a temporada correta
    season = next((s for s in serie.get('temporadas', []) if s['title'] == season_title), None)
    if not season:
        xbmcgui.Dialog().ok('Erro', 'Temporada não encontrada!')
        return

    xbmcplugin.setPluginCategory(HANDLE, season_title)
    xbmcplugin.setContent(HANDLE, 'episodes')

    for episode in season.get('episodios', []):
        list_item = xbmcgui.ListItem(label=episode['title'])
        list_item.setArt({'poster': season.get('poster', ''), 'fanart': serie.get('backdrop', '')})
        list_item.setProperty('IsPlayable', 'true')
        
        url = get_url(action='play', video=episode['url'][0]) if episode.get('url') else None
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)



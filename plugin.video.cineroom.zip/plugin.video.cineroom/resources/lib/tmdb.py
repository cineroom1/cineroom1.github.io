import xbmcaddon
import xbmcgui
import urllib.request
import json

def get_tmdb_api_key():
    # Inicialize `addon` diretamente dentro da função
    addon = xbmcaddon.Addon()
    tmdb_api_key = addon.getSetting("tmdb_api_key")
    
    if not tmdb_api_key:
        tmdb_api_key = 'f0b9cd2de131c900f5bb03a0a5776342'  # Defina a chave padrão, se necessário
    return tmdb_api_key

def get_movie_info(tmdb_id):
    # Obtenha a chave de API usando a função acima
    TMDB_API_KEY = get_tmdb_api_key()
    tmdb_url = f'https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={TMDB_API_KEY}&language=pt-BR'
    
    try:
        response = urllib.request.urlopen(tmdb_url)
        data = response.read().decode('utf-8')
        return json.loads(data)
    except Exception as e:
        xbmcgui.Dialog().notification('Erro', f'Não foi possível obter dados do TMDb: {e}', xbmcgui.NOTIFICATION_ERROR)
        return None

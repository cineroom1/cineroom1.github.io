import json
import os
import xbmc
import xbmcgui
import xbmcplugin
import sys

from xbmcvfs import translatePath

ARQUIVO_MINHA_LISTA = translatePath("special://profile/addon_data/plugin.video.cineroom/watch_later.json")

def load_watch_later():
    """Carrega a lista de filmes/séries salvos em 'Assistir mais tarde'."""
    if not os.path.exists(watch_later_file):
        return []
    try:
        with open(watch_later_file, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        xbmc.log(f"Erro ao carregar watch_later.json: {str(e)}", xbmc.LOGERROR)
        return []

def save_watch_later(data):
    """Salva a lista de filmes/séries em 'Assistir mais tarde'."""
    try:
        with open(watch_later_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
    except Exception as e:
        xbmc.log(f"Erro ao salvar watch_later.json: {str(e)}", xbmc.LOGERROR)

def add_to_watch_later(item):
    """Adiciona um item à lista de 'Assistir mais tarde'."""
    data = load_watch_later()
    if item not in data:
        data.append(item)
        save_watch_later(data)
        xbmcgui.Dialog().notification("Assistir mais tarde", "Adicionado com sucesso!", xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().notification("Assistir mais tarde", "Já está na lista!", xbmcgui.NOTIFICATION_WARNING, 3000)

def remove_from_watch_later(item):
    """Remove um item da lista de 'Assistir mais tarde'."""
    data = load_watch_later()
    if item in data:
        data.remove(item)
        save_watch_later(data)
        xbmcgui.Dialog().notification("Assistir mais tarde", "Removido com sucesso!", xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().notification("Assistir mais tarde", "Não está na lista!", xbmcgui.NOTIFICATION_WARNING, 3000)

def is_in_watch_later(item):
    """Verifica se um item já está na lista."""
    return item in load_watch_later()

def list_watch_later(category_name="Assistir mais tarde"):
    """Lista os filmes e séries salvos para assistir mais tarde."""
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    if category_name:
        xbmcplugin.setPluginCategory(int(sys.argv[1]), category_name)

    data = load_watch_later()
    if not data:
        xbmcgui.Dialog().notification("Assistir mais tarde", "Nenhum item salvo!", xbmcgui.NOTIFICATION_INFO, 3000)
        return
    
    for item in data:
        title = item.get("title", "Sem título")
        poster = item.get("poster", "")
        backdrop = item.get("backdrop", "")
        studio = item.get("studio", "Desconhecido")
        year = item.get("year", 0)
        rating = item.get("rating", item.get("rate", 0))
        genres = item.get("genres", "")
        sinopse = item.get("synopsis", item.get("sinopse", "Sem sinopse disponível"))
        is_series = "temporadas" in item
        
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({"poster": poster, "fanart": backdrop})
        list_item.setInfo("video", {
            "title": title,
            "year": year,
            "rating": rating,
            "genre": genres,
            "plot": sinopse,
            "studio": studio
        })
        
        if is_series:
            url = f"{sys.argv[0]}?action=listar_temporadas&serie={title}"
            list_item.setProperty("IsPlayable", "false")
        else:
            video_urls = json.dumps(item["url"])
            url = f"{sys.argv[0]}?action=play&video={video_urls}"
            list_item.setProperty("IsPlayable", "true")
        
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=is_series)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

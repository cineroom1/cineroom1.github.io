from concurrent.futures import ThreadPoolExecutor, as_completed
import xbmc
import xbmcgui
import xbmcplugin

# Dicionário de cache para armazenar informações do TMDb
tmdb_cache = {}

def get_movie_info_cached(tmdb_id, get_movie_info_from_tmdb):
    """Tenta pegar informações do cache. Se não estiver no cache, chama a API do TMDb."""
    if tmdb_id in tmdb_cache:
        return tmdb_cache[tmdb_id]
    info = get_movie_info_from_tmdb(tmdb_id)
    if info:
        tmdb_cache[tmdb_id] = info
    return info

def search_movies(handle, videos, get_videos_from_category, get_url):
    """
    Permite que o usuário busque filmes na lista de vídeos fornecida (sem depender da URL da categoria).
    """
    # Exibe a seleção de critério de busca
    option = choose_search_option()
    if option is None:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return  # Sai se o usuário cancelar e retorna ao menu do addon

    # Para cada critério de busca, o processo é o mesmo: usar o teclado ou selecionar uma opção
    if option == 'Gênero':
        genres = [
            "Animação", "Aventura", "Ação", "Cinema TV", "Comédia", "Crime",
            "Documentário", "Drama", "Família", "Fantasia", "Faroeste", "Ficção científica",
            "Guerra", "História", "Mistério", "Música", "Romance", "Terror", "Thriller"
        ]
        dialog = xbmcgui.Dialog()
        selected_genre = dialog.select('Escolha um Gênero:', genres)
        if selected_genre == -1:  # Usuário cancelou
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return  # Sai e retorna ao menu do addon
        search_query = genres[selected_genre].lower()
    else:
        # Para outros critérios, usa o teclado para entrada de texto
        keyboard = xbmc.Keyboard('', f'Digite o {option.lower()} para pesquisa:')
        keyboard.doModal()

        if not keyboard.isConfirmed():
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return  # Sai e retorna ao menu do addon

        search_query = keyboard.getText().lower()
        if not search_query:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return  # Sai e retorna ao menu do addon

    # Filtrar os vídeos pelo critério selecionado
    if option == 'Nome':
        filtered_videos = filter_videos_by_name(videos, search_query)
    elif option == 'Gênero':
        filtered_videos = filter_videos_by_genre(videos, search_query)
    elif option == 'Ano':
        filtered_videos = filter_videos_by_year(videos, search_query)
    elif option == 'Ator':
        filtered_videos = filter_videos_by_actor(videos, search_query)
    elif option == 'Diretor':
        filtered_videos = filter_videos_by_director(videos, search_query)
    elif option == 'Palavra-chave':  # Nova opção
        filtered_videos = filter_videos_by_keyword(videos, search_query)
    else:
        filtered_videos = []

    # Exibe os resultados
    if filtered_videos:
        xbmcplugin.setPluginCategory(handle, f'Resultados para {option}: {search_query}')
        xbmcplugin.setContent(handle, 'movies')

        for video in filtered_videos:
            # Cria o item da lista com informações de `poster` e `backdrop`
            list_item = xbmcgui.ListItem(label=video.get('title', 'Título desconhecido'))
            list_item.setArt({
                'poster': video.get('poster', ''),  # Usa o campo `poster` do vídeo
                'fanart': video.get('backdrop', ''),  # Usa o campo `backdrop` do vídeo
            })

            # Configura os detalhes do vídeo usando `setInfo`
            video_info = {
                'title': video.get('title', 'Título desconhecido'),
                'year': video.get('year', 0),
                'genre': ", ".join(video.get('genres', '').split(',')),  # Agora trata `genres` como string separada por vírgulas
                'cast': [actor.strip() for actor in video.get('actors', '').split(',')],  # Lista de atores
                'director': video.get('director', 'Desconhecido')  # Exibe o nome do diretor
            }
            list_item.setInfo('video', video_info)

            list_item.setProperty('IsPlayable', 'true')
            url = get_url(action='play', video=video['url'], movie_id=video.get('tmdb_id', ''))
            is_folder = False

            xbmcplugin.addDirectoryItem(handle, url, list_item, is_folder)

        xbmcplugin.endOfDirectory(handle)
    else:
        xbmcgui.Dialog().notification('Resultado', 'Nenhum filme encontrado com esse critério de pesquisa.', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(handle, succeeded=False)


def choose_search_option():
    """
    Exibe uma janela para o usuário selecionar o critério de busca.
    Retorna a opção selecionada ou None se o usuário cancelar.
    """
    options = ['Nome', 'Gênero', 'Ano', 'Ator', 'Diretor', 'Palavra-chave']
    dialog = xbmcgui.Dialog()
    selected_index = dialog.select('Escolha o critério de busca:', options)
    
    if selected_index == -1:  # Se o usuário cancelar
        return None
    
    return options[selected_index]


def filter_videos_by_name(videos, search_query):
    """Filtra os vídeos por nome."""
    return [video for video in videos if 'title' in video and search_query in video['title'].lower()]

def filter_videos_by_genre(videos, search_query):
    """Filtra os vídeos por gênero de forma exata."""
    return [video for video in videos if 'genres' in video and any(search_query == genre.strip().lower() for genre in video['genres'].split(','))]

def filter_videos_by_year(videos, search_query):
    """Filtra os vídeos por ano."""
    return [video for video in videos if 'year' in video and search_query == str(video['year'])]

def filter_videos_by_actor(videos, search_query):
    """Filtra os vídeos por ator."""
    return [video for video in videos if 'actors' in video and any(search_query in actor.strip().lower() for actor in video['actors'].lower().split(','))]

def filter_videos_by_director(videos, search_query):
    """Filtra os vídeos por diretor."""
    return [video for video in videos if 'director' in video and search_query in video['director'].lower()]

def filter_videos_by_keyword(videos, search_query):
    """Filtra os vídeos por palavras-chave no título e em outros campos relevantes."""
    return [
        video for video in videos
        if 'title' in video and search_query in video['title'].lower()  # Busca no título
        or 'genres' in video and any(search_query in genre.lower() for genre in video['genres'].split(','))  # Busca em gêneros
        or 'description' in video and search_query in video['description'].lower()  # Busca em descrição
    ]

# Dados de exemplo para testar o filtro
videos = [
    {'title': 'Ação no Deserto', 'genres': 'Ação, Aventura', 'description': 'Um filme de ação com muita aventura.'},
    {'title': 'Comédia Romântica', 'genres': 'Comédia, Romance', 'description': 'Uma história de amor engraçada.'},
    {'title': 'Ficção Científica', 'genres': 'Ficção Científica', 'description': 'Uma viagem no espaço e no tempo.'}
]

search_query = 'ação'  # Palavra-chave a ser testada
filtered_videos = filter_videos_by_keyword(videos, search_query)

print(filtered_videos)  # Verifique se o filtro retorna os vídeos corretos

import os
import json
import hashlib
import urllib.request
import concurrent.futures
from datetime import datetime, timedelta
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import time
import base64
from concurrent.futures import ThreadPoolExecutor

# Configurações do cache
ADDON = xbmcaddon.Addon()
CACHE_DIR = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo('profile'), 'cache/'))
os.makedirs(CACHE_DIR, exist_ok=True)



class VideoCache:
    def __init__(self):
        self.cache_index = {}
        self.load_index()
        self.enabled = ADDON.getSettingBool('enable_cache')
        xbmc.log(f"[VideoCache] Inicializado. Status: {'Ativado' if self.enabled else 'Desativado'}", xbmc.LOGINFO)
    
    def _obfuscate_url(self, url):
        """Ofusca uma URL para armazenamento seguro"""
        if not url:
            return url
        return base64.b64encode(url[::-1].encode('utf-8')).decode('utf-8')

    def _deobfuscate_url(self, obfuscated_url):
        """Desofusca uma URL armazenada"""
        if not obfuscated_url:
            return obfuscated_url
        try:
            return base64.b64decode(obfuscated_url.encode('utf-8')).decode('utf-8')[::-1]
        except:
            return obfuscated_url

    def _obfuscate_item(self, item):
        """Ofusca campos sensíveis em um item individual"""
        if isinstance(item, dict):
            sensitive_fields = ['url', 'external_link', 'poster', 'backdrop', 'clearlogo']
            for field in sensitive_fields:
                if field in item:
                    if isinstance(item[field], str):
                        item[field] = self._obfuscate_url(item[field])
                    elif isinstance(item[field], list):
                        item[field] = [self._obfuscate_url(x) if isinstance(x, str) else x for x in item[field]]
            return item
        return item

    def _deobfuscate_item(self, item):
        """Desofusca campos sensíveis em um item individual"""
        if isinstance(item, dict):
            sensitive_fields = ['url', 'external_link', 'poster', 'backdrop', 'clearlogo']
            for field in sensitive_fields:
                if field in item:
                    if isinstance(item[field], str):
                        item[field] = self._deobfuscate_url(item[field])
                    elif isinstance(item[field], list):
                        item[field] = [self._deobfuscate_url(x) if isinstance(x, str) else x for x in item[field]]
            return item
        return item

    def _obfuscate_data(self, data):
        """Ofusca os dados completos, incluindo campos sensíveis"""
        try:
            if isinstance(data, list):
                data = [self._obfuscate_item(item) for item in data]
            elif isinstance(data, dict):
                data = self._obfuscate_item(data)
            
            json_str = json.dumps(data)
            reversed_str = json_str[::-1]
            return base64.b64encode(reversed_str.encode('utf-8')).decode('utf-8')
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao ofuscar dados: {str(e)}", xbmc.LOGERROR)
            return None

    def _deobfuscate_data(self, obfuscated_data):
        """Desofusca os dados completos"""
        try:
            decoded = base64.b64decode(obfuscated_data.encode('utf-8')).decode('utf-8')
            original_str = decoded[::-1]
            data = json.loads(original_str)
            
            if isinstance(data, list):
                return [self._deobfuscate_item(item) for item in data]
            elif isinstance(data, dict):
                return self._deobfuscate_item(data)
            return data
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao desofuscar dados: {str(e)}", xbmc.LOGERROR)
            return None
            
    def get_cache_size(self):
        """Retorna o tamanho total do cache em bytes"""
        total_size = 0
        for filename in os.listdir(CACHE_DIR):
            filepath = os.path.join(CACHE_DIR, filename)
            if os.path.isfile(filepath):
                total_size += os.path.getsize(filepath)
        return total_size
    
    def load_index(self):
        """Carrega o índice do cache com URLs ofuscadas usando múltiplas threads"""
        index_file = os.path.join(CACHE_DIR, 'index.json')

        if not os.path.exists(index_file):
            self.cache_index = {}
            return

        try:
            with open(index_file, 'r', encoding='utf-8') as f:
                obfuscated_index = json.load(f)

            self.cache_index = {}

            def process_entry(item):
                key, entry = item
                try:
                    url = self._deobfuscate_url(entry.get('url', ''))
                    if url and 'expires' in entry:
                        entry['url'] = url
                        return key, entry
                except Exception as e:
                    xbmc.log(f"[VideoCache] Erro ao processar entrada {key}: {str(e)}", xbmc.LOGDEBUG)
                return None

            try:
                threads_str = ADDON.getSetting('threads_cache')
                threads = int(threads_str) if threads_str.isdigit() else 4
            except Exception:
                threads = 4  # Garante fallback para 8

            with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as executor:
                results = list(executor.map(process_entry, obfuscated_index.items()))

            self.cache_index = {key: entry for result in results if result for key, entry in [result]}

            xbmc.log(f"[VideoCache] Índice carregado com {len(self.cache_index)} entradas usando {threads} threads", xbmc.LOGDEBUG)

        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao carregar índice: {str(e)}", xbmc.LOGERROR)
            self.cache_index = {}



    
    def save_index(self):
        """Salva o índice do cache com URLs ofuscadas"""
        index_file = os.path.join(CACHE_DIR, 'index.json')
        try:
            # Cria uma cópia ofuscada do índice
            obfuscated_index = {}
            for key, entry in self.cache_index.items():
                obfuscated_entry = entry.copy()
                obfuscated_entry['url'] = self._obfuscate_url(entry.get('url', ''))
                obfuscated_index[key] = obfuscated_entry

            temp_file = index_file + '.tmp'
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(obfuscated_index, f, indent=2, ensure_ascii=False)
            
            if os.path.getsize(temp_file) > 0:
                if os.path.exists(index_file):
                    os.remove(index_file)
                os.rename(temp_file, index_file)
                xbmc.log("[VideoCache] Índice salvo com sucesso", xbmc.LOGDEBUG)
            else:
                xbmc.log("[VideoCache] AVISO: Índice vazio não foi salvo", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao salvar índice: {str(e)}", xbmc.LOGERROR)
    
    def get_cache_path(self, url):
        """Retorna o caminho completo do arquivo de cache"""
        return os.path.join(CACHE_DIR, hashlib.sha256(url.encode('utf-8')).hexdigest() + '.dat')
    
    def get(self, url):
        """Obtém dados do cache"""
        if not self.enabled:
            xbmc.log(f"[VideoCache] Cache DESATIVADO (ignorando): {url}", xbmc.LOGDEBUG)
            return None
        
        cache_key = hashlib.md5(url.encode('utf-8')).hexdigest()

        if cache_key not in self.cache_index:
            xbmc.log(f"[VideoCache] Cache MISS (não encontrado): {url}", xbmc.LOGDEBUG)
            return None
            
        try:
            expiry_time = datetime.fromisoformat(self.cache_index[cache_key]['expires'])
            if datetime.now() > expiry_time:
                xbmc.log(f"[VideoCache] Cache EXPIRADO: {url}", xbmc.LOGDEBUG)
                self.delete(url)
                return None
            
            cache_file = self.get_cache_path(url)
            if not os.path.exists(cache_file):
                xbmc.log(f"[VideoCache] AVISO: Arquivo de cache não existe: {cache_file}", xbmc.LOGWARNING)
                return None
            
            with open(cache_file, 'r', encoding='utf-8') as f:
                obfuscated_data = f.read()
                data = self._deobfuscate_data(obfuscated_data)
                
                if not data or not isinstance(data, list):
                    xbmc.log(f"[VideoCache] AVISO: Dados inválidos em cache: {cache_file}", xbmc.LOGWARNING)
                    return None
                
                xbmc.log(f"[VideoCache] Cache HIT: {url} ({len(data)} itens)", xbmc.LOGINFO)
                return data
                
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao ler cache: {str(e)}", xbmc.LOGERROR)
            return None
    
    def set(self, url, data):
        """Armazena dados no cache"""
        if not self.enabled:
            xbmc.log("[VideoCache] Cache DESATIVADO (não salvando)", xbmc.LOGDEBUG)
            return False

        if not data or not isinstance(data, list):
            xbmc.log("[VideoCache] AVISO: Tentativa de cachear dados inválidos", xbmc.LOGWARNING)
            return False
            
        cache_key = hashlib.md5(url.encode('utf-8')).hexdigest()
        cache_file = self.get_cache_path(url)
        
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
            
            obfuscated_data = self._obfuscate_data(data)
            if not obfuscated_data:
                return False
            
            temp_file = cache_file + '.tmp'
            with open(temp_file, 'w', encoding='utf-8') as f:
                f.write(obfuscated_data)
            
            if os.path.exists(temp_file) and os.path.getsize(temp_file) > 0:
                if os.path.exists(cache_file):
                    os.remove(cache_file)
                os.rename(temp_file, cache_file)
                
                self.cache_index[cache_key] = {
                    'url': url,
                    'expires': (datetime.now() + timedelta(hours=72)).isoformat(),
                    'size': len(data)
                }
                self.save_index()
                
                xbmc.log(f"[VideoCache] Dados cacheados: {url} ({len(data)} itens)", xbmc.LOGINFO)
                return True
            else:
                xbmc.log("[VideoCache] ERRO: Arquivo de cache não foi criado", xbmc.LOGERROR)
                return False
                
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao salvar cache: {str(e)}", xbmc.LOGERROR)
            if os.path.exists(temp_file):
                os.remove(temp_file)
            return False
    
    def delete(self, url):
        """Remove um item do cache"""
        cache_key = hashlib.md5(url.encode('utf-8')).hexdigest()
        try:
            cache_file = self.get_cache_path(url)
            if os.path.exists(cache_file):
                os.remove(cache_file)
            if cache_key in self.cache_index:
                del self.cache_index[cache_key]
            self.save_index()
            xbmc.log(f"[VideoCache] Cache removido: {url}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao remover cache: {str(e)}", xbmc.LOGERROR)
    
    def clear(self):
        """Limpa completamente o cache"""
        try:
            for filename in os.listdir(CACHE_DIR):
                file_path = os.path.join(CACHE_DIR, filename)
                try:
                    if os.path.isfile(file_path):
                        os.unlink(file_path)
                except Exception as e:
                    xbmc.log(f"[VideoCache] ERRO ao remover {file_path}: {str(e)}", xbmc.LOGERROR)
            
            self.cache_index = {}
            self.save_index()
            xbmc.log("[VideoCache] Cache completamente limpo", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao limpar cache: {str(e)}", xbmc.LOGERROR)

# Instância global do cache
VIDEO_CACHE = VideoCache()

def clear_cache():
    """Limpa todo o cache"""
    VIDEO_CACHE.clear()
    xbmcgui.Dialog().notification("Cache", "Cache limpo com sucesso", xbmcgui.NOTIFICATION_INFO)

def get_all_videos():
    """Carrega todos os vídeos com cache e paralelismo"""
    from main import get_menu
    
    all_videos = []
    menu = get_menu()
    
    if not menu:
        return all_videos

    def fetch_videos(url):
        try:
            # Verifica cache primeiro (se ativado)
            if VIDEO_CACHE.enabled:
                cached = VIDEO_CACHE.get(url)
                if cached:
                    xbmc.log(f"[CACHE] Usando cache para {url}", xbmc.LOGINFO)
                    return cached
            
            # Faz download (cache desativado ou não encontrado)
            xbmc.log(f"[NETWORK] Baixando {url}", xbmc.LOGINFO)
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=30) as response:
                data = json.load(response)
                videos = data[1:] if isinstance(data[0], dict) and "status" in data[0] else data
                
                # Adiciona metadados
                for v in videos:
                    v['external_link'] = url
                
                # Salva no cache (se ativado)
                if videos and VIDEO_CACHE.enabled:
                    VIDEO_CACHE.set(url, videos)
                
                return videos
        except Exception as e:
            xbmc.log(f"[ERRO] Falha ao processar {url}: {str(e)}", xbmc.LOGERROR)
            return []

    # Coleta todas as URLs
    urls = []
    for menu_item in menu:
        for sub in menu_item.get('subcategorias', []):
            if url := sub.get('externallink'):
                urls.append(url)

    # Processamento paralelo
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        results = executor.map(fetch_videos, urls)
        for result in results:
            all_videos.extend(result)

    return all_videos
    
def clear_cache(show_dialog=True):
    """
    Limpeza completa e verificada do cache
    :param show_dialog: Mostra diálogos de confirmação e resultado
    :return: True se limpeza bem-sucedida, False caso contrário
    """
    if show_dialog:
        if not xbmcgui.Dialog().yesno('Limpar Cache', 'Tem certeza que deseja limpar todo o cache?'):
            return False

    try:
        # Primeiro: Limpa a instância em memória
        VIDEO_CACHE.cache_index = {}
        VIDEO_CACHE.save_index()
        
        # Segundo: Remove todos os arquivos do diretório
        failed_deletions = []
        for filename in os.listdir(CACHE_DIR):
            file_path = os.path.join(CACHE_DIR, filename)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                failed_deletions.append((filename, str(e)))
                xbmc.log(f"[CACHE] Falha ao remover {filename}: {str(e)}", xbmc.LOGERROR)

        # Verificação final
        remaining_files = [f for f in os.listdir(CACHE_DIR) if f != 'temp']
        if not remaining_files:
            xbmc.log("[CACHE] Limpeza completada com sucesso", xbmc.LOGINFO)
            if show_dialog:
                xbmcgui.Dialog().notification('Sucesso', 'Cache limpo completamente', xbmcgui.NOTIFICATION_INFO)
            return True
        else:
            error_msg = f"{len(remaining_files)} arquivos não removidos"
            xbmc.log(f"[CACHE ERRO] {error_msg}", xbmc.LOGERROR)
            
            if show_dialog:
                report = "\n".join([f"• {f[0]}: {f[1]}" for f in failed_deletions[:3]])
                if len(failed_deletions) > 3:
                    report += f"\n• e mais {len(failed_deletions)-3} arquivos..."
                xbmcgui.Dialog().ok('Erro ao Limpar', f'Alguns arquivos não puderam ser removidos:\n{report}')
            return False

    except Exception as e:
        xbmc.log(f"[CACHE ERRO CRÍTICO] {str(e)}", xbmc.LOGERROR)
        if show_dialog:
            xbmcgui.Dialog().notification('Erro', 'Falha crítica ao limpar cache', xbmcgui.NOTIFICATION_ERROR)
        return False
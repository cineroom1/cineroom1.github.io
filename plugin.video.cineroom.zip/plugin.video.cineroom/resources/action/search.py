import xbmcgui
import xbmcplugin
import xbmc
import sys
import threading
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict
from resources.lib.utils import get_all_videos
from resources.action.video_listing import create_video_item

URL = sys.argv[0]

def get_url(**kwargs):
    """Cria uma URL para chamar o plugin recursivamente a partir dos argumentos fornecidos."""
    return '{}?{}'.format(URL, urlencode(kwargs))

def search_videos(HANDLE):
    """Permite que o usuário pesquise vídeos por título, gênero, ano ou TMDb ID."""
    search_term = xbmcgui.Dialog().input("Digite o título ou TMDb ID:").strip().lower()
    
    if not search_term or len(search_term) < 3:
        xbmcgui.Dialog().ok("Aviso", "Por favor, insira um termo de busca com pelo menos 3 caracteres.")
        return

    try:
        all_videos = get_all_videos()
    except Exception as e:
        xbmcgui.Dialog().ok("Erro", f"Erro ao obter vídeos: {str(e)}")
        return

    # Set para evitar duplicatas usando tmdb_id como identificador único
    unique_videos = defaultdict(bool)
    
    def filter_videos_chunk(videos_chunk):
        """Filtra vídeos dentro de um chunk e armazena os resultados."""
        filtered = []
        try:
            for video in videos_chunk:
                tmdb_id = str(video.get('tmdb_id', ''))  # Converte para string para facilitar comparação
                if unique_videos[tmdb_id]:
                    continue  # Ignora duplicatas
                
                title_match = search_term in video.get('title', '').lower()
                genre_match = search_term in ', '.join(video.get('genres', [])).lower()
                year_match = search_term.isdigit() and search_term == str(video.get('year', ''))
                tmdb_match = search_term.isdigit() and search_term == tmdb_id  # Busca pelo TMDb ID

                if title_match or genre_match or year_match or tmdb_match:
                    unique_videos[tmdb_id] = True  # Marca como já adicionado
                    filtered.append(video)
        except Exception as e:
            xbmc.log(f"Erro na thread de filtragem: {e}", xbmc.LOGERROR)
        
        return filtered

    # Divide os vídeos em partes para threading
    num_threads = min(5, len(all_videos) // 10) or 1  # No mínimo 1 thread, no máximo 5
    chunk_size = max(1, len(all_videos) // num_threads)
    chunks = [all_videos[i:i + chunk_size] for i in range(0, len(all_videos), chunk_size)]
    
    filtered_videos = []
    
    # Usa ThreadPoolExecutor para processamento paralelo
    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        futures = [executor.submit(filter_videos_chunk, chunk) for chunk in chunks]

        for future in as_completed(futures):
            filtered_videos.extend(future.result())

    if not filtered_videos:
        xbmcgui.Dialog().ok("Resultado", "Nenhum vídeo encontrado com o termo de busca.")
        return

    display_results(HANDLE, filtered_videos, search_term)


def display_results(HANDLE, filtered_videos, search_term):
    """Exibe os vídeos filtrados na interface do Kodi."""
    xbmcplugin.setPluginCategory(HANDLE, f'Resultados para: {search_term}')
    xbmcplugin.setContent(HANDLE, 'videos')

    for video in filtered_videos:
        list_item, url, is_folder = create_video_item(video)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)

import sys
import os
import subprocess
import xbmc
import xbmcgui
import xbmcplugin
import re

from urllib.parse import urlparse, parse_qs, urlencode, urlunparse, quote_plus
from datetime import datetime
from urllib.parse import quote
from resources.lib.elementum_rajada  import play_elementum, is_elementum_installed, process_elementum_choice




HANDLE = int(sys.argv[1])

def adicionar_trackers(magnet_link):
    """
    Adiciona trackers públicos ao final de um link magnet.
    """
    trackers = [
        "udp://tracker.openbittorrent.com:80/announce",
        "udp://tracker.trackerfix.com:83/announce",
        "udp://tracker.opentrackr.org:1337/announce",
        "udp://tracker.trackerfix.com:80/announce",
        "udp://tracker.coppersurfer.tk:6969/announce",
        "udp://tracker.leechers-paradise.org:6969/announce",
        "udp://eddie4.nl:6969/announce",
        "udp://p4p.arenabg.com:1337/announce",
        "udp://explodie.org:6969/announce",
        "udp://zer0day.ch:1337/announce",
        "udp://glotorrents.pw:6969/announce",
        "udp://torrent.gresille.org:80/announce",
        "udp://p4p.arenabg.ch:1337",
        "udp://tracker.internetwarriors.net:1337",
        "http://tracker.opentrackr.org:1337/announce",
        "udp://open.stealth.si:80/announce",
        "udp://exodus.desync.com:6969/announce",
        "udp://tracker.cyberia.is:6969/announce",
        "udp://tracker.torrent.eu.org:451/announce",
        "udp://tracker.birkenwald.de:6969/announce",
        "udp://tracker.moeking.me:6969/announce",
        "udp://ipv4.tracker.harry.lu:80/announce",
        "udp://tracker.tiny-vps.com:6969/announce"
    ]

    for tracker in trackers:
        encoded = quote(tracker, safe='')
        if encoded not in magnet_link:
            magnet_link += f"&tr={encoded}"
    return magnet_link

def get_player_choice(path):
    dialog = xbmcgui.Dialog()
    players = []

    if xbmc.getCondVisibility("System.Platform.Windows"):
        vlc_path = r"C:\Program Files\VideoLAN\VLC\vlc.exe"
        if not os.path.exists(vlc_path):
            vlc_path = r"C:\Program Files (x86)\VideoLAN\VLC\vlc.exe"
        if os.path.exists(vlc_path):
            players.append(("VLC", "vlc"))

    elif xbmc.getCondVisibility("System.Platform.Android"):
        players.append(("ResolveURL", "resolveurl"))

    players.append(("Player Padrão (Kodi)", "kodi"))
    choices = [player[0] for player in players]
    index = dialog.select("Escolha o player", choices)

    if index == -1:
        return None, None

    return players[index][1], path


def play_with_vlc(path):
    vlc_path = r"C:\Program Files\VideoLAN\VLC\vlc.exe"
    if not os.path.exists(vlc_path):
        vlc_path = r"C:\Program Files (x86)\VideoLAN\VLC\vlc.exe"
    if os.path.exists(vlc_path):
        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
        command = [vlc_path, "--http-user-agent", user_agent, path]
        try:
            subprocess.Popen(command, shell=False)
            xbmc.log(f"Comando VLC executado: {command}", xbmc.LOGINFO)
        except Exception as e:
            xbmcgui.Dialog().ok("Erro", f"Falha ao abrir no VLC: {str(e)}")
            xbmc.log(f"Erro ao executar VLC: {str(e)}", xbmc.LOGERROR)
    else:
        xbmcgui.Dialog().ok("Erro", "VLC não encontrado. Por favor, instale o VLC.")

def play_with_resolveurl(path):
    try:
        import resolveurl as urlresolver
    except ImportError:
        xbmcgui.Dialog().ok("Erro", "ResolveURL não está instalado.")
        xbmc.log("ResolveURL não encontrado", xbmc.LOGERROR)
        return

    resolved = urlresolver.resolve(path)
    if resolved:
        play_item = xbmcgui.ListItem(path=resolved)
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)
        xbmc.log(f"Reproduzido com ResolveURL: {resolved}", xbmc.LOGINFO)
    else:
        xbmcgui.Dialog().ok("Erro", "Não foi possível resolver o link.")
        xbmc.log(f"ResolveURL falhou: {path}", xbmc.LOGERROR)


def play_with_kodi(path):
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)
    xbmc.log(f"Reproduzindo no player do Kodi: {path}", xbmc.LOGINFO)

import re

def clean_url(url):
    """
    Remove qualquer texto entre parênteses e o próprio parêntese da URL.
    Exemplo: https://example.com/video(DUAL AUDIO) -> https://example.com/video
    """
    print(f"URL antes da limpeza: {url}")  # Adicionei um print para depuração
    cleaned_url = re.sub(r"\([^)]*\)", "", url)
    print(f"URL depois da limpeza: {cleaned_url}")  # E outro print para verificar
    return cleaned_url


def play_video(paths, title='', tmdb_id='', year=None):
    """
    Reproduz um vídeo e limpa o cache para evitar duplicação
    """
    try:
        # Normalização e validação dos paths
        if not paths:
            raise ValueError("Nenhum path fornecido para reprodução")
            
        paths = [paths] if isinstance(paths, str) else list(paths)
        
        # Adiciona opção de busca no Elementum se houver identificador
        if tmdb_id or title:
            paths.append("elementum_search")

        # Mostra diálogo de seleção de fonte
        selected_path = select_source(paths)
        if not selected_path:
            return False

        # Limpa a URL selecionada (removendo parênteses e texto entre parênteses)
        selected_path = clean_url(selected_path)

        # Processa a fonte selecionada
        if selected_path == "elementum_search":
            result = handle_elementum_playback(tmdb_id, title, year)
        elif selected_path.startswith("plugin://plugin.video.elementum"):
            result = handle_elementum_link(selected_path)
        else:
            result = handle_standard_playback(selected_path)

        # Limpa a URL selecionada e atualiza o conteúdo sem duplicação
        xbmc.executebuiltin('Container.Update')  # Atualiza o conteúdo sem reprocessar tudo

        return result

    except Exception as e:
        xbmc.log(f"Erro ao reproduzir vídeo: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Erro", "Falha ao reproduzir o conteúdo", xbmc.NOTIFICATION_ERROR)
        return False
    finally:
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)  # Desativa cache



def select_source(paths):
    """Exibe diálogo customizado para seleção da fonte de reprodução"""
    import xbmcgui
    import xbmcaddon
    import os
    import xbmc

    ADDON = xbmcaddon.Addon()
    ADDON_PATH = ADDON.getAddonInfo('path')
    MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')

    # Caminho absoluto para o XML
    XML_FULL_PATH = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', '720p', 'fontes.xml')

    if not os.path.exists(XML_FULL_PATH):
        xbmc.log(f"[Cineroom] XML não encontrado: {XML_FULL_PATH}", xbmc.LOGERROR)
        return select_source_fallback(paths)

    class SourceSelectorDialog(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            self.paths = kwargs.get('paths', [])
            self.selected_index = -1

        def onInit(self):
            try:
                self.source_list = self.getControl(100)
                self.cancel_button = self.getControl(101)

                items = []
                for i, path in enumerate(self.paths):
                    listitem = xbmcgui.ListItem()

                    if path == "elementum_search":
                        label = "BUSCAR FONTES"
                        icon = os.path.join(MEDIA_PATH, 'elementum.png')
                    else:
                        source_type = 'TORRENT' if 'plugin://plugin.video.elementum' in path else 'LINK DIRETO'
                        icon_name = 'torrent.png' if source_type == 'TORRENT' else 'direct.png'
                        icon = os.path.join(MEDIA_PATH, icon_name)

                        extra_info = extract_extra_info(path) if 'extract_extra_info' in globals() else ''
                        label = f"FONTE {i+1} - {source_type}{extra_info}"

                    # Verifica se o ícone existe
                    if not os.path.exists(icon):
                        xbmc.log(f"[Cineroom] Ícone não encontrado: {icon}", xbmc.LOGERROR)

                    # Define rótulo e ícones
                    listitem.setProperty('SourceLabel', label)
                    listitem.setProperty('ColorVar', 'FFFFFFFF')  # Cor branca
                    listitem.setArt({'icon': icon, 'thumb': icon, 'poster': icon})

                    items.append(listitem)

                self.source_list.addItems(items)
                self.setFocus(self.source_list)

            except Exception as e:
                xbmc.log(f"[Cineroom] Erro no diálogo: {str(e)}", xbmc.LOGERROR)
                self.close()

        def onClick(self, controlId):
            if controlId == 101:
                self.close()
            elif controlId == 100:
                self.selected_index = self.source_list.getSelectedPosition()
                self.close()

    try:
        dialog = SourceSelectorDialog(
            'fontes.xml',
            ADDON_PATH,
            'Default',
            '720p',
            paths=paths
        )
        dialog.doModal()
        selected_index = dialog.selected_index
        del dialog

        return paths[selected_index] if selected_index != -1 else None

    except Exception as e:
        xbmc.log(f"[Cineroom] Falha no diálogo: {str(e)}", xbmc.LOGERROR)
        return select_source_fallback(paths)


def extract_extra_info(path):
    """Extrai informações adicionais entre parênteses no path."""
    match = re.search(r'\s*\(([^)]+)\)\s*$', path)
    return f" - {match.group(1)}" if match else ""

def handle_elementum_playback(tmdb_id, title, year):
    """Lida com a reprodução via Elementum (busca ou play direto)."""
    if not is_elementum_installed():
        xbmcgui.Dialog().notification('Elementum não instalado', 'Instale o Elementum para continuar.', xbmcgui.NOTIFICATION_ERROR)
        return

    if tmdb_id:
        play_elementum(tmdb_id, title)
    else:
        show_elementum_burst_search_from_title(title, year)

import re
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

def handle_elementum_link(path):
    """Processa links do Elementum, adicionando trackers a magnet links e limpando links HTTPS com parênteses e 'DUAL AUDIO'."""
    parsed = urlparse(path)
    query = parse_qs(parsed.query)
    uri = query.get('uri', [''])[0]
    
    # Limpa os parênteses e "DUAL AUDIO" do link HTTPS e também dos magnet links
    uri = re.sub(r'\s*\([^)]*\)\s*$', '', uri)  # Limpa parênteses do final da URL
    uri = re.sub(r'\s*\(.*DUAL AUDIO.*\)\s*$', '', uri)  # Limpa "DUAL AUDIO" no final

    # Verifica se a URL está codificada corretamente
    uri = re.sub(r'%28DUAL%20AUDIO%29', '', uri)  # Remover "(DUAL AUDIO)" codificado como %28DUAL%20AUDIO%29
    
    if uri.startswith("magnet:?"):
        uri = adicionar_trackers(uri)
        query['uri'] = [uri]
        new_query = urlencode(query, doseq=True)
        path = urlunparse(parsed._replace(query=new_query))

    xbmc.log(f"URL após limpeza: {uri}", xbmc.LOGINFO)
    play_with_kodi(path)



def handle_standard_playback(path):
    """Lida com reprodução padrão (URLs ou paths locais)."""
    if path.startswith(('http://', 'https://')):
        player, _ = get_player_choice(path)
        if not player:
            return

        if player == "vlc":
            play_with_vlc(path)
        elif player == "resolveurl":
            play_with_resolveurl(path)
        else:
            play_with_kodi(path)
    else:
        play_with_kodi(path)
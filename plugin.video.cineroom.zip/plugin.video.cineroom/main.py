import os
import sys
import json
import urllib.request
import xbmcgui
import xbmcplugin
import random
import time
import xbmc
import xbmcaddon

from xbmcaddon import Addon
from xbmcvfs import translatePath
from urllib.parse import urlencode, parse_qsl
from concurrent.futures import ThreadPoolExecutor

addon = Addon()

# Obtenha a chave de API do TMDb inserida pelo usuário
tmdb_api_key = addon.getSetting("tmdb_api_key")

# Caso a chave de API do usuário esteja vazia, você pode definir uma chave padrão (opcional)
if not tmdb_api_key:
    tmdb_api_key = 'f0b9cd2de131c900f5bb03a0a5776342'  # Chave padrão, se necessário

# Obtenha o número de vídeos por página
videos_per_page = int(addon.getSetting("videos_per_page"))

# Obtenha o limite de páginas (opcional)
page_limit = int(addon.getSetting("page_limit"))

# Use a chave de API obtida
TMDB_API_KEY = tmdb_api_key

# Obter a configuração do player preferido
addon = xbmcaddon.Addon()
preferred_player = addon.getSetting("preferred_player")

# Get the plugin url in plugin:// notation.
URL = sys.argv[0]
# Get a plugin handle as an integer number.
HANDLE = int(sys.argv[1])
# Get addon base path
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')
FANART_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'fanart')

# Define as categorias e suas respectivas URLs
categories_data = [
    ('Lançamentos', 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/news.json', 'special://home/addons/plugin.video.cineroom/resources/media/lançamentos.png'),
    ('Randomizados', 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/random.json', 'special://home/addons/plugin.video.cineroom/resources/media/randomizados.png'),
    ('Por Notas', 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/notas.json', 'special://home/addons/plugin.video.cineroom/resources/media/por_notas.png'),
    ('Coleções', 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/test.json', 'special://home/addons/plugin.video.cineroom/resources/media/colecoes.png'),
    ('Gêneros', 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/genre.json', 'special://home/addons/plugin.video.cineroom/resources/media/generos.png'),
    ('4K', 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/4k.json', 'special://home/addons/plugin.video.cineroom/resources/media/4k.png'),
    ('[COLOR gray][B]Buscar[/B][/COLOR]', '','special://home/addons/plugin.video.cineroom/resources/media/buscar.png')
]

# Convertendo para dicionários
CATEGORIES = {name: url for name, url, _ in categories_data}
ICONS = {name: icon for name, _, icon in categories_data}


# Define a constante para o número de categorias por página
CATEGORIES_PER_PAGE = 15
VIDEOS_PER_PAGE = videos_per_page  # Número de vídeos por página, baseado nas configurações do usuário


def fetch_data_from_url(url):
    """
    Faz a requisição HTTP para buscar o arquivo JSON hospedado em uma URL.
    """
    try:
        response = urllib.request.urlopen(url)
        data = response.read().decode('utf-8')
        return json.loads(data)
    except Exception as e:
        xbmcgui.Dialog().notification('Erro', f'Não foi possível buscar os dados: {e}', xbmcgui.NOTIFICATION_ERROR)
        return []

def get_url(action, **kwargs):
    """
    Gera a URL para ações do plugin.
    """
    base_url = f'{sys.argv[0]}?action={action}'
    for key, value in kwargs.items():
        base_url += f'&{key}={value}'
    return base_url

def get_videos_from_category(url):
    """
    Obtém a lista de vídeos a partir do arquivo JSON específico de uma categoria.
    """
    data = fetch_data_from_url(url)
    
    # Verifica se a chave 'movies' ou 'gêneros' está presente
    if 'movies' in data:
        return data['movies']
    elif 'gêneros' in data:
        return data['gêneros']
    
    return []  # Retorna uma lista vazia se não houver a chave 'movies' ou 'gêneros'

def get_movie_info_from_tmdb(tmdb_id):
    """
    Faz uma requisição à API do TMDb para obter informações detalhadas sobre o filme.
    """
    tmdb_url = f'https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={TMDB_API_KEY}&language=pt-BR'
    try:
        response = urllib.request.urlopen(tmdb_url)
        data = response.read().decode('utf-8')
        return json.loads(data)
    except Exception as e:
        xbmcgui.Dialog().notification('Erro', f'Não foi possível obter dados do TMDb: {e}', xbmcgui.NOTIFICATION_ERROR)
        return None

def list_categories():
    """
    Lista as categorias disponíveis no plugin.
    """

    for category_name in CATEGORIES.keys():
        list_item = xbmcgui.ListItem(label=category_name)

        # Define as imagens locais para o item
        list_item.setArt({
            'icon': ICONS.get(category_name, 'default.png'),
            'fanart': ICONS.get(category_name, 'default.jpg')
        })

        # Cria a URL para chamar o plugin com a URL da categoria
        url = get_url(action='listing', category=category_name)
        is_folder = True

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)

    xbmcplugin.endOfDirectory(HANDLE)

def list_generos():
    """
    Lista os gêneros disponíveis no plugin.
    """

    # Obtém a URL da categoria
    generos_url = CATEGORIES['Gêneros']

    # Busca os gêneros do arquivo JSON
    xbmc.log(f"Buscando dados de gêneros da URL: {generos_url}", xbmc.LOGINFO)
    generos_data = fetch_data_from_url(generos_url)

    if not generos_data:
        xbmc.log("Erro: Nenhum dado encontrado no arquivo JSON de gêneros.", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Erro', 'Nenhum gênero encontrado', xbmcgui.NOTIFICATION_ERROR)
        return

    # Verifica se a chave 'generos' está presente no JSON
    if 'generos' in generos_data:
        xbmc.log("Dado 'generos' encontrado no arquivo JSON.", xbmc.LOGINFO)
        for genero in generos_data['generos']:
            xbmc.log(f"Processando gênero: {genero['nome']}", xbmc.LOGINFO)
            list_item = xbmcgui.ListItem(label=genero['nome'])

            # Define o ícone do gênero usando a URL do JSON
            list_item.setArt({
                'icon': genero.get('icone', ''),  # Usa a URL do ícone do JSON
                'fanart': os.path.join(FANART_DIR, 'default.jpg')  # Pode manter um fanart padrão
            })

            # Cria a URL para listar os vídeos dentro do gênero
            url = get_url(action='listing', category=genero['nome'])
            is_folder = True

            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)
    else:
        xbmc.log("Erro: A chave 'generos' não foi encontrada no arquivo JSON.", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Erro', 'Nenhum gênero encontrado no arquivo JSON', xbmcgui.NOTIFICATION_ERROR)

    xbmcplugin.endOfDirectory(HANDLE)

    
def list_colecoes():
    """
    Função que lista as coleções disponíveis no arquivo JSON.
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Coleções')
    xbmcplugin.setContent(HANDLE, 'movies')
    
    url = CATEGORIES['Coleções']  # URL do arquivo JSON de coleções
    response = urllib.request.urlopen(url)  # Faz a requisição HTTP
    data = response.read().decode('utf-8')
    colecoes = json.loads(data)  # Carrega o conteúdo JSON

    # Verifica se a chave 'colecoes' está presente no JSON
    if 'colecoes' in colecoes:
        for colecao in colecoes['colecoes']:
            nome_colecao = colecao['nome']
            descricao = colecao['descricao']
            imagem = colecao['imagem']

            # Cria o item de lista para cada coleção
            list_item = xbmcgui.ListItem(label=nome_colecao)
            list_item.setArt({
                'icon': imagem,
                'fanart': imagem
            })
            
            # URL para listar os vídeos da coleção
            url = get_url(action='listar_videos_colecao', colecao=nome_colecao)
            is_folder = True

            # Adiciona o item à interface do Kodi
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)

def listar_videos_colecao(colecao_nome):
    """
    Lista os vídeos de uma coleção específica.
    """
    xbmcplugin.setContent(HANDLE, 'movies')
    
    url = CATEGORIES['Coleções']  # URL do arquivo JSON de coleções
    response = urllib.request.urlopen(url)  # Faz a requisição HTTP
    data = response.read().decode('utf-8')
    colecoes = json.loads(data)

    # Encontrar a coleção correta
    for colecao in colecoes['colecoes']:
        if colecao['nome'] == colecao_nome:
            videos = colecao['videos']
            
            # Define a categoria com o nome da coleção atual
            xbmcplugin.setPluginCategory(HANDLE, colecao_nome)
            
            for video in videos:
                titulo = video['titulo']
                tmdb_id = video['tmdb_id']
                video_url = video['url']

                # Obtém informações do TMDb, se necessário
                tmdb_info = get_movie_info_from_tmdb(tmdb_id)

                # Cria o item de lista para o vídeo
                list_item = xbmcgui.ListItem(label=titulo)
                list_item.setArt({
                    'poster': f"https://image.tmdb.org/t/p/w500{tmdb_info['poster_path']}",
                    'fanart': f"https://image.tmdb.org/t/p/original{tmdb_info['backdrop_path']}"
                })

                # Adiciona informações adicionais
                info_tag = list_item.getVideoInfoTag()
                info_tag.setMediaType('movie')
                info_tag.setTitle(titulo)
                info_tag.setPlot(tmdb_info['overview'])
                info_tag.setYear(int(tmdb_info['release_date'].split('-')[0]) if tmdb_info.get('release_date') else 0)
                info_tag.setRating(tmdb_info.get('vote_average', 0))

                # Definir como item reproduzível
                list_item.setProperty('IsPlayable', 'true')

                # URL para reprodução do vídeo
                url = get_url(action='play', video=video_url, movie_id=tmdb_id)
                is_folder = False

                # Adicionar o item à interface
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)

    

def fetch_category_url(category_name):
    """
    Obtém a URL da categoria, verificando se é um gênero ou não.
    """
    genero_data = fetch_data_from_url(CATEGORIES['Gêneros'])
    if genero_data and 'generos' in genero_data:
        for genero in genero_data['generos']:
            if genero['nome'].lower() == category_name.lower():
                return genero['url']
    return CATEGORIES.get(category_name)


def create_list_item(tmdb_info, show_backdrops):
    """
    Cria um item de lista para o vídeo usando as informações do TMDB.
    """
    list_item = xbmcgui.ListItem(label=tmdb_info['title'])
    list_item.setArt({
        'poster': f"https://image.tmdb.org/t/p/w500{tmdb_info['poster_path']}",
        'fanart': f"https://image.tmdb.org/t/p/original{tmdb_info['backdrop_path']}" if show_backdrops else None
    })
    
    info_tag = list_item.getVideoInfoTag()
    info_tag.setMediaType('movie')
    info_tag.setTitle(tmdb_info['title'])
    info_tag.setPlot(tmdb_info['overview'])
    info_tag.setYear(int(tmdb_info['release_date'].split('-')[0]) if tmdb_info.get('release_date') else 0)
    info_tag.setRating(tmdb_info.get('vote_average', 0))
    info_tag.setDuration(tmdb_info.get('runtime', 0) * 60)
    info_tag.setPremiered(tmdb_info.get('release_date', '1900-01-01'))
    info_tag.setGenres([genre['name'] for genre in tmdb_info.get('genres', [])])

    list_item.setProperty('IsPlayable', 'true')
    return list_item


def list_videos(category_name, page=1, seen_movies=None):
    """
    Cria a lista de vídeos reproduzíveis na interface do Kodi para a categoria selecionada com paginação.
    """
    if seen_movies is None:
        seen_movies = set()  # Inicializa um conjunto para armazenar IDs de filmes vistos

    xbmcplugin.setPluginCategory(HANDLE, f'{category_name}')
    xbmcplugin.setContent(HANDLE, 'movies')

    # Busca a URL da categoria
    category_url = fetch_category_url(category_name)
    
    if not category_url:
        xbmcgui.Dialog().notification('Erro', 'Categoria não encontrada!', xbmcgui.NOTIFICATION_ERROR)
        return

    # Pega os vídeos da categoria
    videos = get_videos_from_category(category_url)
    
    # Aleatoriza os vídeos se a categoria for 'Randomizados'
    # Aleatoriza os vídeos e, em seguida, ordena por nota em ordem descendente se a categoria for 'Randomizados'
    if category_name == 'Randomizados':
        random.shuffle(videos)
        videos = sorted(videos, key=lambda x: x.get('rating', 0), reverse=True)

    
    # Filtra os vídeos para remover aqueles que já foram exibidos
    filtered_videos = [video for video in videos if video['tmdb_id'] not in seen_movies]

    # Implementa a paginação após a ordenação
    start_index = (page - 1) * VIDEOS_PER_PAGE
    end_index = start_index + VIDEOS_PER_PAGE
    paginated_videos = filtered_videos[start_index:end_index]

    
    # Adiciona os IDs dos filmes exibidos ao conjunto
    for video in paginated_videos:
        seen_movies.add(video['tmdb_id'])

    # Verifica se deve exibir backdrops (configuração do usuário)
    show_backdrops = xbmcplugin.getSetting(HANDLE, "show_backdrops") == "true"

    # Obtém o número de threads a serem usadas a partir das configurações do usuário
    max_threads = int(xbmcplugin.getSetting(HANDLE, "num_threads"))
    
    # Usando ThreadPoolExecutor para obter informações dos filmes em paralelo, limitando o número de threads
    with ThreadPoolExecutor(max_workers=max_threads) as executor:
        future_to_video = {executor.submit(get_movie_info_from_tmdb, video['tmdb_id']): video for video in paginated_videos}
        
        for future in future_to_video:
            video = future_to_video[future]
            try:
                # Obtém informações do TMDB
                tmdb_info = future.result()
                if tmdb_info:
                    # Cria o item de lista com as informações do TMDB
                    list_item = create_list_item(tmdb_info, show_backdrops)
                    # Gera a URL para reprodução do vídeo
                    url = get_url(action='play', video=video['url'], movie_id=video['tmdb_id'])
                    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, False)
            except Exception as e:
                print(f"Erro ao buscar informações do vídeo: {e}")

    # Adiciona a opção de 'Próxima Página' se houver mais vídeos
    if end_index < len(filtered_videos):
        next_page_url = get_url(action='listing', category=category_name, page=page + 1, seen_movies=seen_movies)
        next_page_item = xbmcgui.ListItem(label=f'Próxima Página ({page + 1}/{(len(filtered_videos) + VIDEOS_PER_PAGE - 1) // VIDEOS_PER_PAGE})')
        next_page_item.setArt({'icon': 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/1700740365615.png'})
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, True)

    # Definir métodos de ordenação baseados na categoria
    if category_name == 'Lançamentos':
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    elif category_name == 'Por Notas' or category_name == 'Randomizados':
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    elif category_name != '4K':  # Para '4K', não aplicar ordenação adicional
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)

    # Finaliza a listagem no Kodi
    xbmcplugin.endOfDirectory(HANDLE)



import threading

def load_movie_info(movie_id, callback):
    """Carrega as informações do filme em segundo plano."""
    tmdb_info = get_movie_info_from_tmdb(movie_id)
    if tmdb_info:
        callback(tmdb_info)

def play_video(video_url, movie_id):
    """
    Inicia a reprodução do vídeo selecionado com a opção de escolher entre Jacktorr ou Elementum.
    """

    # Pergunta ao usuário qual player usar
    player_options = ["Elementum", "Jacktorr"]
    dialog = xbmcgui.Dialog()
    selected = dialog.select("Escolha o Player", player_options)

    if selected == -1:
        xbmcgui.Dialog().notification("Ação Cancelada", "Nenhum player foi selecionado.")
        return  # Se o usuário cancelar, retorna e não inicia o player

    # Carrega informações do filme em segundo plano
    threading.Thread(target=load_movie_info, args=(movie_id, lambda tmdb_info: start_playback(tmdb_info, video_url, selected))).start()

def start_playback(tmdb_info, video_url, selected):
    """Inicia a reprodução com as informações do filme carregadas."""
    if selected == 0:  # Reproduzir com Elementum
        xbmcgui.Dialog().notification("Player", "Reproduzindo com Elementum")
        video_url = f"plugin://plugin.video.elementum/play?uri=magnet:?xt=urn:btih:{video_url.split('magnet=')[1]}"
    elif selected == 1:  # Reproduzir com Jacktorr
        xbmcgui.Dialog().notification("Player", "Reproduzindo com Jacktorr")
        video_url = f"plugin://plugin.video.jacktorr/play_magnet?magnet={video_url}"

    # Configura a janela de reprodução
    play_item = xbmcgui.ListItem(path=video_url)
    play_item.setInfo(type="Video", infoLabels={
        "Title": tmdb_info['title'], 
        "Genre": tmdb_info['genres'][0]['name'] if tmdb_info['genres'] else 'Desconhecido'
    })
    play_item.setArt({
        'poster': f"https://image.tmdb.org/t/p/w500{tmdb_info['poster_path']}",
        'fanart': f"https://image.tmdb.org/t/p/original{tmdb_info['backdrop_path']}"
    })

    # Inicia o player com o player escolhido
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)



def search_movies():
    """
    Permite que o usuário busque filmes em todas as categorias e na lista de busca.
    """
    # Exibe um teclado para o usuário inserir o nome do filme
    keyboard = xbmc.Keyboard('', 'Digite o nome do filme:')
    keyboard.doModal()
    
    if keyboard.isConfirmed():
        search_query = keyboard.getText().lower()  # Obtém o texto digitado e converte para minúsculas
        if not search_query:
            return  # Se não houver texto, não faz nada

        # Lista de URLs das categorias a serem pesquisadas
        category_urls = [
            CATEGORIES['Lançamentos'],
            CATEGORIES['Randomizados'],
            CATEGORIES['Por Notas'],
            # Adicione mais categorias conforme necessário
        ]

        filtered_videos = []

        # Carrega e filtra os vídeos de cada categoria
        for url in category_urls:
            videos = get_videos_from_category(url)
            filtered_videos.extend([video for video in videos if 'title' in video and search_query in video['title'].lower()])

        # Remove duplicados
        filtered_videos = list({video['tmdb_id']: video for video in filtered_videos}.values())

        if filtered_videos:
            xbmcplugin.setPluginCategory(HANDLE, 'Resultados da Busca')
            xbmcplugin.setContent(HANDLE, 'movies')

            for video in filtered_videos:
                tmdb_info = get_movie_info_from_tmdb(video['tmdb_id'])
                if not tmdb_info:
                    continue

                list_item = xbmcgui.ListItem(label=tmdb_info['title'])
                list_item.setArt({
                    'poster': f"https://image.tmdb.org/t/p/w500{tmdb_info['poster_path']}",
                    'fanart': f"https://image.tmdb.org/t/p/original{tmdb_info['backdrop_path']}"
                })
                info_tag = list_item.getVideoInfoTag()
                info_tag.setMediaType('movie')
                info_tag.setTitle(tmdb_info['title'])
                info_tag.setPlot(tmdb_info['overview'])
                info_tag.setYear(int(tmdb_info['release_date'].split('-')[0]) if tmdb_info.get('release_date') else 0)
                info_tag.setRating(tmdb_info.get('vote_average', 0))

                list_item.setProperty('IsPlayable', 'true')
                url = get_url(action='play', video=video['url'], movie_id=video['tmdb_id'])
                is_folder = False

                xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)

            xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcgui.Dialog().notification('Resultado', 'Nenhum filme encontrado com esse nome.', xbmcgui.NOTIFICATION_INFO)


def display_search_results(search_term):
    """
    Exibe os resultados da busca em uma pasta.
    """

    # Criar uma pasta para os resultados da busca
    folder_title = f'Resultados da Busca: {search_term}'
    list_item = xbmcgui.ListItem(label=folder_title)
    xbmcplugin.addDirectoryItem(HANDLE, '', list_item, isFolder=False)  # Adiciona a pasta

    # Adiciona os filmes encontrados dentro da pasta
    for movie in example_results:
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setProperty('IsPlayable', 'true')

        # URL para reproduzir o vídeo
        url = get_url(action='play', video=movie['url'], movie_id=movie['tmdb_id'])
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    
    
def router(paramstring):
    params = dict(parse_qsl(paramstring))

    if not params:
        list_categories()  # Carrega a primeira página de categorias
    elif params['action'] == 'listing':
        page = int(params.get('page', 1))  # Obtém a página atual
        category = params['category']
        
        if category == 'Gêneros':
            list_generos()
        elif category == '[COLOR gray][B]Buscar[/B][/COLOR]':
            search_movies()
        elif category == 'Coleções':
            list_colecoes()  # Nova categoria de coleções
        else:
            list_videos(category, page)
    elif params['action'] == 'listar_videos_colecao':
        colecao_nome = params['colecao']
        listar_videos_colecao(colecao_nome)  # Chama a função para listar vídeos da coleção
    elif params['action'] == 'play':
        video_url = params['video']
        movie_id = params.get('movie_id')
        play_video(video_url, movie_id)
    else:
        raise ValueError(f'Parâmetro inválido: {paramstring}!')


if __name__ == '__main__':
    router(sys.argv[2][1:])  # Inicia o roteador com os parâmetros da linha de comando



import os
import json
import urllib.request
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import xbmcaddon
import sys
import re

# Caminho correto para o diretório dos dados do addon
ADDON_DATA_PATH = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.example')

HANDLE = int(sys.argv[1])

# Certifique-se de que o diretório existe
if not os.path.exists(ADDON_DATA_PATH):
    os.makedirs(ADDON_DATA_PATH)  # Cria o diretório, se necessário

# Caminho completo do arquivo JSON
CACHE_FILE = os.path.join(ADDON_DATA_PATH, 'grupos.json')

grupos = {}  # Definição global


def is_valid_url(url):
    """
    Verifica se o URL é válido, incluindo URLs com tokens.
    """
    regex = re.compile(
        r'^(https?|ftp)://'  # http://, https:// ou ftp://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  # Domínio
        r'localhost|'  # localhost
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # IP
        r'(?::\d+)?'  # Porta
        r'(?:/?|[/?]\S*)$',  # Parâmetros, tokens, etc.
        re.IGNORECASE
    )
    return re.match(regex, url) is not None


def salvar_grupos():
    """
    Salva os grupos de canais em um arquivo JSON para persistência.
    """
    with open(CACHE_FILE, 'w', encoding='utf-8') as f:
        json.dump(grupos, f)


def carregar_grupos():
    global grupos
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                grupos = json.load(f)
        except json.JSONDecodeError:
            grupos = {}
    else:
        grupos = {}


def extract_attribute(line, attribute):
    """
    Extrai um atributo de uma linha #EXTINF.
    """
    match = re.search(f'{attribute}="([^"]+)"', line)
    return match.group(1) if match else ""


def list_canais(external_link):
    global grupos
    grupos.clear()

    try:
        # Adicionar timeout para evitar travamentos
        response = urllib.request.urlopen(external_link, timeout=10)
        m3u_data = response.read().decode('utf-8')
    except urllib.error.URLError as e:
        xbmcgui.Dialog().ok("Erro", f"Falha ao acessar o link: {e.reason}")
        return
    except UnicodeDecodeError:
        xbmcgui.Dialog().ok("Erro", "Erro ao decodificar o conteúdo do arquivo M3U8.")
        return
    except Exception as e:
        xbmcgui.Dialog().ok("Erro", f"Erro inesperado: {str(e)}")
        return

    # Verificar se o conteúdo é um arquivo M3U8 válido
    if not m3u_data.startswith("#EXTM3U"):
        xbmcgui.Dialog().ok("Erro", "O link não contém um arquivo M3U8 válido.")
        return

    linhas = m3u_data.splitlines()

    for i in range(len(linhas)):
        linha = linhas[i].strip()
        if linha.startswith("#EXTINF:"):
            atributos = linha.split(",")
            nome_canal = atributos[-1]
            tvg_logo = extract_attribute(linha, 'tvg-logo')
            group_title = extract_attribute(linha, 'group-title')

            if i + 1 < len(linhas):
                url = linhas[i + 1].strip()
                if not is_valid_url(url):
                    xbmc.log(f"[AVISO] URL inválido ignorado: {url}", xbmc.LOGWARNING)
                    continue

                canal_info = {
                    'title': nome_canal,
                    'logo': tvg_logo,
                    'group': group_title,
                    'url': url
                }

                if group_title:
                    if group_title not in grupos:
                        grupos[group_title] = []
                    grupos[group_title].append(canal_info)

    salvar_grupos()

    for grupo in grupos.keys():
        list_item = xbmcgui.ListItem(label=grupo)
        url = f"{sys.argv[0]}?action=list_group&group={urllib.parse.quote(grupo)}"
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def list_group(group):
    global grupos
    carregar_grupos()

    if not grupos:
        xbmcgui.Dialog().ok("Erro", "Nenhum grupo foi carregado! Você acessou a lista de canais antes?")
        return

    if group not in grupos:
        xbmcgui.Dialog().ok("Erro", f"Grupo '{group}' não encontrado!")
        return

    for canal in grupos[group]:
        list_item = create_list_item(
            label=canal['title'],
            icon=canal['logo'],
            thumb=canal['logo'],
            info={'title': canal['title']}
        )
        url = f"{sys.argv[0]}?action=play_channel&channel_url={urllib.parse.quote_plus(canal['url'])}"
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def play_channel(channel_url):
    """
    Exibe uma escolha de player para reproduzir canais ao vivo e IPTV.
    """
    url_decodificada = urllib.parse.unquote(channel_url)
    xbmc.log(f"[DEBUG] URL do canal: {url_decodificada}", xbmc.LOGINFO)

    # Verifica se o URL é válido
    if not is_valid_url(url_decodificada):
        xbmcgui.Dialog().ok("Erro", "URL inválido!")
        return

    # Verifica se o link é do Dailymotion
    if 'dailymotion.com' in url_decodificada:
        # Usa o addon do Dailymotion para reproduzir o vídeo
        dailymotion_url = f"plugin://plugin.video.dailymotion_com/?mode=playVideo&url={urllib.parse.quote(url_decodificada)}"
        xbmc.executebuiltin(f"PlayMedia({dailymotion_url})")
        return

    # Verifica se o link é um stream HLS ou MPEG-DASH
    is_hls = '.m3u8' in url_decodificada
    is_ts = '.ts' in url_decodificada

    # Opções de players disponíveis
    players = []

    # Adiciona os novos players
    players.append(("PROXY - HLSRETRY", "proxy_hlsretry"))
    players.append(("PROXY - TSDOWNLOADER", "proxy_tsdownloader"))
    if xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
        players.append(("INPUTSTREAM ADAPTIVE", "inputstream"))
    players.append(("Player Padrão (Kodi)", "kodi"))

    dialog = xbmcgui.Dialog()
    choices = [player[0] for player in players]
    index = dialog.select("Escolha o player para IPTV", choices)

    if index == -1:
        xbmc.log("[DEBUG] Reprodução cancelada pelo usuário.", xbmc.LOGINFO)
        return

    chosen_player = players[index][1]
    item = xbmcgui.ListItem(path=url_decodificada)
    item.setProperty('IsPlayable', 'true')

    # Adicionar headers personalizados para URLs com tokens
    if 'token=' in url_decodificada or 'auth=' in url_decodificada:
        item.setProperty('inputstream.adaptive.stream_headers', f'User-Agent=Mozilla/5.0&Referer={url_decodificada}')

    if chosen_player == "proxy_hlsretry":
        # Usa o F4mTester com streamtype HLSRETRY
        f4m_url = f"plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&url={urllib.parse.quote(url_decodificada)}"
        xbmc.log(f"[DEBUG] Reproduzindo com PROXY - HLSRETRY: {f4m_url}", xbmc.LOGINFO)
        xbmc.executebuiltin(f"PlayMedia({f4m_url})")
        return
    elif chosen_player == "proxy_tsdownloader":
        # Usa o F4mTester com streamtype TSDOWNLOADER
        f4m_url = f"plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&url={urllib.parse.quote(url_decodificada)}"
        xbmc.log(f"[DEBUG] Reproduzindo com PROXY - TSDOWNLOADER: {f4m_url}", xbmc.LOGINFO)
        xbmc.executebuiltin(f"PlayMedia({f4m_url})")
        return
    elif chosen_player == "inputstream":
        if is_hls:
            item.setProperty('inputstream', 'inputstream.adaptive')
            item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            xbmc.log(f"[DEBUG] Reproduzindo com INPUTSTREAM ADAPTIVE (HLS): {url_decodificada}", xbmc.LOGINFO)
        elif is_ts:
            item.setProperty('inputstream', 'inputstream.adaptive')
            item.setProperty('inputstream.adaptive.manifest_type', 'ts')
            xbmc.log(f"[DEBUG] Reproduzindo com INPUTSTREAM ADAPTIVE (TS): {url_decodificada}", xbmc.LOGINFO)
        else:
            xbmcgui.Dialog().ok("Erro", "O link não é um stream HLS ou TS.")
            return
    else:
        xbmc.log(f"[DEBUG] Reproduzindo com o player padrão do Kodi: {url_decodificada}", xbmc.LOGINFO)

    xbmc.Player().play(url_decodificada, item)


def play_m3u(stream_url):
    if not is_valid_url(stream_url):
        xbmcgui.Dialog().ok("Erro", "URL inválido!")
        return

    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)


def create_list_item(label, icon=None, thumb=None, info=None):
    """
    Cria um ListItem do Kodi com opções de ícone, thumbnail e informações.
    """
    list_item = xbmcgui.ListItem(label=label)
    if icon or thumb:
        list_item.setArt({'icon': icon, 'thumb': thumb})
    if info:
        list_item.setInfo('video', info)
    return list_item
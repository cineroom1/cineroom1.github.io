import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import xbmcaddon
import json
import sys
from resources.lib.utils import get_all_videos
from datetime import datetime  # Esta linha substitui o seu import datetime atual

# E depois usar diretamente:
datetime.now().isoformat()

from urllib.parse import urlencode, parse_qsl
from xbmcaddon import Addon
from xbmcvfs import translatePath



URL = sys.argv[0]
HANDLE = int(sys.argv[1])

FAVORITES_FILE = os.path.join(xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.cineroom/"), "favorites.json")

def get_url(**kwargs):
    """
    Cria uma URL para chamar o plugin recursivamente a partir dos argumentos fornecidos.
    """
    return '{}?{}'.format(URL, urlencode(kwargs))

def add_to_favorites(video):
    """
    Adiciona ou atualiza um vídeo/série na lista de favoritos.
    Se for uma série, verifica se já existe e atualiza os dados.
    """
    favorites = load_favorites()
    
    # Para séries, usamos tmdb_id para identificar (se disponível)
    identifier = video.get('tmdb_id') or video['title']
    
    # Verifica se o conteúdo já está nos favoritos
    existing_index = None
    for i, fav in enumerate(favorites):
        if (fav.get('tmdb_id') and fav['tmdb_id'] == video.get('tmdb_id')) or fav['title'] == video['title']:
            existing_index = i
            break

    if existing_index is not None:
        # Se for uma série, faz merge das informações mantendo os dados novos
        if video.get('type') == 'tvshow':
            # Preserva alguns dados existentes que podem ser úteis
            preserved_data = {
                'user_added_date': favorites[existing_index].get('user_added_date', datetime.now().isoformat()),
                'user_notes': favorites[existing_index].get('user_notes', '')
            }
            
            # Atualiza a série mantendo os dados preservados
            updated_series = {**video, **preserved_data}
            favorites[existing_index] = updated_series
            
            notification_msg = f"{video['title']} atualizado na sua lista!"
        else:
            # Para filmes, não fazemos atualização automática
            xbmcgui.Dialog().notification("Minha Lista", f"{video['title']} já está na sua lista!", xbmcgui.NOTIFICATION_INFO, 3000)
            return
    else:
        # Adiciona data/hora quando foi adicionado aos favoritos
        video['user_added_date'] = datetime.now().isoformat()
        favorites.append(video)
        notification_msg = f"{video['title']} adicionado a sua lista!"

    save_favorites(favorites)
    xbmcgui.Dialog().notification("Minha Lista", notification_msg, xbmcgui.NOTIFICATION_INFO, 3000)

def load_favorites():
    """Carrega a lista de favoritos com tratamento de erros melhorado."""
    if not xbmcvfs.exists(FAVORITES_FILE):
        return []

    try:
        with xbmcvfs.File(FAVORITES_FILE, 'r') as file:
            content = file.read()
            return json.loads(content) if content else []
    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Erro ao carregar favoritos: {str(e)}')
        return []

def save_favorites(favorites):
    """Salva a lista de favoritos com tratamento de erros."""
    try:
        # Garante que o diretório existe
        if not xbmcvfs.exists(os.path.dirname(FAVORITES_FILE)):
            xbmcvfs.mkdirs(os.path.dirname(FAVORITES_FILE))
        
        with xbmcvfs.File(FAVORITES_FILE, 'w') as file:
            file.write(json.dumps(favorites, indent=4))
        return True
    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Erro ao salvar favoritos: {str(e)}')
        return False

def save_favorites(favorites):
    """
    Salva a lista de favoritos em um arquivo JSON.
    """
    try:
        os.makedirs(os.path.dirname(FAVORITES_FILE), exist_ok=True)
        with open(FAVORITES_FILE, 'w') as file:
            json.dump(favorites, file)
    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Erro ao salvar favoritos: {e}')

def remove_from_favorites(video):
    """
    Remove um vídeo ou série da lista de favoritos.
    """
    favorites = load_favorites()
    
    # Filtra a lista de favoritos, removendo o vídeo
    updated_favorites = [fav for fav in favorites if fav['title'] != video['title']]
    
    if len(updated_favorites) == len(favorites):
        xbmcgui.Dialog().notification("Sua Lista", f"{video['title']} não está na sua lista!", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Salva a lista atualizada
    save_favorites(updated_favorites)
    xbmcgui.Dialog().notification("Minha Lista", f"{video['title']} removido da sua lista!", xbmcgui.NOTIFICATION_INFO, 3000)

def list_favorites():
    """Lista os favoritos com tratamento para séries atualizadas."""
    from resources.action.video_listing import create_video_item
    
    favorites = load_favorites()
    if not favorites:
        xbmcgui.Dialog().ok('Favoritos', 'Nenhum item encontrado na lista!')
        return

    xbmcplugin.setPluginCategory(HANDLE, 'Minha Lista')
    xbmcplugin.setContent(HANDLE, 'movies')

    for video in favorites:
        # Verifica se o item ainda existe no catálogo principal
        catalog_item = find_in_catalog(video.get('tmdb_id'), video['title'])
        
        # Se encontrou no catálogo, usa os dados atualizados
        current_item = catalog_item if catalog_item else video
        
        list_item, url, is_folder = create_video_item(current_item)
        
        # Menu de contexto
        context_menu = [
            ('Remover da sua Lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(video))})')
        ]
        
        if current_item.get('type') == 'tvshow':
            context_menu.append(('Atualizar Série', f'RunPlugin({get_url(action="force_update_series", video_id=str(video.get("tmdb_id")))})'))
        
        list_item.addContextMenuItems(context_menu)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)

def find_in_catalog(tmdb_id, title):
    """Busca um item no catálogo principal por tmdb_id ou título."""
    all_videos = get_all_videos()  # Você precisará implementar esta função
    
    if tmdb_id:
        for item in all_videos:
            if item.get('tmdb_id') == tmdb_id:
                return item
    
    # Fallback para busca por título
    for item in all_videos:
        if item['title'] == title:
            return item
    
    return None
def force_update_series(video_id):
    """
    Atualiza manualmente os dados de uma série nos favoritos
    buscando informações atualizadas do catálogo principal.
    """
    if not video_id:
        xbmcgui.Dialog().notification("Erro", "ID da série não fornecido", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    # Carrega favoritos e catálogo
    favorites = load_favorites()
    all_videos = get_all_videos()
    
    # Encontra a série no catálogo
    catalog_series = None
    for item in all_videos:
        if str(item.get('tmdb_id')) == str(video_id):
            catalog_series = item
            break
    
    if not catalog_series:
        xbmcgui.Dialog().notification("Erro", "Série não encontrada no catálogo", xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    
    # Atualiza nos favoritos
    updated = False
    for i, fav in enumerate(favorites):
        if str(fav.get('tmdb_id')) == str(video_id):
            # Mantém metadados específicos do usuário
            user_data = {
                'user_added_date': fav.get('user_added_date', datetime.now().isoformat()),
                'user_notes': fav.get('user_notes', ''),
                'user_rating': fav.get('user_rating')
            }
            
            # Combina dados atualizados com dados do usuário
            favorites[i] = {**catalog_series, **user_data}
            updated = True
            break
    
    if updated:
        save_favorites(favorites)
        xbmcgui.Dialog().notification("Sucesso", "Série atualizada com sucesso!", xbmcgui.NOTIFICATION_INFO, 3000)
        # Atualiza a lista para mostrar as mudanças
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmcgui.Dialog().notification("Erro", "Série não encontrada nos favoritos", xbmcgui.NOTIFICATION_ERROR, 3000)    
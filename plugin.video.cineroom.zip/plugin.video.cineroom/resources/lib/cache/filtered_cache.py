import json
import time
import xbmc
import xbmcgui
from datetime import datetime, timedelta
from video_cache import VideoCache

class FilteredCache:
    """Classe para gerenciamento de cache filtrado e ordenado"""
    
    def __init__(self, video_cache):
        self.cache = video_cache
        self.prefix = "filter_"
        self.sort_prefix = "sorted_"
        self.progress = None
        self.max_items = 500
        self.compression = True
        self.batch_size = 20
        self.last_update_time = 0
    
    def _init_progress(self, title):
        """Inicializa a barra de progresso"""
        try:
            self.progress = xbmcgui.DialogProgress()
            self.progress.create(title, 'Aguarde...')
            self.last_update_time = time.time()
        except:
            self.progress = None
    
    def _update_progress(self, percent, message, estimated_time=None):
        """Atualiza a barra de progresso"""
        if not self.progress:
            return
            
        current_time = time.time()
        if current_time - self.last_update_time < 0.3:
            return
            
        self.last_update_time = current_time
        
        try:
            anim_chars = ['|', '/', '-', '\\']
            anim_index = int(current_time * 3) % len(anim_chars)
            animated_msg = f"{message} {anim_chars[anim_index]}"
            
            if estimated_time:
                animated_msg += f" [~{estimated_time}s]"
            
            if self.progress.iscanceled():
                raise Exception("Operação cancelada pelo usuário")
            
            self.progress.update(percent, animated_msg)
        except:
            pass
    
    def _close_progress(self):
        """Fecha a barra de progresso"""
        if self.progress:
            try:
                if self.progress.percent == 100:
                    try:
                        xbmcgui.Dialog().notification('Concluído', 'Operação finalizada', 
                                                    xbmcgui.NOTIFICATION_INFO, 1500)
                    except:
                        pass
                
                self.progress.close()
            except:
                pass
        self.progress = None
    
    def _compress(self, data):
        """Compacta os dados"""
        if not self.compression:
            return data
            
        import zlib, base64
        try:
            json_str = json.dumps(data, separators=(',', ':'))
            return base64.b64encode(zlib.compress(json_str.encode('utf-8'), 1)).decode('utf-8')
        except:
            return data
    
    def _decompress(self, data):
        """Descompacta os dados"""
        if not self.compression or not isinstance(data, str):
            return data
            
        import zlib, base64
        try:
            return json.loads(zlib.decompress(base64.b64decode(data)).decode('utf-8'))
        except:
            return data
    
    def _light_version(self, items):
        """Cria versão leve dos itens"""
        light_items = []
        total_items = min(len(items), self.max_items)
        
        for i in range(0, total_items, self.batch_size):
            batch = items[i:i+self.batch_size]
            light_items.extend({
                'id': item.get('tmdb_id'),
                't': item.get('title')[:30],
                'r': item.get('rating'),
                'y': item.get('year')
            } for item in batch if item.get('tmdb_id'))
            
            if self.progress:
                percent = 60 + ((i + len(batch)) / total_items * 30)
                remaining = max(1, (total_items - i) / self.batch_size)
                self._update_progress(int(percent), 
                                    f"Processando {min(i + len(batch), total_items)}/{total_items}",
                                    estimated_time=remaining * 0.1)
        
        return light_items
    
    def _expand_items(self, light_items):
        """Recupera os itens completos"""
        if not light_items:
            return []
            
        main_cache = self.cache.get('full_items') or {}
        result = []
        missing_ids = []
        
        for i, item in enumerate(light_items):
            if item['id'] in main_cache:
                result.append(main_cache[item['id']])
            else:
                missing_ids.append(item['id'])
            
            if self.progress and i % 50 == 0:
                percent = 10 + (i / len(light_items) * 20)
                self._update_progress(int(percent), "Recuperando itens do cache")
        
        if missing_ids:
            missing_items = self._fetch_missing_items(missing_ids)
            result.extend(missing_items)
            updated_cache = {**main_cache, **{i['tmdb_id']: i for i in missing_items}}
            self.cache.set('full_items', updated_cache, expiry_hours=24)
        
        return result
    
    def _fetch_missing_items(self, ids):
        """Busca itens específicos"""
        if not ids:
            return []
            
        batch_size = 10
        results = []
        
        for i in range(0, len(ids), batch_size):
            batch_ids = ids[i:i+batch_size]
            try:
                all_videos = get_all_videos()
                results.extend(v for v in all_videos if v.get('tmdb_id') in batch_ids)
                
                if self.progress:
                    percent = 30 + (i / len(ids) * 30)
                    self._update_progress(int(percent), 
                                        f"Buscando itens {i+1}/{len(ids)}")
            except Exception as e:
                xbmc.log(f"[FilteredCache] Erro no lote {i//batch_size}: {str(e)}", xbmc.LOGERROR)
        
        return results
    
    def get_filtered(self, filter_name, filter_func, expiry_hours=24, force_refresh=False):
        """Obtém dados filtrados"""
        cache_key = f"{self.prefix}{filter_name}"
        
        if not force_refresh:
            cached = self._decompress(self.cache.get(cache_key))
            if cached:
                if self.progress:
                    self._update_progress(5, "Verificando cache...", estimated_time=1)
                expanded = self._expand_items(cached)
                if expanded and not self.cache.is_expired(cache_key):
                    if self.cache.is_expired(cache_key):
                        xbmc.executebuiltin('RunPlugin(script://refresh_cache)')
                        return self._expand_items(cached)[:self.max_items]

        try:
            self._init_progress(f'Filtrando {filter_name.replace("_", " ")}')
            self._update_progress(10, 'Carregando dados...', estimated_time=2)
            all_videos = get_all_videos()
            
            self._update_progress(30, 'Aplicando filtros...', estimated_time=3)
            filtered = filter_func(all_videos)
            
            self._update_progress(60, 'Otimizando cache...', estimated_time=4)
            light_data = self._light_version(filtered)
            compressed = self._compress(light_data)
            
            def async_cache_update():
                compressed = self._compress(light_data)
                self.cache.set(cache_key, compressed, expiry_hours=expiry_hours)
                full_items = self.cache.get('full_items') or {}
                full_items.update({item['tmdb_id']: item for item in filtered if item.get('tmdb_id')})
                self.cache.set('full_items', full_items, expiry_hours=24)
        
            xbmc.executebuiltin(f'RunScript({async_cache_update})')
            
            self._update_progress(100, 'Concluído!')
            return filtered
            
        except Exception as e:
            xbmc.log(f"[FilteredCache] Erro: {str(e)}", xbmc.LOGERROR)
            return []
        finally:
            self._close_progress()
    
    def get_sorted(self, sort_name, sort_func, expiry_hours=12, force_refresh=False):
        """Obtém dados ordenados"""
        cache_key = f"{self.sort_prefix}{sort_name}"
        
        if not force_refresh:
            cached = self._decompress(self.cache.get(cache_key))
            if cached and not self.cache.is_expired(cache_key):
                return self._expand_items(cached)
                
        try:
            self._init_progress(f'Ordenando {sort_name.replace("_", " ")}')
            
            if self.progress and self.progress.iscanceled():
                return []
                
            self._update_progress(20, 'Carregando dados...', estimated_time=2)
            all_videos = get_all_videos()
            
            if self.progress and self.progress.iscanceled():
                return []
                
            self._update_progress(40, 'Ordenando...', estimated_time=3)
            sorted_videos = sort_func(all_videos)
            
            if self.progress and self.progress.iscanceled():
                return []
                
            self._update_progress(70, 'Otimizando cache...', estimated_time=4)
            light_data = self._light_version(sorted_videos)
            
            if self.progress and self.progress.iscanceled():
                return []
                
            compressed = self._compress(light_data)
            self._update_progress(90, 'Armazenando...', estimated_time=1)
            self.cache.set(cache_key, compressed, expiry_hours=expiry_hours)
            
            self._update_progress(100, 'Concluído!')
            return sorted_videos[:self.max_items]
            
        except Exception as e:
            xbmc.log(f"[FilteredCache] Erro: {str(e)}", xbmc.LOGERROR)
            return []
        finally:
            self._close_progress()


# Funções auxiliares (poderiam ser movidas para um utils.py se desejar)
def get_all_videos():
    """Obtém todos os vídeos (implementação simplificada)"""
    # Implementação original aqui
    pass

def clear_cache(show_dialog=True):
    """Limpa o cache"""
    try:
        if show_dialog and not xbmcgui.Dialog().yesno('Limpar Cache', 'Tem certeza?'):
            return False

        VIDEO_CACHE.clear()
        if show_dialog:
            xbmcgui.Dialog().notification("Cache", "Cache limpo com sucesso", xbmcgui.NOTIFICATION_INFO)
        return True
    except Exception as e:
        xbmc.log(f"[ERRO] Falha ao limpar cache: {str(e)}", xbmc.LOGERROR)
        if show_dialog:
            xbmcgui.Dialog().notification("Erro", "Falha ao limpar cache", xbmcgui.NOTIFICATION_ERROR)
        return False


# Configuração recomendada para dispositivos fracos:
VIDEO_CACHE = VideoCache()
FILTERED_CACHE = FilteredCache(VIDEO_CACHE)
FILTERED_CACHE.max_items = 300
FILTERED_CACHE.compression = True
FILTERED_CACHE.batch_size = 15
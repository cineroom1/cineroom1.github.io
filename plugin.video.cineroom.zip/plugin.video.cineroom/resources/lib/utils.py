import urllib.request
import json
import xbmc
import xbmcgui
import xbmcvfs
import os
import concurrent.futures

# Dicionário global para armazenar os dados em cache
CACHE = {}

import time

def clear_cache():
    """
    Limpa o cache manualmente, tanto em memória quanto em disco.
    """
    global CACHE

    # Limpa o cache em memória
    CACHE.clear()
    xbmc.log("Cache em memória limpo com sucesso.", xbmc.LOGINFO)

    # Caminho absoluto para o diretório de cache
    cache_dir = os.path.expanduser("~/kodi/cache/archive_cache")  # Ajuste o caminho conforme necessário
    xbmc.log(f"Tentando limpar o cache em disco no diretório: {cache_dir}", xbmc.LOGINFO)

    # Verifica se o diretório existe
    if os.path.exists(cache_dir):
        # Lista todos os arquivos no diretório de cache
        for file_name in os.listdir(cache_dir):
            file_path = os.path.join(cache_dir, file_name)
            retries = 3  # Número de tentativas para excluir o arquivo
            while retries > 0:
                try:
                    if os.path.isfile(file_path):  # Verifica se é um arquivo (não um diretório)
                        os.remove(file_path)
                        xbmc.log(f"Arquivo {file_path} removido do cache em disco.", xbmc.LOGINFO)
                        break
                    else:
                        xbmc.log(f"Ignorando diretório: {file_path}", xbmc.LOGINFO)
                        break
                except Exception as e:
                    xbmc.log(f"Erro ao remover o arquivo {file_path}: {e}. Tentativas restantes: {retries - 1}", xbmc.LOGERROR)
                    retries -= 1
                    time.sleep(1)  # Aguarda 1 segundo antes de tentar novamente

            if retries == 0:
                xbmc.log(f"Não foi possível remover o arquivo {file_path}. Ele pode estar em uso.", xbmc.LOGERROR)

        xbmc.log("Tentativa de limpar o cache em disco concluída.", xbmc.LOGINFO)
    else:
        xbmc.log(f"Diretório de cache em disco não encontrado: {cache_dir}", xbmc.LOGERROR)

    # Exibe uma notificação para o usuário
    xbmcgui.Dialog().notification("Cache", "Cache limpo com sucesso.", xbmcgui.NOTIFICATION_INFO)

def get_all_videos():
    """
    Carrega todos os vídeos de todas as subcategorias, utilizando cache para evitar múltiplas requisições
    e threads para acelerar o carregamento.
    """
    from main import get_menu  # Evita import circular
    all_videos = []
    menu = get_menu()  # Carrega o menu principal

    if not menu:
        return all_videos

    urls_to_fetch = []

    for menu_item in menu:
        subcategories = menu_item.get('subcategorias', [])
        for subcategory in subcategories:
            external_link = subcategory.get('externallink')
            if external_link:
                if external_link in CACHE:
                    xbmc.log(f"Usando cache para {external_link}", xbmc.LOGINFO)
                    all_videos.extend(CACHE[external_link])
                else:
                    urls_to_fetch.append(external_link)

    # Função interna para baixar vídeos
    def fetch_videos(url):
        try:
            xbmc.log(f"Baixando vídeos de {url}", xbmc.LOGINFO)
            with urllib.request.urlopen(url) as response:
                data = json.load(response)
                videos = data[1:] if isinstance(data[0], dict) and "status" in data[0] else data
                for video in videos:
                    video['external_link'] = url
                CACHE[url] = videos  # Armazena no cache
                return videos
        except Exception as e:
            xbmc.log(f"Erro ao carregar vídeos de {url}: {e}", xbmc.LOGERROR)
            return []

    # Usa threads para acelerar downloads
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as executor:
        results = executor.map(fetch_videos, urls_to_fetch)

    # Adiciona os vídeos baixados à lista final
    for videos in results:
        all_videos.extend(videos)

    return all_videos
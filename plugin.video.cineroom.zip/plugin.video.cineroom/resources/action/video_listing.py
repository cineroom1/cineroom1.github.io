# video_listing.py

import json
import xbmcgui
import xbmcplugin
import sys
import xbmc
import time
import json
import xbmc
import urllib.parse
import urllib.request

from urllib.parse import urlencode, parse_qsl
from resources.action.favorites import load_favorites


HANDLE = int(sys.argv[1])
URL = sys.argv[0]


def get_url(**kwargs) -> str:
    """
    Cria uma URL para chamar o plugin recursivamente.
    Otimizado para serialização automática de objetos.
    """
    params = {}
    for key, value in kwargs.items():
        if isinstance(value, (dict, list)):
            params[key] = json.dumps(value)
        else:
            params[key] = value
    return f"{URL}?{urlencode(params)}"


MEDIA_TYPES = {
    'movie': {'content_type': 'movies', 'playable': True, 'folder': False},
    'tvshow': {'content_type': 'tvshows', 'playable': False, 'folder': True},
    'set': {'content_type': 'movies', 'playable': False, 'folder': True}
}

def load_videos(external_link):
    """Carrega os vídeos a partir de uma URL externa."""
    try:
        with urllib.request.urlopen(external_link) as response:
            return json.load(response)
    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Erro ao carregar vídeos: {e}')
        return None

def check_maintenance(data):
    """Verifica se a lista está em manutenção."""
    if isinstance(data[0], dict) and data[0].get("status", "").lower() == "off":
        xbmcgui.Dialog().notification("Aguarde...", "A lista está em manutenção!", xbmcgui.NOTIFICATION_WARNING, 3000)
        return True
    return False

def set_content_type(videos):
    """Define o tipo de conteúdo com base nos vídeos."""
    types = {video['type'] for video in videos}
    if types == {'movie'}:
        xbmcplugin.setContent(HANDLE, 'movies')
    elif types == {'tvshow'}:
        xbmcplugin.setContent(HANDLE, 'tvshows')
    elif types == {'set'}:
        xbmcplugin.setContent(HANDLE, 'movies')
    else:
        xbmcplugin.setContent(HANDLE, 'movies')

def create_video_item(video):
    """
    Cria um ListItem para exibir na interface do Kodi.
    """
    try:
        xbmc.log(f"Iniciando a criação do ListItem para o vídeo: {video['title']}", xbmc.LOGINFO)
        
        # Criação do ListItem
        list_item = xbmcgui.ListItem(label=video['title'])
        list_item.setArt({
            'poster': video.get('poster', ''),
            'thumb': video.get('poster', ''),
            'fanart': video.get('backdrop', ''),
            'clearlogo': video.get('clearlogo', '')
        })

        mediatype = video['type']
        media_info = MEDIA_TYPES.get(mediatype, {})
        is_folder = media_info.get('folder', False)

        list_item.setProperty('IsPlayable', 'true' if media_info.get('playable', False) else 'false')
        
        xbmc.log(f"Tipo de mídia: {mediatype}, IsFolder: {is_folder}, Playable: {media_info.get('playable', False)}", xbmc.LOGINFO)

        if mediatype == 'movie':
            urls = video.get('url', [])
            if isinstance(urls, str):
                urls = [urls]
            url = get_url(action='play', video=','.join(urls), tmdb_id=video.get('tmdb_id', ''))


        elif mediatype == 'set':
            url = get_url(action='list_collection', collection=json.dumps(video))
        elif mediatype == 'tvshow':  # Caso seja uma série
            url = get_url(action='list_seasons', serie=video)
        else:
            url = ''
        
        # Define as informações do vídeo
        list_item.setInfo('video', {
            'title': video['title'],
            'rating': video.get('rating', 0),
            'year': video.get('year', 0),
            'studio': video.get('studio', ''),
            'genre': ', '.join(video.get('genres', [])),
            'director': video.get("director", "Desconhecido"),
            'duration': video.get("runtime", 0),
            "aired": video.get("premiered", "Ano não disponível"),
            'plot': video.get('synopsis', ''),
            'mediatype': mediatype
        })

        actors = video.get("actors", [])
        cast = [{'name': actor.get('name', 'Desconhecido')} if isinstance(actor, dict) else {'name': actor} for actor in actors]
        list_item.setCast(cast)

        list_item.setProperty('mediatype', mediatype)

        # Adiciona menu de contexto para favoritos
        favorites = load_favorites()
        if any(fav['title'] == video['title'] for fav in favorites):
            list_item.addContextMenuItems([('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(video))})')])
        else:
            list_item.addContextMenuItems([('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(video))})')])

        xbmc.log(f"ListItem criado com sucesso para o vídeo: {video['title']}", xbmc.LOGINFO)
        
        return list_item, url, is_folder

    except Exception as e:
        xbmc.log(f"Erro ao criar ListItem para o vídeo: {video.get('title', 'Desconhecido')} - {str(e)}", xbmc.LOGERROR)
        return None, None, False



def list_videos(external_link, sort_method=None, page=1, items_per_page=100):
    """
    Lista os vídeos de uma subcategoria, tanto filmes quanto séries.
    """
    print(f"Debug: list_videos chamada com page={page}, sort_method={sort_method}, external_link={external_link}")  # Debug

    data = load_videos(external_link)
    if not data:
        return

    if check_maintenance(data):
        return

    videos = data[1:] if isinstance(data[0], dict) and "status" in data[0] else data

    # 🔍 VERIFICAÇÃO DE TYPE
    for v in videos:
        if v.get('type') != 'tvshow':
            titulo = v.get('title', 'Sem título')
            tipo = v.get('type', 'NÃO DEFINIDO')
            xbmc.log(f"[CINEROOM] Série inválida: '{titulo}' com type='{tipo}'", xbmc.LOGWARNING)

    set_content_type(videos)

    # Aplica a ordenação com base no sort_method
    if sort_method == 'year':
        videos.sort(key=lambda x: x.get('year', 0), reverse=True)
    elif sort_method == 'rating':
        videos.sort(key=lambda x: x.get('rating', 0), reverse=True)
    elif sort_method == 'label':
        videos.sort(key=lambda x: x.get('title', '').lower())
    elif sort_method == 'genre':
        videos.sort(key=lambda x: x.get('genre', '').lower())

    # Calcula o índice inicial e final para a página atual
    start_index = max(0, (page - 1) * items_per_page)
    end_index = min(len(videos), start_index + items_per_page)
    paginated_videos = videos[start_index:end_index]

    print(f"Debug: Exibindo vídeos {start_index + 1} a {end_index} de {len(videos)}")  # Debug

    for video in paginated_videos:
        if 'title' not in video or 'type' not in video:
            continue  # Ignora vídeos inválidos

        list_item, url, is_folder = create_video_item(video)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    if end_index < len(videos):
        next_page_item = xbmcgui.ListItem(label='Próxima Página >>')
        next_page_url = get_url(action='list_videos', external_link=external_link, sort_method=sort_method, page=page+1, items_per_page=items_per_page)
        next_page_item.setArt({"icon": "https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/1700740365615.png"})
        print(f"Debug: URL da próxima página: {next_page_url}")  # Debug
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def list_seasons(serie_data):
    """Lista temporadas com desempenho máximo para grandes catálogos"""
    try:
        # 1. Desserialização Rápida
        if isinstance(serie_data, str):
            serie = json.loads(serie_data)
        else:
            serie = serie_data

        # 2. Validação Rápida
        if not isinstance(serie, dict) or not serie.get('temporadas'):
            raise ValueError("Dados da série inválidos ou 'temporadas' ausentes.")

        # 3. Codificação do título da série para uso interno
        serie_title = serie.get('title', '')
        encoded_title = urllib.parse.quote(serie_title)

        # 4. Usando o título original para exibição no Kodi (sem codificação)
        title_for_display = serie.get('title', '')

        # 5. Configurações Iniciais
        xbmcplugin.setPluginCategory(HANDLE, title_for_display)
        xbmcplugin.setContent(HANDLE, 'seasons')
        
        # 6. Cache de Artes
        poster = serie.get('poster', '')
        fanart = serie.get('backdrop', '')

        # 7. Processamento Acelerado
        for temp in serie['temporadas']:
            if not temp.get('title'):
                continue

            # Verifica disponibilidade
            episodios_url = temp.get('episodios_link', '')
            episodios_inline = temp.get('episodios', [])
            is_disponivel = bool(episodios_url or episodios_inline)

            # Ajuste do título
            title = temp['title']
            if not is_disponivel:
                title += ' (Offline)'

            # Criação mínima do item
            li = xbmcgui.ListItem(label=title)

            # Arte essencial apenas
            li.setArt({
                'poster': temp.get('poster', poster),
                'fanart': fanart
            })
            li.setInfo('video', {
                'title': title,
                'plot': temp.get('synopsis', ''),
                'rating': temp.get('rating', 0),
                'premiered': temp.get('air_date', ''),
                'mediatype': 'seasons'
            })

            # Passando a URL de episódios ou dados inline
            if episodios_url or episodios_inline:
                url = get_url(
                    action='list_episodes',
                    serie=json.dumps({
                        'title': encoded_title,
                        'episodios_url': episodios_url,  # Passa a URL diretamente
                        'episodios_inline': episodios_inline,
                        'poster': temp.get('poster', poster)
                    }),
                    season_title=temp['title']
                )
                xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE)
        return True

    except Exception as e:
        xbmc.log(f"Erro list_seasons: {str(e)}", xbmc.LOGERROR)
        return False

def list_episodes(season_data, season_title):
    """Lista episódios com suporte a duração (runtime)"""
    try:
        # 1. Desserialização Rápida
        if isinstance(season_data, str):
            season = json.loads(season_data)
        else:
            season = season_data

        # 2. Verificação Rápida
        episodios_url = season.get('episodios_url', '')
        episodios_inline = season.get('episodios_inline', [])
        if not episodios_url and not episodios_inline:
            xbmc.log(f"Erro ao processar temporada: {season_title}. Dados incorretos ou ausentes.", xbmc.LOGERROR)
            return False

        # 3. Carregar dados dos episódios
        episodios_data = []
        if episodios_url:
            try:
                with urllib.request.urlopen(episodios_url) as response:
                    episodios_data = json.loads(response.read().decode()).get('episodios', [])
            except Exception as e:
                xbmc.log(f"Erro ao carregar dados dos episódios para a temporada {season_title}: {str(e)}", xbmc.LOGERROR)
        elif episodios_inline:
            episodios_data = episodios_inline

        # 4. Configuração Básica
        xbmcplugin.setPluginCategory(HANDLE, season_title)
        xbmcplugin.setContent(HANDLE, 'episodes')

        # 5. Cache de Arte
        poster = season.get('poster', '')

        # 6. Processamento Direto
        for ep in episodios_data:
            if not ep or not ep.get('url'):
                continue

            # Criação do ListItem
            li = xbmcgui.ListItem(label=ep.get('title', ''))
            
            # Preparação das informações
            info = {
                'title': ep.get('title', ''),
                'plot': ep.get('synopsis', ''),
                'mediatype': 'episode'
            }

            # Adiciona campos condicionais
            if ep.get('air_date'):
                info['date'] = ep['air_date']
            if ep.get('rating'):
                info['rating'] = float(ep['rating'])
            if ep.get('runtime'):
                info['duration'] = int(ep['runtime']) * 60  # Converte minutos para segundos
            if ep.get('aired'):
                info['premiered'] = ep['aired']
            else:
                info['premiered'] = "Ano não disponível"

            li.setInfo('video', info)

            # Configuração de arte
            art = {}
            if 'poster' in ep:
                art['thumb'] = ep['poster']
            elif poster:
                art['thumb'] = poster
            li.setArt(art)

            # Configuração de propriedades
            li.setProperty('IsPlayable', 'true')
            li.setProperty('mediatype', 'episode')

            # Preparação da URL
            url = ep['url']
            if isinstance(url, str):
                url = [url]
            elif not isinstance(url, list):
                xbmc.log(f"Formato de URL inválido para: {ep.get('title', 'Desconhecido')}", xbmc.LOGERROR)
                continue

            # Adiciona o item à lista
            xbmcplugin.addDirectoryItem(
                HANDLE,
                get_url(action='play', video=json.dumps(url)),
                li,
                isFolder=False
            )

        xbmcplugin.endOfDirectory(HANDLE)
        return True

    except Exception as e:
        xbmc.log(f"Erro em list_episodes: {str(e)}", xbmc.LOGERROR)
        return False




def list_collection(collection_json):
    """
    Lista os filmes de uma coleção.
    """
    if not collection_json:
        xbmcgui.Dialog().notification('Erro', 'Coleção não encontrada!', xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        # Decodifica o JSON da coleção
        collection_data = json.loads(collection_json)
    except Exception as e:
        xbmcgui.Dialog().notification('Erro', f'Erro ao carregar coleção: {e}', xbmcgui.NOTIFICATION_ERROR)
        return

    # Define o tipo de conteúdo como 'movies'
    xbmcplugin.setContent(HANDLE, 'movies')

    # Itera sobre os filmes da coleção
    for movie in collection_data.get('movies', []):
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setArt({'poster': movie['poster'], 'thumb': movie['poster'], 'fanart': movie['backdrop']})
        list_item.setProperty('IsPlayable', 'true')

        # Passa a lista de URLs para a função play_video
        url = get_url(action='play', video=','.join(movie['url'])) if 'url' in movie else ''

        # Define informações do filme
        list_item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('plot', ''),
            'rating': movie.get('rate', 0),
            'year': movie.get('year', 0),
            'genre': ', '.join(movie.get('genres', [])),
            'mediatype': 'movie'
        })

        # Define o mediatype corretamente
        list_item.setProperty('mediatype', 'movie')

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)




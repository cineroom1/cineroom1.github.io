import sys
import os
import subprocess
import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])

def get_player_choice(path):
    """
    Oferece ao usuário a escolha do player para reproduzir o vídeo.
    Retorna o player escolhido e o caminho do vídeo.
    """
    dialog = xbmcgui.Dialog()
    players = []

    if xbmc.getCondVisibility("System.Platform.Windows"):
        # Windows: Oferece VLC e player padrão do Kodi
        vlc_path = r"C:\Program Files\VideoLAN\VLC\vlc.exe"
        if not os.path.exists(vlc_path):
            vlc_path = r"C:\Program Files (x86)\VideoLAN\VLC\vlc.exe"
        if os.path.exists(vlc_path):
            players.append(("VLC", "vlc"))
    elif xbmc.getCondVisibility("System.Platform.Android"):
        # Android: Oferece InputStream e player padrão do Kodi
        if xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
            players.append(("InputStream Adaptive", "inputstream"))

    # Adiciona o player padrão do Kodi
    players.append(("Player Padrão (Kodi)", "kodi"))

    # Oferece a escolha ao usuário
    choices = [player[0] for player in players]
    index = dialog.select("Escolha o player", choices)

    if index == -1:
        return None, None  # Usuário cancelou

    return players[index][1], path

def play_with_vlc(path):
    """
    Reproduz o vídeo usando o VLC (apenas no Windows).
    """
    vlc_path = r"C:\Program Files\VideoLAN\VLC\vlc.exe"
    if not os.path.exists(vlc_path):
        vlc_path = r"C:\Program Files (x86)\VideoLAN\VLC\vlc.exe"
    if os.path.exists(vlc_path):
        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
        command = [vlc_path, "--http-user-agent", user_agent, path]
        try:
            subprocess.Popen(command, shell=False)
            xbmc.log(f"Comando VLC executado: {command}", xbmc.LOGINFO)
        except Exception as e:
            xbmcgui.Dialog().ok("Erro", f"Falha ao abrir no VLC: {str(e)}")
            xbmc.log(f"Erro ao executar VLC: {str(e)}", xbmc.LOGERROR)
    else:
        xbmcgui.Dialog().ok("Erro", "VLC não encontrado. Por favor, instale o VLC.")

def play_with_inputstream(path):
    """
    Reproduz o vídeo usando o InputStream Adaptive (apenas no Android).
    """
    play_item = xbmcgui.ListItem(path=path)
    play_item.setProperty('inputstream', 'inputstream.adaptive')
    play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')  # ou 'mpd' para DASH
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)
    xbmc.log(f"Reproduzindo com InputStream Adaptive: {path}", xbmc.LOGINFO)

def play_with_kodi(path):
    """
    Reproduz o vídeo usando o player padrão do Kodi.
    """
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)
    xbmc.log(f"Reproduzindo no player do Kodi: {path}", xbmc.LOGINFO)

def play_video(paths):
    """
    Reproduz um vídeo a partir de uma ou mais URLs fornecidas.
    Se houver mais de uma URL, oferece opções de escolha ao usuário.
    """
    if isinstance(paths, list) and len(paths) > 1:
        dialog = xbmcgui.Dialog()
        choices = [
            f"Fonte {i+1} - {'Torrent' if 'plugin://plugin.video.elementum' in path else 'Link Direto'}"
            for i, path in enumerate(paths)
        ]
        index = dialog.select("Escolha uma fonte", choices)
        if index == -1:
            return  # Usuário cancelou
        selected_path = paths[index]
    else:
        selected_path = paths if isinstance(paths, str) else paths[0]

    # Verifica se o link é do tipo "plugin://plugin.video.elementum"
    if selected_path.startswith("plugin://plugin.video.elementum"):
        # Reproduz diretamente no player padrão do Kodi
        play_with_kodi(selected_path)
        return

    # Verifica se o link começa com "https://" e exibe a escolha de player
    if selected_path.startswith("https://"):
        player, path = get_player_choice(selected_path)
        if not player:
            return  # Usuário cancelou

        # Reproduz com o player escolhido
        if player == "vlc":
            play_with_vlc(path)
        elif player == "inputstream":
            play_with_inputstream(path)
        else:
            play_with_kodi(path)
    else:
        # Reproduz diretamente no player padrão do Kodi para outros tipos de links
        play_with_kodi(selected_path)

    # Garantir que o fluxo de navegação volte para o diretório anterior após a reprodução
    xbmcplugin.endOfDirectory(HANDLE)
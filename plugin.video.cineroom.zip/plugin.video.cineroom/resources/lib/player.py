import threading
import xbmcgui
import xbmcplugin
import xbmcaddon

# Inicialização do addon
addon = xbmcaddon.Addon()

def load_movie_info(movie_id, callback):
    """
    Carrega as informações do filme em segundo plano.
    """
    tmdb_info = get_movie_info_from_tmdb(movie_id)
    if tmdb_info:
        callback(tmdb_info)

def play_video(video_url, movie_id, addon):
    """
    Inicia a reprodução do vídeo selecionado com a opção de escolher entre Jacktorr ou Elementum,
    com base nas configurações do player preferido.
    """
    # Obtém o player preferido das configurações
    preferred_player = addon.getSetting("preferred_player")

    # Se o player preferido não estiver configurado, pergunte ao usuário
    if preferred_player == "0":  # Elementum
        selected = 0
    elif preferred_player == "1":  # Jacktorr
        selected = 1
    else:
        # Pergunta ao usuário qual player usar
        player_options = ["Elementum", "Jacktorr"]
        dialog = xbmcgui.Dialog()
        selected = dialog.select("Escolha o Player", player_options)

        # Se o usuário cancelar, retorna e não inicia o player
        if selected == -1:
            xbmcgui.Dialog().notification("Ação Cancelada", "Nenhum player foi selecionado.")
            return

    # Carrega as informações do filme em segundo plano
    threading.Thread(target=load_movie_info, args=(movie_id, lambda tmdb_info: start_playback(tmdb_info, video_url, selected))).start()

def start_playback(tmdb_info, video_url, selected):
    """Inicia a reprodução com as informações do filme carregadas."""
    try:
        # Verificar se o video_url é válido
        if 'magnet=' not in video_url:
            xbmcgui.Dialog().notification("Erro", "URL de vídeo inválida.")
            return

        # Configurar o magnet link
        magnet_link = video_url.split('magnet=')[1]
        if selected == 0:  # Reproduzir com Elementum
            xbmcgui.Dialog().notification("Aguarde", f"Buscando Dados: [COLOR yellow]{tmdb_info['title']}[/COLOR]", sound=False)
            video_url = f"plugin://plugin.video.elementum/play?uri=magnet:?xt=urn:btih:{magnet_link}"
        elif selected == 1:  # Reproduzir com Jacktorr
            xbmcgui.Dialog().notification("Aguarde", f"Buscando Dados: [COLOR yellow]{tmdb_info['title']}[/COLOR]", sound=False)
            video_url = f"plugin://plugin.video.jacktorr/play_magnet?magnet={magnet_link}"
        else:
            xbmcgui.Dialog().notification("Erro", "Player não reconhecido.")
            return

        # Configura a janela de reprodução
        play_item = xbmcgui.ListItem(path=video_url)
        play_item.setInfo(type="Video", infoLabels={
            "Title": tmdb_info.get('title', 'Sem título'),
            "Genre": tmdb_info.get('genres', [{'name': 'Desconhecido'}])[0]['name']
        })
        play_item.setArt({
            'poster': f"https://image.tmdb.org/t/p/w500{tmdb_info.get('poster_path', '')}",
            'fanart': f"https://image.tmdb.org/t/p/original{tmdb_info.get('backdrop_path', '')}"
        })

        # Inicia o player com o item configurado
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)

    except Exception as e:
        xbmcgui.Dialog().notification("Erro", f"Falha na reprodução: {str(e)}")

import xbmc
import xbmcvfs
import os
import json
import urllib.request
import threading
import time
import urllib.error
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta

# Variáveis globais (certifique-se de que estão definidas no escopo do seu addon)
# Exemplo: HANDLE = int(sys.argv[1])
# Exemplo: xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
# Exemplo: get_all_videos, create_video_item, get_url (necessitam ser funções definidas em outro lugar)

TMDB_API_KEY = 'f0b9cd2de131c900f5bb03a0a5776342'

# Garante que o diretório do cache exista para séries também
ADDON_DATA_PATH = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.cineroom/")
if not xbmcvfs.exists(ADDON_DATA_PATH):
    xbmcvfs.mkdir(ADDON_DATA_PATH)
    
SERIES_CACHE_PATH = os.path.join(ADDON_DATA_PATH, "popularity_series_cache.json")
CACHE_DURATION_DAYS = 3
REQUEST_DELAY_SECONDS = 0.1  # Atraso mínimo entre requisições para evitar rate limit

def get_tmdb_series_popularity(tmdb_id, retries=3, initial_delay=0.5):
    """
    Obtém a popularidade de uma série do TMDb, com tratamento de rate limiting
    e backoff exponencial.

    Args:
        tmdb_id (str): O ID da série no TMDb.
        retries (int): Número máximo de tentativas em caso de erro 429.
        initial_delay (float): Atraso inicial em segundos antes de uma nova tentativa.

    Returns:
        float or None: A popularidade da série ou None em caso de falha.
    """
    url = f'https://api.themoviedb.org/3/tv/{tmdb_id}?api_key={TMDB_API_KEY}&language=pt-BR'
    current_delay = initial_delay

    for i in range(retries):
        try:
            with urllib.request.urlopen(url, timeout=5) as response:
                data = json.loads(response.read().decode())
                return data.get('popularity')
        except urllib.error.HTTPError as e:
            if e.code == 429:  # Too Many Requests
                xbmc.log(f"TMDb Rate Limit excedido para série ID {tmdb_id} (Tentativa {i+1}/{retries}). "
                         f"Aguardando {current_delay:.2f}s...", xbmc.LOGWARNING)
                time.sleep(current_delay)
                current_delay *= 2  # Backoff exponencial
            else:
                xbmc.log(f"Erro HTTP ao obter popularidade do TMDb para série ID {tmdb_id}: {e.code} - {e.reason}", xbmc.LOGERROR)
                return None
        except urllib.error.URLError as e:  # Erros de rede (DNS, conexão, etc.)
            xbmc.log(f"Erro de rede ao obter popularidade do TMDb para série ID {tmdb_id}: {e.reason}", xbmc.LOGERROR)
            if i < retries - 1:
                time.sleep(current_delay)
                current_delay *= 2
            else:
                return None
        except json.JSONDecodeError as e:  # Erro ao decodificar JSON
            xbmc.log(f"Erro ao decodificar JSON da resposta do TMDb para série ID {tmdb_id}: {e}", xbmc.LOGERROR)
            return None
        except Exception as e:  # Qualquer outro erro inesperado
            xbmc.log(f"Erro inesperado ao obter popularidade do TMDb para série ID {tmdb_id}: {e}", xbmc.LOGERROR)
            return None

    xbmc.log(f"Falha ao obter popularidade do TMDb para série ID {tmdb_id} após {retries} tentativas.", xbmc.LOGERROR)
    return None

def load_series_popularity_cache():
    """
    Carrega o cache de popularidade de séries. Invalida o cache se estiver muito antigo.
    """
    if not xbmcvfs.exists(SERIES_CACHE_PATH):
        return {}
    try:
        with xbmcvfs.File(SERIES_CACHE_PATH, 'r') as f:
            data = json.loads(f.read())
        timestamp = datetime.fromisoformat(data.get('_timestamp', '2000-01-01'))
        if datetime.now() - timestamp > timedelta(days=CACHE_DURATION_DAYS):
            xbmc.log("Cache de popularidade de séries expirado, recarregando...", xbmc.LOGINFO)
            return {}
        return data.get('popularity', {})
    except Exception as e:
        xbmc.log(f"Erro ao carregar cache de popularidade de séries: {e}", xbmc.LOGERROR)
        return {}

def save_series_popularity_cache(popularity_data):
    """
    Salva os dados de popularidade de séries no cache.
    """
    try:
        with xbmcvfs.File(SERIES_CACHE_PATH, 'w') as f:
            f.write(json.dumps({
                '_timestamp': datetime.now().isoformat(),
                'popularity': popularity_data
            }, ensure_ascii=False))
    except Exception as e:
        xbmc.log(f"Erro ao salvar cache de popularidade de séries: {e}", xbmc.LOGERROR)
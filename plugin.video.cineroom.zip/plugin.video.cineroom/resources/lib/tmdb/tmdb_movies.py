import xbmc
import os
import json
import urllib.request
import threading
import time
import urllib.error
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
import xbmcvfs

# Variáveis globais (certifique-se de que estão definidas no escopo do seu addon)
# Exemplo: HANDLE = int(sys.argv[1])
# Exemplo: xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
# Exemplo: FILTERED_CACHE (necessita ser uma classe ou objeto com um método get_sorted)
# Exemplo: create_video_item, get_url (necessitam ser funções definidas em outro lugar)

TMDB_API_KEY = 'f0b9cd2de131c900f5bb03a0a5776342'
# Garante que o diretório do cache exista
ADDON_DATA_PATH = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.cineroom/")
if not xbmcvfs.exists(ADDON_DATA_PATH):
    xbmcvfs.mkdir(ADDON_DATA_PATH)
CACHE_PATH = os.path.join(ADDON_DATA_PATH, "popularity_cache.json")
CACHE_DURATION_DAYS = 7
REQUEST_DELAY_SECONDS = 0.1

# Define o número máximo de filmes para os quais você quer manter a popularidade atualizada
# Isso DEVE ser igual ou maior que o limite definido em sort_by_popularity
MAX_POPULARITY_UPDATE_LIMIT = 500 


def get_tmdb_popularity(tmdb_id, retries=3, initial_delay=0.2):
    """
    Obtém a popularidade de um filme do TMDb, com tratamento de rate limiting
    e backoff exponencial.

    Args:
        tmdb_id (str): O ID do filme no TMDb.
        retries (int): Número máximo de tentativas em caso de erro 429.
        initial_delay (float): Atraso inicial em segundos antes de uma nova tentativa.

    Returns:
        float or None: A popularidade do filme ou None em caso de falha.
    """
    url = f'https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={TMDB_API_KEY}&language=pt-BR'
    current_delay = initial_delay

    for i in range(retries):
        try:
            with urllib.request.urlopen(url, timeout=5) as response:
                data = json.loads(response.read().decode())
                return data.get('popularity')
        except urllib.error.HTTPError as e:
            if e.code == 429: # Too Many Requests
                xbmc.log(f"TMDb Rate Limit excedido para ID {tmdb_id} (Tentativa {i+1}/{retries}). "
                         f"Aguardando {current_delay:.2f}s...", xbmc.LOGWARNING)
                time.sleep(current_delay)
                current_delay *= 2  # Backoff exponencial
            else:
                xbmc.log(f"Erro HTTP ao obter popularidade do TMDb para ID {tmdb_id}: {e.code} - {e.reason}", xbmc.LOGERROR)
                return None
        except urllib.error.URLError as e: # Erros de rede (DNS, conexão, etc.)
            xbmc.log(f"Erro de rede ao obter popularidade do TMDb para ID {tmdb_id}: {e.reason}", xbmc.LOGERROR)
            if i < retries - 1: # Tentar novamente se não for a última tentativa
                time.sleep(current_delay)
                current_delay *= 2
            else:
                return None
        except json.JSONDecodeError as e: # Erro ao decodificar JSON
            xbmc.log(f"Erro ao decodificar JSON da resposta do TMDb para ID {tmdb_id}: {e}", xbmc.LOGERROR)
            return None
        except Exception as e: # Qualquer outro erro inesperado
            xbmc.log(f"Erro inesperado ao obter popularidade do TMDb para ID {tmdb_id}: {e}", xbmc.LOGERROR)
            return None

    xbmc.log(f"Falha ao obter popularidade do TMDb para ID {tmdb_id} após {retries} tentativas.", xbmc.LOGERROR)
    return None

def load_popularity_cache():
    """
    Carrega o cache de popularidade. Invalida o cache se estiver muito antigo.
    """
    if not xbmcvfs.exists(CACHE_PATH):
        return {}
    try:
        with xbmcvfs.File(CACHE_PATH, 'r') as f:
            data = json.loads(f.read())
        timestamp = datetime.fromisoformat(data.get('_timestamp', '2000-01-01'))
        if datetime.now() - timestamp > timedelta(days=CACHE_DURATION_DAYS):
            xbmc.log("Cache de popularidade expirado, recarregando...", xbmc.LOGINFO)
            return {}
        return data.get('popularity', {})
    except Exception as e:
        xbmc.log(f"Erro ao carregar cache de popularidade: {e}", xbmc.LOGERROR)
        return {}

def save_popularity_cache(popularity_data):
    """
    Salva os dados de popularidade no cache.
    """
    try:
        with xbmcvfs.File(CACHE_PATH, 'w') as f:
            f.write(json.dumps({
                '_timestamp': datetime.now().isoformat(),
                'popularity': popularity_data
            }, ensure_ascii=False))
    except Exception as e:
        xbmc.log(f"Erro ao salvar cache de popularidade: {e}", xbmc.LOGERROR)
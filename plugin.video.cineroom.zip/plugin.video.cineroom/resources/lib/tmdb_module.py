import xbmcaddon
import urllib.request
import json
import xbmcgui
import xbmc
from concurrent.futures import ThreadPoolExecutor, as_completed

addon = xbmcaddon.Addon()

def get_tmdb_api_key():
    """Retorna a chave da API do TMDb configurada no addon."""
    return addon.getSetting("tmdb_api_key") or 'f0b9cd2de131c900f5bb03a0a5776342'

def fetch_tmdb_data(url):
    """Função para fazer a requisição à API do TMDb e retornar os dados."""
    try:
        response = urllib.request.urlopen(url)
        return json.loads(response.read().decode('utf-8'))
    except Exception as e:
        xbmc.log(f"Erro ao acessar o TMDb: {str(e)}", xbmc.LOGERROR)
        return None

movie_cache = {}

def get_movie_info_from_tmdb(tmdb_id, titulo_original=None):
    """Obtém informações detalhadas sobre um filme utilizando o TMDb."""
    tmdb_url = f'https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={get_tmdb_api_key()}&language=pt-BR'
    data = fetch_tmdb_data(tmdb_url)
    
    if not data:
        mensagem_erro = (
            f"Erro ao obter informações para '{titulo_original}' (ID: {tmdb_id}).\n"
            "[COLOR yellow]Informe ao desenvolvedor sobre esse erro![/COLOR]"
        ) if titulo_original else (
            f"Erro: ID {tmdb_id} não encontrado ou inválido.\n"
            "[COLOR yellow]Informe ao desenvolvedor sobre esse erro![/COLOR]"
        )
        xbmcgui.Dialog().ok('Erro TMDb', mensagem_erro)
        return None
    return data

def fetch_multiple_movie_info(tmdb_ids):
    """Função para buscar informações de vários filmes usando múltiplas threads."""
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = {executor.submit(get_movie_info_from_tmdb, tmdb_id): tmdb_id for tmdb_id in tmdb_ids}
        results = {}
        
        for future in as_completed(futures):
            tmdb_id = futures[future]
            try:
                result = future.result()
                if result:
                    results[tmdb_id] = result
            except Exception as e:
                xbmc.log(f"Erro ao buscar informações para o ID {tmdb_id}: {str(e)}", xbmc.LOGERROR)
        
        return results

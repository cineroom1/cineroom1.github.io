import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import xbmcaddon
import json
import sys

from urllib.parse import urlencode, parse_qsl
from xbmcaddon import Addon
from xbmcvfs import translatePath



URL = sys.argv[0]
HANDLE = int(sys.argv[1])

FAVORITES_FILE = os.path.join(xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.cineroom/"), "favorites.json")

def get_url(**kwargs):
    """
    Cria uma URL para chamar o plugin recursivamente a partir dos argumentos fornecidos.
    """
    return '{}?{}'.format(URL, urlencode(kwargs))

def add_to_favorites(video):
    """
    Adiciona um vídeo ou série à lista de favoritos.
    """
    favorites = load_favorites()
    
    # Verifica se o vídeo já está nos favoritos
    if any(fav['title'] == video['title'] for fav in favorites):
        xbmcgui.Dialog().notification("Minha Lista", f"{video['title']} já está na sua lista!", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Adiciona o vídeo à lista de favoritos
    favorites.append(video)
    save_favorites(favorites)
    xbmcgui.Dialog().notification("Minha Lista", f"{video['title']} adicionado a sua lista!", xbmcgui.NOTIFICATION_INFO, 3000)

def load_favorites():
    """
    Carrega a lista de favoritos a partir do arquivo JSON.
    """
    if not os.path.exists(FAVORITES_FILE):
        return []

    try:
        with open(FAVORITES_FILE, 'r') as file:
            return json.load(file)
    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Erro ao carregar favoritos: {e}')
        return []

def save_favorites(favorites):
    """
    Salva a lista de favoritos em um arquivo JSON.
    """
    try:
        os.makedirs(os.path.dirname(FAVORITES_FILE), exist_ok=True)
        with open(FAVORITES_FILE, 'w') as file:
            json.dump(favorites, file)
    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Erro ao salvar favoritos: {e}')

def remove_from_favorites(video):
    """
    Remove um vídeo ou série da lista de favoritos.
    """
    favorites = load_favorites()
    
    # Filtra a lista de favoritos, removendo o vídeo
    updated_favorites = [fav for fav in favorites if fav['title'] != video['title']]
    
    if len(updated_favorites) == len(favorites):
        xbmcgui.Dialog().notification("Sua Lista", f"{video['title']} não está na sua lista!", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Salva a lista atualizada
    save_favorites(updated_favorites)
    xbmcgui.Dialog().notification("Minha Lista", f"{video['title']} removido da sua lista!", xbmcgui.NOTIFICATION_INFO, 3000)

def list_favorites():
    """
    Lista os vídeos e séries favoritados.
    """
    from resources.action.video_listing import create_video_item
    
    favorites = load_favorites()
    if not favorites:
        xbmcgui.Dialog().ok('Favoritos', 'Nenhum item encontrado na lista!')
        return

    xbmcplugin.setPluginCategory(HANDLE, 'Minha Lista')
    xbmcplugin.setContent(HANDLE, 'movies')

    for video in favorites:
        list_item, url, is_folder = create_video_item(video)
        
        # Adiciona um menu de contexto para remover dos favoritos
        list_item.addContextMenuItems([
            ('Remover da sua Lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(video))})')
        ])
        
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)
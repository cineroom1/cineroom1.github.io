def handle_select_genre():
    """
    Exibe as pastas de gêneros. Quando o usuário seleciona um gênero, lista os filmes daquele gênero.
    """
    genres = [
        "Animação", "Aventura", "Ação", "Cinema TV", "Comédia", "Crime",
        "Documentário", "Drama", "Família", "Fantasia", "Faroeste", "Ficção científica",
        "Guerra", "História", "Mistério", "Música", "Romance", "Terror", "Thriller"
    ]

    # Exibe as pastas de gêneros
    for genre in genres:
        list_item = xbmcgui.ListItem(label=genre)
        list_item.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})  # Ícones de pasta padrão
        url = get_url(action='listar_filmes_por_genero', genero=genre)
        is_folder = True  # Indica que é uma pasta (não um item de vídeo)

        # Adiciona a pasta ao diretório do plugin
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=is_folder)

    # Finaliza a exibição das pastas de gêneros
    xbmcplugin.endOfDirectory(handle)

def listar_filmes_por_genero(genero):
    """
    Lista os filmes de um gênero específico extraindo da URL fornecida.
    """
    xbmcplugin.setPluginCategory(handle, f'Gênero: {genero}')
    xbmcplugin.setContent(handle, 'movies')

    # Carrega os filmes do arquivo JSON (exemplo de URL, substitua pela real)
    filmes = fetch_data_from_url('https://raw.githubusercontent.com/Gael1303/cn/refs/heads/main/main/random.json')

    # Filtra os filmes que contêm o gênero selecionado
    filmes_filtrados = [filme for filme in filmes.get('movies', []) if genero.lower() in filme.get('genres', '').lower()]

    # Exibe os filmes filtrados
    for filme in filmes_filtrados:
        titulo = filme['title']
        tmdb_id = filme['tmdb_id']
        video_url = filme['url']
        poster_path = filme.get('poster', '')
        backdrop_path = filme.get('backdrop', '')

        # Cria o item de lista para o filme
        list_item = xbmcgui.ListItem(label=titulo)
        list_item.setArt({
            'poster': poster_path,
            'fanart': backdrop_path
        })

        # Informações do vídeo
        info_tag = list_item.getVideoInfoTag()
        info_tag.setMediaType('movie')
        info_tag.setTitle(titulo)
        info_tag.setYear(filme.get('year', 0))
        info_tag.setGenres(filme.get('genres', '').split(", "))
        info_tag.setRating(0)  # O rating pode ser adicionado se disponível
        info_tag.setDuration(0)  # O tempo de duração pode ser adicionado se disponível

        # Define como item reproduzível
        list_item.setProperty('IsPlayable', 'true')

        # URL para reprodução do vídeo
        video_url = get_url(action='play', video=video_url, movie_id=tmdb_id)
        is_folder = False

        # Adiciona o item ao diretório com o handle corretamente definido
        xbmcplugin.addDirectoryItem(handle=handle, url=video_url, listitem=list_item, isFolder=is_folder)

    # Finaliza a exibição dos filmes
    xbmc.executebuiltin('Container.SetViewMode(50)')
    xbmcplugin.endOfDirectory(handle)
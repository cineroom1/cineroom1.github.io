from concurrent.futures import ThreadPoolExecutor, as_completed
import xbmc
import xbmcgui
import xbmcplugin

# Dicionário de cache para armazenar informações do TMDb
tmdb_cache = {}

def get_movie_info_cached(tmdb_id, get_movie_info_from_tmdb):
    """Tenta pegar informações do cache. Se não estiver no cache, chama a API do TMDb."""
    if tmdb_id in tmdb_cache:
        return tmdb_cache[tmdb_id]
    info = get_movie_info_from_tmdb(tmdb_id)
    if info:
        tmdb_cache[tmdb_id] = info
    return info

def search_movies(handle, videos, get_videos_from_category, get_url):
    """
    Permite que o usuário busque filmes na lista de vídeos fornecida (sem depender da URL da categoria).
    """
    # Exibe a seleção de critério de busca
    option = choose_search_option()
    if option is None:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return  # Sai se o usuário cancelar e retorna ao menu do addon

    # Lista fixa de estúdios
    studios = [
        "Universal Pictures", "Warner Bros.", "Paramount Pictures", "Sony Pictures",
        "20th Century Studios", "Walt Disney Pictures", "Pixar", "DreamWorks Animation",
        "Columbia Pictures", "Legendary Pictures", "DC Comics", "A24", "Marvel Studios",
        "MGM", "Lionsgate", "New Line Cinema", "Original Film", "Fox 2000 Pictures", 
        "Sunday Night Productions", "Blue Sky Studios", "Lucasfilm Ltd.", "Blumhouse Productions",
        "Skydance Media"
        ]

    # Lista fixa de anos
    years = [str(year) for year in range(2000, 2025)]  # Exemplo: anos de 2000 até 2024

    # Lógica de entrada de busca com base no critério
    if option == 'Por Estúdio':
        dialog = xbmcgui.Dialog()
        selected_studio = dialog.select('Escolha um Estúdio:', studios)
        if selected_studio == -1:  # Usuário cancelou
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return  # Sai e retorna ao menu do addon
        search_query = studios[selected_studio].lower()
    elif option == 'Por Ano':
        dialog = xbmcgui.Dialog()
        selected_year = dialog.select('Escolha um Ano:', years)
        if selected_year == -1:  # Usuário cancelou
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return  # Sai e retorna ao menu do addon
        search_query = years[selected_year]
    else:
        keyboard = xbmc.Keyboard('', f'Digite o {option.lower()} para pesquisa:')
        keyboard.doModal()

        if not keyboard.isConfirmed():
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return  # Sai e retorna ao menu do addon

        search_query = keyboard.getText().lower()
        if not search_query:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return  # Sai e retorna ao menu do addon

    # Filtrar os vídeos pelo critério selecionado
    if option == 'Por Nome':
        filtered_videos = filter_videos_by_name(videos, search_query)
    elif option == 'Por Ano':
        filtered_videos = filter_videos_by_year(videos, search_query)
    elif option == 'Por Ator':
        filtered_videos = filter_videos_by_actor(videos, search_query)
    elif option == 'Por Diretor':
        filtered_videos = filter_videos_by_director(videos, search_query)
    elif option == 'Por Estúdio':
        filtered_videos = filter_videos_by_studio(videos, search_query)
    else:
        filtered_videos = []

    # Exibe os resultados
    if filtered_videos:
        xbmcplugin.setPluginCategory(handle, f'Resultados para {option}: {search_query}')
        xbmcplugin.setContent(handle, 'movies')

        for video in filtered_videos:
            # Cria o item da lista com informações de `poster` e `backdrop`
            list_item = xbmcgui.ListItem(label=video.get('title', 'Título desconhecido'))
            list_item.setArt({
                'poster': video.get('poster', ''),
                'fanart': video.get('backdrop', ''),
            })

            video_info = {
                'title': video.get('title', 'Título desconhecido'),
                'year': video.get('year', 0),
                'genre': ", ".join(video.get('genres', '').split(',')),
                'cast': [actor.strip() for actor in video.get('actors', '').split(',')],
                'director': video.get('director', 'Desconhecido'),
                'studio': video.get('studio', ''),  # Estúdio (caso exista)
                'rating': video.get('rating', ''),  # Nota do filme
                'mediatype': 'movie'
            }
            list_item.setInfo('video', video_info)
            list_item.setProperty('IsPlayable', 'true')
            url = get_url(action='play', video=video['url'], movie_id=video.get('tmdb_id', ''))
            is_folder = False
            xbmcplugin.addDirectoryItem(handle, url, list_item, is_folder)

        xbmcplugin.endOfDirectory(handle)
    else:
        xbmcgui.Dialog().notification('Resultado', 'Nenhum filme encontrado com esse critério de pesquisa.', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(handle, succeeded=False)

def choose_search_option():
    """
    Exibe uma janela para o usuário selecionar o critério de busca.
    Retorna a opção selecionada ou None se o usuário cancelar.
    """
    options = ['Por Nome', 'Por Ano', 'Por Ator', 'Por Diretor', 'Por Estúdio']
    dialog = xbmcgui.Dialog()
    selected_index = dialog.select('Escolha o critério de busca:', options)
    
    if selected_index == -1:  # Se o usuário cancelar
        return None
    
    return options[selected_index]


def filter_videos_by_name(videos, search_query):
    """Filtra os vídeos por nome."""
    return [video for video in videos if 'title' in video and search_query in video['title'].lower()]

def filter_videos_by_year(videos, search_query):
    """Filtra os vídeos por ano."""
    return [video for video in videos if 'year' in video and search_query == str(video['year'])]

def filter_videos_by_actor(videos, search_query):
    """Filtra os vídeos por ator."""
    return [video for video in videos if 'actors' in video and any(search_query in actor.strip().lower() for actor in video['actors'].lower().split(','))]

def filter_videos_by_director(videos, search_query):
    """Filtra os vídeos por diretor."""
    return [video for video in videos if 'director' in video and search_query in video['director'].lower()]

def filter_videos_by_studio(videos, search_query):
    """Filtra os vídeos pelo estúdio."""
    return [
        video for video in videos
        if 'studio' in video and video['studio'] and search_query in video['studio'].lower()
    ]

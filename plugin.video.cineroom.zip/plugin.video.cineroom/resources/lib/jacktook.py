import xbmc
import xbmcgui
import xbmcplugin
import sys
import json
from urllib.parse import quote_plus, urlencode

HANDLE = int(sys.argv[1])

# --- Funções do Jacktook (mantidas ou importadas) ---
def is_jacktook_installed():
    """Verifica se o Jacktook está instalado."""
    return xbmc.getCondVisibility('System.HasAddon(plugin.video.jacktook)')

def search_jacktook(title, tmdb_id=None, tvdb_id=None, imdb_id=None, content_type='movie'):
    """
    Inicia uma busca no Jacktook com base no título e IDs fornecidos,
    imitando a chamada do TMDb Helper.
    """
    if not is_jacktook_installed():
        xbmcgui.Dialog().notification('Jacktook não instalado', 'O Jacktook não foi encontrado.', xbmcgui.NOTIFICATION_ERROR)
        return

    ids_dict = {
        "tmdb_id": str(tmdb_id) if tmdb_id else "", # Mude None para string vazia para o Jacktook
        "tvdb_id": str(tvdb_id) if tvdb_id else "",
        "imdb_id": str(imdb_id) if imdb_id else ""
    }

    # Converta o dicionário de IDs para uma string JSON e, em seguida, codifique para URL
    json_ids_string = json.dumps(ids_dict)
    
    # O urlencode vai lidar com o json_ids_string
    # A estrutura original que você mostrou no início:
    # "ids=%7B%22tmdb_id%22%3A+%22{tmdb}%22%2C+%22tvdb_id%22%3A+%22{tvdb}%22%2C+%22imdb_id%22%3A+%22{imdb}%22%7D"
    # é um JSON já url-encoded. Para replicar isso, precisamos de um passo a mais.
    
    # Uma forma mais robusta de construir a URL do Jacktook
    base_url = "plugin://plugin.video.jacktook/?"
    query_params = {
        "action": "search",
        "mode": "movies", # Fixado para filmes
        "rescrape": "True",
        "query": title,
        "ids": json_ids_string # Passa a string JSON para ser codificada
    }
    
    # Use urlencode para formatar os parâmetros da URL
    encoded_params = urlencode(query_params)
    jacktook_url = f"{base_url}{encoded_params}"

    xbmc.log(f"[SEU_ADDON] Chamando Jacktook com URL: {jacktook_url}", xbmc.LOGDEBUG)

    # Não chame setResolvedUrl aqui, pois a função será chamada por handle_jacktook_search_movie
    # e ela só retorna a URL para ser reproduzida.
    xbmc.executebuiltin(f"RunPlugin({jacktook_url})") # Executa o Jacktook diretamente


# --- NOVA FUNÇÃO PARA TRATAR A BUSCA DE FILMES NO JACKTOOK ---
def handle_jacktook_search_movie(title, tmdb_id, imdb_id):
    """
    Função que lida com a opção de busca no Jacktook para filmes.
    Apenas chama a função search_jacktook.
    """
    xbmc.log(f"[SEU_ADDON] Iniciando busca de filme no Jacktook para: {title} (TMDB ID: {tmdb_id})", xbmc.LOGINFO)
    search_jacktook(title=title, tmdb_id=tmdb_id, imdb_id=imdb_id, content_type='movie')
    return True # Indica que a ação foi iniciada
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import re
import sys

from urllib.request import urlopen
from datetime import datetime
import urllib.request
import json
import subprocess
from urllib.parse import parse_qsl

from resources.lib.utils import get_json_data, get_url
from resources.lib.player import play_video
from resources.lib.menu import TVSHOWS_URLS, URL_TENDENCIA


HANDLE = int(sys.argv[1])


def list_tendencia(category_name):
    xbmcplugin.setContent(HANDLE, 'movies')
    if category_name:
        xbmcplugin.setPluginCategory(HANDLE, category_name)

    """Lista filmes e séries populares misturados na categoria 'Tendências'."""

    data = get_json_data(URL_TENDENCIA)  # Usando a URL definida fora da função

    if not data:
        return  # Se falhar, a função já lida com erro

    # Verifica se o primeiro item é um dicionário com a chave "status"
    if isinstance(data[0], dict) and data[0].get("status", "").lower() == "off":
        xbmcgui.Dialog().notification("Acesso Negado", "A lista está em manutenção!", xbmcgui.NOTIFICATION_WARNING, 3000)
        return  # Encerra a função sem listar os itens

    # Remove o item de status para processar apenas os filmes
    data = data[1:]   

    for item in data:
        title = item.get("title", "Sem título")  # Pegando corretamente o título
        poster = item.get("poster", "")
        backdrop = item.get("backdrop", "")
        studio = item.get("studio", "Desconhecido")
        year = item.get("year", 0)  # Se não existir, define como 0
        rating = item.get("rating", item.get("rate", 0))
        genres = item.get("genres", "")
        duration = item.get("runtime", 0)
        sinopse = item.get("synopsis", item.get("sinopse", "Sem sinopse disponível"))
        clearlogo = item.get("clearlogo", "").strip()  # Remove espaços extras para evitar strings vazias
        is_series = "temporadas" in item
        
        list_item = xbmcgui.ListItem(label=f"{title}")
        list_item.setArt({
            "poster": poster, 
            "fanart": backdrop
        })
        
        # Só adiciona o ClearLogo se não estiver vazio
        if clearlogo:
            art["clearlogo"] = clearlogo
        
        list_item.setInfo("video", {
            "title": title,
            "year": year,
            "rating": rating,
            "genre": genres,
            "plot": sinopse,
            "studio": studio,
            "duration": duration  # Adiciona duração do filme
        })

        if is_series:
            url = get_url(action='list_seasons', serie=title, tipo='serie')
            list_item.setProperty("IsPlayable", "false")
        else:
            video_urls = json.dumps(item["url"])
            url = f"{sys.argv[0]}?action=play&video={urllib.parse.quote(video_urls)}"
            list_item.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=is_series)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def list_seasons(serie):
    """Lista as temporadas de uma série."""
    xbmcplugin.setContent(HANDLE, 'tvshows')
    
    data = get_json_data(URL_TENDENCIA)  # Usando a URL definida fora da função
    
    if not data:
        return  # Se falhar, a função já lida com erro
    
    # Procura a série específica no JSON
    for item in data:
        if item.get("title") == serie and "temporadas" in item:
            temporadas = item["temporadas"]
            for temporada in temporadas:
                title = temporada.get("title", "Temporada Desconhecida")
                poster = temporada.get("poster", item.get("poster", ""))
                url = get_url(action='list_episodes', serie=serie, temporada=title)
                
                list_item = xbmcgui.ListItem(label=title)
                list_item.setArt({"poster": poster})
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)
            
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            return  # Sai da função após encontrar a série

def list_episodes(serie, temporada, ano_serie="Desconhecido"):
    """Lista os episódios de uma temporada."""
    xbmcplugin.setContent(HANDLE, 'episodes')

    data = get_json_data(URL_TENDENCIA)  # Usando a URL definida fora da função

    if not data:
        xbmcgui.Dialog().notification("Erro", "Falha ao obter os episódios.", xbmcgui.NOTIFICATION_ERROR)
        return

    serie_encontrada = False

    for item in data:
        if item.get("title") == serie and "temporadas" in item:
            serie_encontrada = True
            ano_serie = item.get("ano", "Desconhecido")  # Obtém o ano da série
            serie_title = item.get("title", "Título Desconhecido")
            
            for temp in item["temporadas"]:
                if temp.get("title") == temporada:
                    episodios = temp.get("episodios", [])

                    if not episodios:
                        xbmcgui.Dialog().notification("Aviso", "Nenhum episódio disponível.", xbmcgui.NOTIFICATION_WARNING)
                        return
                    
                    for idx, episodio in enumerate(episodios, start=1):
                        title = episodio.get("title", "Episódio Desconhecido")
                        video_url = episodio.get("url", "")
                        ano = episodio.get("ano", ano_serie)  # Usa o ano da série se o episódio não tiver
                        sinopse = episodio.get("sinopse", "Sem sinopse")
                        poster = episodio.get('poster', '')  # Obtém o poster da temporada
                        rate = episodio.get("rate", 0)  # Obtém a nota do episódio
                        resume_time = episodio.get("resume_time", 0)  # Tempo de reprodução salvo

                        # Extrai apenas o número da temporada (ex: "1ª Temporada" -> 1)
                        match = re.search(r'\d+', temporada)
                        num_temp = int(match.group()) if match else 1

                        # Formata o nome do episódio no estilo desejado
                        nome_formatado = f"{serie_title}\nS{num_temp:02d} - {title}"

                        list_item = xbmcgui.ListItem(label=nome_formatado)
                        list_item.setProperty("IsPlayable", "true")
                        list_item.setArt({'poster': poster, 'thumb': poster})
                        list_item.setInfo('video', {
                            'title': title,
                            'year': ano,
                            'plot': sinopse,
                            'rating': rate,  
                            'mediatype': 'episode'
                        })

                        # Adiciona suporte para retomar a reprodução
                        if resume_time > 0:
                            list_item.setProperty("ResumeTime", str(resume_time))

                        url = get_url(action='play', video=json.dumps(video_url))
                        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)
                    
                    xbmcplugin.endOfDirectory(int(sys.argv[1]))
                    return  # Sai da função após encontrar a temporada

    if not serie_encontrada:
        xbmcgui.Dialog().notification("Erro", "Série não encontrada.", xbmcgui.NOTIFICATION_ERROR)


def list_conteudo(tipo):
    """
    Lista séries, novelas ou animes de acordo com o tipo especificado.
    """
    url_conteudo = TVSHOWS_URLS.get(tipo)
    if not url_conteudo:
        xbmcgui.Dialog().ok('Erro', 'Tipo de conteúdo inválido!')
        return

    xbmcplugin.setContent(HANDLE, 'tvshows')

    try:
        response = urlopen(url_conteudo)
        data = response.read().decode('utf-8')
        conteudos = json.loads(data)
        print(json.dumps(conteudos, indent=4, ensure_ascii=False))  # Ver JSON no log

        if isinstance(conteudos[0], dict):
            status = conteudos[0].get("status", "").lower()

            if status == "off":
                xbmcgui.Dialog().notification("Aguarde...", f"A lista de {tipo} está em manutenção!", xbmcgui.NOTIFICATION_WARNING, 3000)
                return

            elif status == "+18":
               senha_correta = "2025"  # Defina a senha desejada
               senha_digitada = xbmcgui.Dialog().input("Conteúdo +18. Digite a senha:", type=xbmcgui.INPUT_NUMERIC)
        
               if senha_digitada != senha_correta:
                    xbmcgui.Dialog().ok("Acesso Negado", "Senha incorreta. Você não tem permissão para acessar este conteúdo.")
                    return

        conteudos = conteudos[1:]  # Removendo o primeiro item após a verificação


        for conteudo in conteudos:
            nome = conteudo['title']
            sinopse = conteudo.get('sinopse', 'Sinopse não disponível')
            poster = conteudo.get('poster', '')
            backdrop = conteudo.get('backdrop', '')
            studio = conteudo.get('studio', 'Desconhecido')
            genres = conteudo.get('genres', [])
            nota = conteudo.get('rate', '0')
            ano = conteudo.get('year', 'Desconhecido')
            aired = conteudo.get('aired', 'Desconhecido')

            list_item = xbmcgui.ListItem(label=nome)
            list_item.setArt({'poster': poster, 'thumb': poster, 'fanart': backdrop})
            list_item.setInfo('video', {
                'title': nome,
                'plot': sinopse,
                'rating': nota,
                'year': ano,
                'studio': studio,
                'genre': ', '.join(genres),
                'premiered': aired,
                'mediatype': 'tvshow'
            })
            list_item.setProperty('mediatype', 'tvshows')

            url = get_url(action='listar_temporadas', serie=nome, tipo=tipo)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)

        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.endOfDirectory(HANDLE)

    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Não foi possível carregar {tipo}: {str(e)}')


def listar_temporadas(serie_nome, tipo):
    xbmcplugin.setContent(HANDLE, 'seasons')
    
    url_conteudo = TVSHOWS_URLS.get(tipo)
    if not url_conteudo:
        xbmcgui.Dialog().ok('Erro', 'Tipo de conteúdo inválido!')
        return

    try:
        response = urlopen(url_conteudo)
        data = response.read().decode('utf-8')
        conteudos = json.loads(data)
        
        for conteudo in conteudos:
            if conteudo.get('title') == serie_nome:
                temporadas = conteudo.get('temporadas', [])  # Garante que seja uma lista vazia se não existir
        
                if not temporadas:
                    xbmcgui.Dialog().ok('Erro', f'Sem temporadas disponíveis para {serie_nome}')
                    return
        
                for temporada in temporadas:
                    titulo = temporada.get('title', 'Temporada Desconhecida')  # Evita erro
                    poster = temporada.get('poster', '')

                    list_item = xbmcgui.ListItem(label=titulo)
                    list_item.setArt({'poster': poster, 'thumb': poster})
                    list_item.setInfo('video', {'title': titulo, 'mediatype': 'season'})

                    url = get_url(action='listar_episodios', serie=serie_nome, temporada=titulo, tipo=tipo)
                    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)


        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Não foi possível carregar as temporadas: {str(e)}')


def listar_episodios(serie_nome, temporada_nome, tipo):
    xbmcplugin.setContent(HANDLE, 'episodes')
    
    url_conteudo = TVSHOWS_URLS.get(tipo)
    if not url_conteudo:
        xbmcgui.Dialog().ok('Erro', 'Tipo de conteúdo inválido!')
        return

    try:
        response = urlopen(url_conteudo)
        data = response.read().decode('utf-8')
        conteudos = json.loads(data)
        
        conteudos = conteudos[1:]  # Ignorar a primeira entrada da lista

        for conteudo in conteudos:
            if conteudo['title'] == serie_nome:
                for temporada in conteudo['temporadas']:
                    if temporada['title'] == temporada_nome:
                        for index, episodio in enumerate(temporada['episodios'], start=1):
                            titulo = episodio['title']
                            video_url = episodio['url']
                            sinopse = episodio.get('sinopse', 'Sinopse não disponível')
                            duracao = episodio.get('duracao', 0)  # Em segundos
                            nota = episodio.get('rate', '0')
                            ano = conteudo.get('year', 'Desconhecido')

                            list_item = xbmcgui.ListItem(label=titulo)
                            list_item.setArt({'poster': temporada.get('poster', '')})
                            list_item.setProperty('IsPlayable', 'true')
                            list_item.setInfo('video', {
                                'title': titulo,
                                'plot': sinopse,
                                'duration': duracao,
                                'rating': nota,
                                'year': ano,
                                'season': temporada_nome,
                                'episode': index,
                                'mediatype': 'episode'
                            })

                            url = get_url(action='play', video=json.dumps(video_url))
                            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)
        
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Não foi possível carregar os episódios: {str(e)}')


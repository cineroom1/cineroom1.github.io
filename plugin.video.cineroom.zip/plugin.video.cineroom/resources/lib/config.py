import xbmcaddon
import xbmcgui
import urllib.request
import json

# Variável para ativar/desativar o login
ENABLE_LOGIN = False  # Defina como True para ativar o login
MAX_ATTEMPTS = 2  # Número máximo de tentativas

def fetch_credentials():
    """Obtém as credenciais do JSON remoto."""
    from main import CREDENTIALS_URL
    try:
        with urllib.request.urlopen(CREDENTIALS_URL) as response:
            credentials = json.load(response)

            # Verifica se o JSON contém as credenciais corretamente
            if isinstance(credentials, dict) and "user" in credentials and "password" in credentials:
                return credentials["user"], credentials["password"]
            else:
                xbmcgui.Dialog().ok("Erro", "Formato inválido do arquivo de credenciais.")
                return None, None
    except urllib.error.URLError as e:
        xbmcgui.Dialog().ok("Erro de Rede", f"Erro ao conectar ao servidor: {e}")
    except json.JSONDecodeError as e:
        xbmcgui.Dialog().ok("Erro de JSON", f"Erro ao decodificar o arquivo de credenciais: {e}")
    except Exception as e:
        xbmcgui.Dialog().ok("Erro", f"Erro inesperado: {e}")

    return None, None  # Retorna None em caso de erro

def login():
    """Solicita login ao usuário e valida com as credenciais remotas."""
    global ENABLE_LOGIN
    if not ENABLE_LOGIN:
        return True  # Login desativado, permite acesso

    addon = xbmcaddon.Addon()
    
    # Verifica credenciais já salvas no Kodi
    saved_user = addon.getSetting("saved_user")
    saved_password = addon.getSetting("saved_password")

    # Obtém credenciais do servidor
    USERNAME, PASSWORD = fetch_credentials()
    if not USERNAME or not PASSWORD:
        return False  # Não conseguiu obter credenciais remotas

    # Se credenciais salvas forem válidas, acesso direto
    if saved_user == USERNAME and saved_password == PASSWORD:
        return True

    # Se as credenciais mudaram ou não existem, solicitar login
    for attempt in range(MAX_ATTEMPTS):
        user_input = xbmcgui.Dialog().input("Digite o nome de usuário:", type=xbmcgui.INPUT_ALPHANUM)
        pass_input = xbmcgui.Dialog().input("Digite a senha:", type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)

        if user_input == USERNAME and pass_input == PASSWORD:
            addon.setSetting("saved_user", USERNAME)
            addon.setSetting("saved_password", PASSWORD)
            return True  # Login bem-sucedido

        xbmcgui.Dialog().ok("Erro", "Credenciais inválidas. Tente novamente.")

    xbmcgui.Dialog().ok("Erro", "Número máximo de tentativas atingido. Acesso negado.")
    return False  # Falha no login

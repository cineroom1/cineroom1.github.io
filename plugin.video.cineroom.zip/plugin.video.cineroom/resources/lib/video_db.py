class VideoDatabase:
    def __init__(self):
        self.videos = []  # Lista de vídeos
        self.title_index = {}  # Índice por título
        self.year_index = {}  # Índice por ano
        self.genre_index = {}  # Índice por gênero
        self.actor_index = {}  # Índice por ator

    def add_video(self, video):
        self.videos.append(video)
        
        # Índice por título
        self.title_index[video['title'].lower()] = video
        
        # Índice por ano
        if video['year'] not in self.year_index:
            self.year_index[video['year']] = []
        self.year_index[video['year']].append(video)
        
        # Índice por gênero
        for genre in video['genres']:
            genre = genre.lower()
            if genre not in self.genre_index:
                self.genre_index[genre] = []
            self.genre_index[genre].append(video)
        
        # Índice por ator
        for actor in video['actors'].split(','):
            actor = actor.strip().lower()
            if actor not in self.actor_index:
                self.actor_index[actor] = []
            self.actor_index[actor].append(video)
    
    def get_videos_by_title(self, title):
        return [video for video in self.videos if title.lower() in video['title'].lower()]
    
    def get_videos_by_year(self, year):
        return self.year_index.get(year, [])
    
    def get_videos_by_genre(self, genre):
        return self.genre_index.get(genre.lower(), [])
    
    def get_videos_by_actor(self, actor):
        return self.actor_index.get(actor.lower(), [])
        
# Função para carregar os vídeos do JSON
def load_videos_from_json(json_data):
    video_db = VideoDatabase()
    for video in json_data:
        video_db.add_video(video)
    return video_db

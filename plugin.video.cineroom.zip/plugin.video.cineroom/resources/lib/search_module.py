import xbmc
import xbmcgui
import xbmcplugin

def search_movies(handle, categories, get_videos_from_category, get_movie_info_from_tmdb, get_url):
    """
    Permite que o usuário busque filmes em todas as categorias e exibe os resultados ordenados por ano.
    """
    # Exibe o teclado para o usuário inserir o nome do filme
    keyboard = xbmc.Keyboard('', 'Digite o nome do filme:')
    keyboard.doModal()

    if not keyboard.isConfirmed():
        return  # Se o usuário não confirmou a entrada, sai da função

    search_query = keyboard.getText().lower()
    if not search_query:
        return  # Se a busca está vazia, não faz nada

    filtered_videos = []

    # Percorre as categorias e filtra os vídeos que correspondem à busca
    for url in categories:
        videos = get_videos_from_category(url)
        filtered_videos.extend([video for video in videos if 'title' in video and search_query in video['title'].lower()])

    # Remove duplicados com base no `tmdb_id`
    filtered_videos = list({video['tmdb_id']: video for video in filtered_videos}.values())

    # Obtém informações do TMDb e organiza os filmes por ano de lançamento
    movies_with_info = []
    for video in filtered_videos:
        tmdb_info = get_movie_info_from_tmdb(video['tmdb_id'])
        if tmdb_info:
            movies_with_info.append((video, tmdb_info))

    # Ordena os filmes por ano de lançamento, do mais recente para o mais antigo
    movies_with_info.sort(key=lambda x: x[1].get('release_date', ''), reverse=True)

    # Exibe os resultados da busca
    if movies_with_info:
        xbmcplugin.setPluginCategory(handle, 'Resultados da Busca')
        xbmcplugin.setContent(handle, 'movies')

        for video, tmdb_info in movies_with_info:
            list_item = xbmcgui.ListItem(label=tmdb_info['title'])
            list_item.setArt({
                'poster': f"https://image.tmdb.org/t/p/w500{tmdb_info['poster_path']}",
                'fanart': f"https://image.tmdb.org/t/p/w1280{tmdb_info['backdrop_path']}"
            })
            info_tag = list_item.getVideoInfoTag()
            info_tag.setMediaType('movie')
            info_tag.setTitle(tmdb_info['title'])
            info_tag.setPlot(tmdb_info['overview'])
            info_tag.setYear(int(tmdb_info['release_date'].split('-')[0]) if tmdb_info.get('release_date') else 0)
            info_tag.setRating(tmdb_info.get('vote_average', 0))

            list_item.setProperty('IsPlayable', 'true')
            url = get_url(action='play', video=video['url'], movie_id=video['tmdb_id'])
            is_folder = False

            xbmcplugin.addDirectoryItem(handle, url, list_item, is_folder)

        xbmcplugin.endOfDirectory(handle)
    else:
        xbmcgui.Dialog().notification('Resultado', 'Nenhum filme encontrado com esse nome.', xbmcgui.NOTIFICATION_INFO)



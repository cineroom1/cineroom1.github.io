import xbmc
from resources.lib.cache import Cache

class MyPlugin:
    def __init__(self):
        self.cache = Cache()

    def get_list(self, url: str):
        cached_data = self.cache.get(url)
        if cached_data:
            response, created = cached_data
            if created + 3600 > int(time.time()):  # 1 hora de cache
                xbmc.log("Using cached data", xbmc.LOGINFO)
                return response
        
        # Se não houver cache ou estiver expirado, faça a requisição
        response = self.fetch_data(url)  # Sua função de requisição aqui
        if response:
            self.cache.set(url, response)
        return response

    def fetch_data(self, url: str):
        # Lógica para buscar os dados da URL
        # Exemplo:
        response = "dados_ficticios"  # Substitua pela sua lógica de requisição
        return response

    def clear_cache(self):
        self.cache.clear_cache()

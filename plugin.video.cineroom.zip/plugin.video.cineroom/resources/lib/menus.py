import urllib.request
import json
import xbmcplugin
import xbmcgui
import sys

from urllib.parse import urlencode, parse_qsl

# Configurações do plugin
URL = sys.argv[0]
HANDLE = int(sys.argv[1])

def get_url(**kwargs):
    """
    Cria uma URL para chamar o plugin recursivamente a partir dos argumentos fornecidos.
    """
    return '{}?{}'.format(URL, urlencode(kwargs))

def check_maintenance_status(menu):
    """
    Verifica se o addon está em manutenção.
    Retorna True se o status for "off", caso contrário, retorna False.
    """
    if menu and isinstance(menu, list) and len(menu) > 0:
        first_item = menu[0]
        if isinstance(first_item, dict) and first_item.get("status", "").lower() == "off":
            return True
    return False

def get_menu():
    """
    Busca o menu principal do arquivo JSON hospedado no GitHub.
    """
    from main import MAIN_URL  # Certifique-se de que MAIN_URL está definido corretamente
    
    try:
        with urllib.request.urlopen(MAIN_URL) as response:
            menu = json.load(response)
            # Validação básica do JSON
            if not isinstance(menu, list):
                xbmcgui.Dialog().ok('Erro de JSON', 'O arquivo JSON não contém uma lista válida.')
                return []
            return menu
    except urllib.error.URLError as e:
        xbmcgui.Dialog().ok('Erro de Rede', f'Erro ao conectar ao servidor: {e}')
    except json.JSONDecodeError as e:
        xbmcgui.Dialog().ok('Erro de JSON', f'Erro ao decodificar os dados: {e}')
    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Erro inesperado: {e}')
    return []

def list_menu():
    """
    Lista os menus principais (Filmes, Séries, Pesquisar) na interface do Kodi.
    Verifica se o addon está em manutenção antes de exibir os itens do menu.
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Menu Principal')

    # Carrega o menu do GitHub
    menu = get_menu()
    if not menu:
        return

    from datetime import datetime

    if check_maintenance_status(menu):
        now = datetime.now().strftime("%d/%m/%Y %H:%M")  
        maintenance_item = xbmcgui.ListItem(label=f'Addon em manutenção ({now})')
        maintenance_item.setArt({'icon': 'DefaultIconWarning.png', 'fanart': 'DefaultFanart.png'})
        maintenance_item.setInfo('video', {'title': 'Addon em manutenção...', 'plot': 'Voltaremos em breve!'})
        xbmcplugin.addDirectoryItem(HANDLE, '', maintenance_item, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return  

    # Se não estiver em manutenção, exibe os itens do menu normalmente (ignorando o primeiro item, que é o status)
    for index, menu_info in enumerate(menu[1:], start=1):  # Ignora o primeiro item (status)
        list_item = xbmcgui.ListItem(label=menu_info['menu_title'])
        list_item.setArt({'icon': menu_info.get('poster', ''), 'fanart': menu_info.get('fanart', '')})
        list_item.setInfo('video', {'title': menu_info['menu_title']})

        if 'subcategorias' in menu_info:
            url = get_url(action='list_subcategories', menu_index=index)
            is_folder = True
        else:
            action = menu_info.get('action', '')
            external_link = menu_info.get('externallink', '')

            if external_link:
                url = get_url(action=action, external_link=external_link)
            else:
                url = get_url(action=action)

            is_folder = True  

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    # Adiciona a opção "Limpar Cache" no final da lista
    clear_cache_item = xbmcgui.ListItem(label='[COLOR darkred]Limpar Cache[/COLOR]')
    clear_cache_item.setArt({"icon": "https://archive.org/download/1700740365525/1700740365525.png"})
    clear_cache_item.setInfo('video', {'title': 'Limpar Cache', 'plot': 'Limpa o cache do addon.'})
    xbmcplugin.addDirectoryItem(HANDLE, get_url(action='clear_cache'), clear_cache_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)



def list_subcategories(menu_index):
    """
    Lista as subcategorias do menu selecionado.
    """
    menu = get_menu()
    if not menu or menu_index >= len(menu):
        return
    
    subcategories = menu[menu_index].get('subcategorias', [])
    if not subcategories:
        xbmcgui.Dialog().ok('Erro', 'Subcategorias não encontradas!')
        return
    
    xbmcplugin.setPluginCategory(HANDLE, 'Subcategorias')

    for subcategory in subcategories:
        list_item = xbmcgui.ListItem(label=subcategory['categories'])
        list_item.setArt({'icon': subcategory['poster'], 'fanart': subcategory['backdrop']})
        list_item.setInfo('video', {'title': subcategory['categories'], 'plot': subcategory.get('description', '')})
        
        # Verifica se a subcategoria tem uma ação definida
        if 'action' in subcategory:
            url = get_url(action=subcategory['action'])
            is_folder = True  # Gêneros serão tratados como pastas
        else:
            external_link = subcategory.get('externallink')
            content_type = subcategory.get('type', 'movie')
            sort_method = subcategory.get('sort_method', '')  # Obtém o método de ordenação

            if content_type == 'tvshow':
                xbmcplugin.setContent(HANDLE, 'tvshows')
                url = get_url(action='list_seasons', serie=json.dumps(subcategory), sort_method=sort_method)
            elif content_type == 'set':  # Para coleções
                xbmcplugin.setContent(HANDLE, 'set')
                url = get_url(action='list_collection', collection=json.dumps(subcategory), sort_method=sort_method)
            else:  # Para filmes padrão
                url = get_url(action='list_videos', external_link=external_link, sort_method=sort_method)

            is_folder = True

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)
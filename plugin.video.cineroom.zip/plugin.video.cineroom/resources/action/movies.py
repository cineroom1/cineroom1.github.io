import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import json
    
import concurrent.futures
from resources.lib.utils import get_all_videos
import urllib.request
from resources.action.video_listing import create_video_item
from resources.action.favorites import load_favorites



HANDLE = int(sys.argv[1])

PROVEDORES = [
    {"name": "Netflix", "icon": "https://logopng.com.br/logos/netflix-94.png"},
    {"name": "Amazon Prime Video", "icon": "https://upload.wikimedia.org/wikipedia/commons/f/f1/Prime_Video.png"},
    {"name": "Disney Plus", "icon": "https://logospng.org/wp-content/uploads/disneyplus.png"},
    {"name": "Max", "icon": "https://logospng.org/wp-content/uploads/hbo-max.png"},
    {"name": "Globoplay", "icon": "https://logospng.org/wp-content/uploads/globoplay.png"},
    {"name": "Star Plus", "icon": "https://logospng.org/wp-content/uploads/star-plus.png"},
    {"name": "Paramount Plus", "icon": "https://logospng.org/wp-content/uploads/paramount-plus.png"},
    {"name": "Apple TV+", "icon": "https://w7.pngwing.com/pngs/911/587/png-transparent-apple-tv-hd-logo.png"},
    {"name": "Telecine Amazon Channel", "icon": "https://logospng.org/wp-content/uploads/telecine.png"},
    {"name": "MUBI", "icon": "https://upload.wikimedia.org/wikipedia/commons/3/3c/Mubi_logo.svg"},
    {"name": "Crunchyroll", "icon": "https://upload.wikimedia.org/wikipedia/commons/1/1e/Crunchyroll_Logo.svg"},
    {"name": "YouTube Premium", "icon": "https://logospng.org/wp-content/uploads/youtube-premium.png"},
    {"name": "Pluto TV", "icon": "https://logospng.org/wp-content/uploads/pluto-tv.png"},
    {"name": "Tubi", "icon": "https://upload.wikimedia.org/wikipedia/commons/5/58/Tubi_logo.svg"},
    {"name": "MGM+ Apple TV Channel", "icon": "https://logodownload.org/wp-content/uploads/2021/10/MGM+logo.png"},
    {"name": "Looke", "icon": "https://seeklogo.com/images/L/looke-logo-4146BCD25D-seeklogo.com.png"}
]


# Lista de estúdios predefinidos
ESTUDIOS_FILMES = [
    "Universal Pictures", "Warner Bros.", "Paramount Pictures", "Sony Pictures",
    "20th Century Studios", "Walt Disney Pictures", "Pixar", "DreamWorks Animation",
    "Columbia Pictures", "Legendary Pictures", "DC Comics", "A24", "Marvel Studios",
    "MGM", "Lionsgate", "New Line Cinema", "Original Film", "Fox 2000 Pictures",
    "Sunday Night Productions", "Blue Sky Studios", "Lucasfilm Ltd.",
    "Blumhouse Productions", "Skydance Media", "Studio Ghibli"
]

GENRES = [
    {'name': 'Ação', 'key': 'Ação'},
    {'name': 'Animação', 'key': 'Animação'},
    {'name': 'Aventura', 'key': 'Aventura'}, 
    {'name': 'Cinema TV', 'key': 'Cinema TV'},
    {'name': 'Comédia', 'key': 'Comédia'},
    {'name': 'Crime', 'key': 'Crime'},
    {'name': 'Documentário', 'key': 'Documentário'},
    {'name': 'Drama', 'key': 'Drama'},
    {'name': 'Fantasia', 'key': 'Fantasia'}, 
    {'name': 'Faroeste', 'key': 'Faroeste'},
    {'name': 'Ficção Científica', 'key': 'Ficção científica'},
    {'name': 'Família', 'key': 'Família'},
    {'name': 'Guerra', 'key': 'Guerra'},
    {'name': 'História', 'key': 'História'},
    {'name': 'Mistério', 'key': 'Mistério'}, 
    {'name': 'Música', 'key': 'Música'},
    {'name': 'Romance', 'key': 'Romance'},
    {'name': 'Terror', 'key': 'Terror'},
    {'name': 'Thriller', 'key': 'Thriller'}
]

# Lista de anos pré-programados (últimos 20 anos, por exemplo)
ANOS_FILMES = [str(year) for year in range(2024, 1939, -1)] 

def get_url(action, **kwargs):
    """
    Gera uma URL para chamar ações dentro do addon.
    """
    return f"{sys.argv[0]}?action={action}&{urllib.parse.urlencode(kwargs)}"


def list_movies_by_genre(genre):
    """
    Lista os filmes de um determinado gênero.
    """
    def genre_criteria(movie, value):
        return value in ', '.join(movie.get('genres', [])).split(', ')
    
    filter_and_list_movies(genre_criteria, genre, f'Gênero: {genre}')

def list_movies_by_studio(studio):
    """
    Lista os filmes de um determinado estúdio.
    """
    def studio_criteria(movie, value):
        # Remove espaços extras e converte para minúsculas
        value = value.strip().lower()
        studios = movie.get('studio', [])
        
        # Verifica se o estúdio está na lista de estúdios do filme
        return value in [s.strip().lower() for s in studios]
    
    # Filtra e lista os filmes
    filter_and_list_movies(studio_criteria, studio, f'Filmes do Estúdio: {studio}')

def list_categories(categories, category_type):
    """
    Lista categorias (gêneros ou estúdios) e gera URLs para listar os filmes correspondentes.
    """
    xbmcplugin.setPluginCategory(HANDLE, category_type)
    xbmcplugin.setContent(HANDLE, "genres")

    for category in categories:
        list_item = xbmcgui.ListItem(label=category['name'] if isinstance(category, dict) else category)
        list_item.setInfo('video', {'title': category['name'] if isinstance(category, dict) else category})
        
        # Gera a URL para listar filmes da categoria específica
        url = get_url(
            action=f'list_movies_by_{category_type.lower()}',
            genre=category['key'] if isinstance(category, dict) else category
        )
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def list_genres():
    """
    Lista os gêneros de filmes pré-definidos.
    """
    list_categories(GENRES, 'genre')

def list_studios():
    """
    Lista todos os estúdios pré-programados e permite que o usuário escolha um.
    """
    # Configura a categoria e o conteúdo do plugin
    xbmcplugin.setPluginCategory(HANDLE, 'Estúdios')
    xbmcplugin.setContent(HANDLE, 'studios')

    # Adiciona os estúdios pré-programados à lista
    for studio in ESTUDIOS_FILMES:
        list_item = xbmcgui.ListItem(label=studio)
        list_item.setInfo('video', {'title': studio})
        
        # Gera a URL para listar filmes do estúdio específico
        url = get_url(action='list_movies_by_studio', studio=studio)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    # Finaliza a lista
    xbmcplugin.endOfDirectory(HANDLE)
    
def list_movies_by_year(year):
    """
    Lista os filmes de um determinado ano.
    """
    def year_criteria(movie, value):
        return movie.get('year', 0) == value  # Compara diretamente o ano do filme com o valor passado
    
    filter_and_list_movies(year_criteria, int(year), f'Ano: {year}')

def list_years():
    """
    Lista os anos pré-programados para filtrar os filmes.
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Anos')
    xbmcplugin.setContent(HANDLE, "years")

    for year in ANOS_FILMES:
        list_item = xbmcgui.ListItem(label=str(year))
        list_item.setInfo('video', {'title': str(year)})
        
        # Gera a URL para listar filmes do ano específico
        url = get_url(action='list_movies_by_year', year=year)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    
def filter_and_list_movies(criteria, value, title):
    """
    Filtra e lista os filmes com base em um critério (gênero, estúdio ou ano),
    ignorando filmes com '4K' ou '(4K)' no título.
    """
    xbmcplugin.setPluginCategory(HANDLE, f'Filmes - {title}')
    xbmcplugin.setContent(HANDLE, 'movies')

    movies = get_all_videos()
    seen_movies = set()
    filtered_movies = []

    for movie in movies:
        movie_title = movie.get('title', '').lower()
        if (
            movie.get('type') == 'movie' and  # Garante que é um filme
            criteria(movie, value) and  # Verifica o critério (gênero, estúdio ou ano)
            movie.get('tmdb_id') not in seen_movies and  # Evita filmes duplicados
            '4k' not in movie_title and  # Ignora filmes com '4k' no título
            '(4k)' not in movie_title  # Ignora filmes com '(4k)' no título
        ):
            seen_movies.add(movie['tmdb_id'])
            filtered_movies.append(movie)

    if not filtered_movies:
        xbmcgui.Dialog().ok("Aviso", f"Nenhum filme encontrado para {title}.")
        return

    for movie in filtered_movies:
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setArt({
           'poster': movie['poster'],
           'fanart': movie['backdrop'],
           'clearlogo': movie.get('clearlogo', '')
        })
        list_item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('synopsis', ''),
            'rating': movie.get('rating', 0),
            'year': movie.get('year', 0),
            'studio': ', '.join(movie.get('studio', [])),
            'duration': movie.get("runtime", 0),
            'genre': ', '.join(movie.get('genres', [])),
            "aired": movie.get("premiered", "Ano não disponível"),
            'mediatype': 'movie'
        })

        url = get_url(action='play', video=','.join(movie['url']), tmdb_id=movie.get('tmdb_id', '')) if 'url' in movie else ''
        list_item.setProperty("IsPlayable", "true")
        
        favorites = load_favorites()
        
        if any(fav['title'] == movie['title'] for fav in favorites):
            list_item.addContextMenuItems([
                ('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(movie))})')
            ])
        else:
            list_item.addContextMenuItems([
                ('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(movie))})')
            ])
        
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    # Adiciona métodos de ordenação suportados pelo Kodi
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    xbmcplugin.endOfDirectory(HANDLE)
    
    
def list_movies_by_specific_year(year):
    """
    Filtra e lista os filmes de um ano específico, removendo duplicados por tmdb_id
    e ignorando filmes com '(4K)' no título.
    :param year: O ano para filtrar os filmes (int).
    """
    title = f"Filmes de {year}"
    videos = get_all_videos()

    unique_movies = []
    seen_ids = set()

    for movie in videos:
        if (
            movie.get('type') == 'movie'
            and movie.get('year') == year
            and movie.get('tmdb_id')
            and '(4K)' not in movie.get('title', '')
        ):
            tmdb_id = movie['tmdb_id']
            if tmdb_id not in seen_ids:
                unique_movies.append(movie)
                seen_ids.add(tmdb_id)

    if not unique_movies:
        xbmcgui.Dialog().ok("Aviso", f"Nenhum filme encontrado para {title}.")
        return

    xbmcplugin.setPluginCategory(HANDLE, title)
    xbmcplugin.setContent(HANDLE, 'movies')

    for movie in unique_movies:
        list_item, url, is_folder = create_video_item(movie)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(HANDLE)

    
def generate_url(action, **kwargs):
    return f"{sys.argv[0]}?action={action}&{urllib.parse.urlencode(kwargs)}"    
    
def list_movies_by_rating(page=1, items_per_page=70):
    """
    Lista os filmes ordenados por avaliação (nota) em ordem decrescente, com paginação.
    """
    try:
        page = int(page)
        items_per_page = int(items_per_page)
    except (ValueError, TypeError):
        page = 1
        items_per_page = 70

    # Obtém todos os filmes
    movies = get_all_videos()

    # Filtra apenas filmes e remove títulos com '(4K)'
    movies = [
        movie for movie in movies
        if movie.get('type') == 'movie' and '(4K)' not in movie.get('title', '')
    ]

    # Remove duplicados
    unique_movies = []
    seen_ids = set()
    for movie in movies:
        tmdb_id = movie.get('tmdb_id')
        if tmdb_id and tmdb_id not in seen_ids:
            unique_movies.append(movie)
            seen_ids.add(tmdb_id)

    # Ordena por avaliação
    unique_movies.sort(key=lambda x: x.get('rating', 0), reverse=True)

    if not unique_movies:
        xbmcgui.Dialog().ok("Aviso", "Nenhum filme encontrado.")
        return

    xbmcplugin.setPluginCategory(HANDLE, 'Melhor Avaliação')
    xbmcplugin.setContent(HANDLE, 'movies')

    # Paginação
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page
    paginated_movies = unique_movies[start_index:end_index]

    # Adiciona os filmes da página atual à lista
    for movie in paginated_movies:
        list_item, url, is_folder = create_video_item(movie)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    # Próxima página
    if end_index < len(unique_movies):
        next_page_item = xbmcgui.ListItem(label="Próxima Página >>")
        next_page_url = get_url(action='list_movies_by_rating', page=page + 1, items_per_page=items_per_page)
        next_page_item.setArt({"icon": "https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/1700740365615.png"})
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

    
def list_actors():
    """
    Lista todos os atores disponíveis (sem imagens) e permite ao usuário escolher um para ver os filmes/séries correspondentes.
    Exibe também a quantidade de vídeos de cada ator.
    """
    try:
        all_videos = get_all_videos()
    except Exception as e:
        xbmcgui.Dialog().ok("Erro", f"Erro ao obter vídeos: {str(e)}")
        return

    actor_counts = {}

    for video in all_videos:
        for actor in video.get("actors", []):
            if isinstance(actor, str):
                actor_name = actor.strip()
                if actor_name:
                    actor_counts[actor_name] = actor_counts.get(actor_name, 0) + 1

    if not actor_counts:
        xbmcgui.Dialog().ok("Aviso", "Nenhum ator encontrado.")
        return

    xbmcplugin.setPluginCategory(HANDLE, 'Atores')
    xbmcplugin.setContent(HANDLE, 'actors')

    for actor_name in sorted(actor_counts.keys()):
        count = actor_counts[actor_name]
        label = f"{actor_name} ({count})"

        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo('video', {'title': actor_name})

        url = get_url(action='list_movies_by_actor', actor=actor_name)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def list_movies_by_actor(actor_name):
    """
    Lista os filmes/séries em que um ator específico participou.
    """
    try:
        all_videos = get_all_videos()
    except Exception as e:
        xbmcgui.Dialog().ok("Erro", f"Erro ao obter vídeos: {str(e)}")
        return

    # Filtra os vídeos em que o ator participou
    filtered_videos = []
    for video in all_videos:
        actors = video.get("actors", [])
        if any(actor.lower() == actor_name.lower() for actor in actors):
            filtered_videos.append(video)

    if not filtered_videos:
        xbmcgui.Dialog().ok("Resultado", f"Nenhum vídeo encontrado com o ator: {actor_name}")
        return

    xbmcplugin.setPluginCategory(HANDLE, f'Filmes com: {actor_name}')
    xbmcplugin.setContent(HANDLE, 'movies')

    for video in filtered_videos:
        list_item, url, is_folder = create_video_item(video)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)



def list_movies_by_popularity(page=1, items_per_page=70):
    try:
        page = int(page)
        items_per_page = int(items_per_page)
    except (ValueError, TypeError):
        page = 1
        items_per_page = 70

    movies = get_all_videos()

    def process_movies_chunk(chunk):
        return [
            movie for movie in chunk
            if movie.get('type') == 'movie' and '(4K)' not in movie.get('title', '')
        ]

    chunk_size = 100  # Melhor para dispositivos fracos
    chunks = [movies[i:i + chunk_size] for i in range(0, len(movies), chunk_size)]

    filtered_movies = []
    max_workers = min(3, len(chunks))  # Máximo de 5 threads para não estourar CPU

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(process_movies_chunk, chunk) for chunk in chunks]
        for future in concurrent.futures.as_completed(futures):
            filtered_movies.extend(future.result())

    # Remover duplicados direto
    seen_ids = set()
    unique_movies = []
    for movie in filtered_movies:
        tmdb_id = movie.get('tmdb_id')
        if tmdb_id and tmdb_id not in seen_ids:
            seen_ids.add(tmdb_id)
            unique_movies.append(movie)

    unique_movies.sort(key=lambda x: x.get('popularity', 0), reverse=True)

    if not unique_movies:
        xbmcgui.Dialog().ok("Aviso", "Nenhum filme encontrado.")
        return

    xbmcplugin.setPluginCategory(HANDLE, 'Mais Populares')
    xbmcplugin.setContent(HANDLE, 'movies')

    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page
    paginated_movies = unique_movies[start_index:end_index]

    for movie in paginated_movies:
        title = movie.get('title', '')
        genres = movie.get('genres', [])
        if any('hdcam' in genre.lower() for genre in genres):
            title = f"[COLOR red]{title}[/COLOR]"
        movie['title'] = title  # Sobrescreve o título com cor, se aplicável

        list_item, url, is_folder = create_video_item(movie)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)


    if end_index < len(unique_movies):
        next_page_item = xbmcgui.ListItem(label="Próxima Página >>")
        next_page_url = get_url(action='list_movies_by_popularity', page=page + 1, items_per_page=items_per_page)
        next_page_item.setArt({"icon": "https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/1700740365615.png"})
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)



def list_movies_in_cinemas(page=1, items_per_page=70):
    """
    Lista os filmes com o gênero HDCAM na categoria "Nos Cinemas", com paginação.
    """
    try:
        page = int(page)
        items_per_page = int(items_per_page)
    except (ValueError, TypeError):
        page = 1
        items_per_page = 70

    movies = get_all_videos()

    # Filtra apenas filmes HDCAM
    hdcam_movies = [
        movie for movie in movies
        if movie.get('type') == 'movie' and 'HDCAM' in movie.get('genres', [])
    ]

    # Remove duplicados
    unique_movies = []
    seen_ids = set()
    for movie in hdcam_movies:
        tmdb_id = movie.get('tmdb_id')
        if tmdb_id and tmdb_id not in seen_ids:
            unique_movies.append(movie)
            seen_ids.add(tmdb_id)

    if not unique_movies:
        xbmcgui.Dialog().ok("Aviso", "Nenhum filme em HDCAM encontrado.")
        return

    xbmcplugin.setPluginCategory(HANDLE, 'Nos Cinemas')
    xbmcplugin.setContent(HANDLE, 'movies')

    # Paginação
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page
    paginated_movies = unique_movies[start_index:end_index]

    for movie in paginated_movies:
        list_item, url, is_folder = create_video_item(movie)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    if end_index < len(unique_movies):
        next_page_item = xbmcgui.ListItem(label="Próxima Página >>")
        next_page_url = get_url(action='list_movies_in_cinemas', page=page + 1, items_per_page=items_per_page)
        next_page_item.setArt({"icon": "https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/1700740365615.png"})
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


from datetime import datetime


def list_recently_added(page=1, items_per_page=70):
    """
    Lista APENAS FILMES adicionados recentemente, com paginação.
    Utiliza create_video_item para criar os itens da lista.
    """
    try:
        page = int(page)
        items_per_page = int(items_per_page)
    except (ValueError, TypeError):
        page = 1
        items_per_page = 70

    videos = get_all_videos()

    # Filtra apenas filmes com 'date_added' válido
    movies = [
        video for video in videos 
        if video.get('type') == 'movie' and video.get('date_added') is not None
    ]

    # Remove duplicados
    unique_movies = []
    seen_ids = set()
    for movie in movies:
        tmdb_id = movie.get('tmdb_id')
        if tmdb_id and tmdb_id not in seen_ids:
            unique_movies.append(movie)
            seen_ids.add(tmdb_id)

    if not unique_movies:
        xbmcgui.Dialog().ok("Aviso", "Nenhum filme adicionado recentemente encontrado.")
        return

    xbmcplugin.setPluginCategory(HANDLE, 'Filmes Adicionados Recentemente')
    xbmcplugin.setContent(HANDLE, 'movies')

    # Ordena pela data de adição mais recente
    unique_movies.sort(key=lambda x: x['date_added'], reverse=True)

    # Paginação
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page
    paginated_movies = unique_movies[start_index:end_index]

    for movie in paginated_movies:
        title = movie.get('title', '')
        genres = movie.get('genres', [])
        if any('hdcam' in genre.lower() for genre in genres):
            title = f"[COLOR red]{title}[/COLOR]"
        movie['title'] = title  # Sobrescreve o título com cor, se aplicável

        list_item, url, is_folder = create_video_item(movie)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    # Próxima página
    if end_index < len(unique_movies):
        next_page_item = xbmcgui.ListItem(label="Próxima Página >>")
        next_page_url = get_url(action='list_recently_added', page=page + 1, items_per_page=items_per_page)
        next_page_item.setArt({"icon": "https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/1700740365615.png"})
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

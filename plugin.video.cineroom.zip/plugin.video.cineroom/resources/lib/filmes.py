# filmes.py

import json
import urllib.request
import xbmcgui
import xbmcplugin
import sys
from resources.lib.utils import get_json_data, get_url
import xbmc
import xbmcvfs

from urllib.parse import parse_qsl
from resources.lib.menu import URL_FILMES, URL_ESTUDIO, URL_POR_ANO, URL_COLECOES
from resources.lib.dados import GENRES, ESTUDIOS_FILMES


# Definindo o addon_handle
addon_handle = int(sys.argv[1])  # Obtém o handle do addon

HANDLE = int(sys.argv[1])

def list_items(data_url, category_name, page=1, items_per_page=100):
    try:
        # Log para verificar a URL
        xbmc.log(f"Carregando dados de: {data_url} para a categoria: {category_name}, página {page}", xbmc.LOGINFO)

        # Carrega os dados do JSON
        with urllib.request.urlopen(data_url) as response:
            data = json.load(response)

        # Verifica se a lista está em manutenção
        if isinstance(data[0], dict) and data[0].get("status", "").lower() == "off":
            xbmcgui.Dialog().notification("Aguarde...", "A lista está em manutenção!", xbmcgui.NOTIFICATION_WARNING, 3000)
            return  # Encerra a função sem listar os itens

        # Remove o item de status para processar apenas os filmes
        data = data[1:]

        # Calcula o intervalo de itens
        start_index = (page - 1) * items_per_page
        end_index = start_index + items_per_page
        total_items = len(data)
        paginated_data = data[start_index:end_index]

        xbmcplugin.setPluginCategory(HANDLE, f'{category_name} - Página {page}')
        xbmcplugin.setContent(HANDLE, 'movies')

        # Lista os itens
        for item in paginated_data:
            title = item.get("title", "Sem título")
            poster = item.get("poster", "")
            backdrop = item.get("backdrop", "")
            genres = item.get("genres", "Desconhecido")
            rating = item.get("rating", 0)
            sinopse = item.get("synopsis", "Sem descrição")
            year = item.get("year", 0)
            studio = item.get("studio", "Desconhecido")
            director = item.get("director", "Desconhecido")
            duration = item.get("runtime", 0)
            premiered = item.get("premiered", "Desconhecido")
            clearlogo = item.get("clearlogo", "")  # Remove espaços extras para evitar strings vazias

            # Obter os atores com nome e foto
            actors = item.get("actors", [])
            cast = [{'name': actor.get('name', 'Desconhecido'), 'thumbnail': actor.get('photo', '')} for actor in actors]

            # Configura o item da lista no Kodi
            list_item = xbmcgui.ListItem(label=title)

            # Definir artes
            art = {
                "poster": poster,
                "fanart": backdrop,
            }
            if clearlogo:
                art["clearlogo"] = clearlogo  # Apenas adiciona se existir

            list_item.setArt(art)
            list_item.setInfo("video", {
                "title": title,
                "genre": genres,
                "rating": rating,
                "plot": sinopse,
                "year": year,
                "studio": studio,
                "director": director,
                "cast": [c['name'] for c in cast],  # Apenas os nomes dos atores
                "duration": duration,
                "aired": premiered,
                "mediatype": "movie"
            })

            # Adiciona o elenco completo com fotos
            list_item.setCast(cast)

            # Configura o item como reproduzível
            list_item.setProperty("IsPlayable", "true")

            urls = item.get("url")  # Usa get() para evitar erro caso a chave 'url' não exista
            if isinstance(urls, str):  # Se for string única, transforma em lista
                urls = [urls]

            # Gera a URL do item
            if urls:  # Verifica se urls não é vazio
                url = get_url(action="play", video=json.dumps(urls))
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)

        # Adiciona a próxima página
        if end_index < total_items:
            next_page_url = f"{sys.argv[0]}?action=list_items&data_url={data_url}&category_name={category_name}&page={page + 1}"
            next_page_item = xbmcgui.ListItem(label=f"Próxima Página ({page + 1})")
            next_page_item.setArt({"icon": "https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/1700740365615.png"})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=next_page_url, listitem=next_page_item, isFolder=True)

        # Condiciona a ordenação com base na categoria
        if category_name in ["Top 250", "Aleatorios"]:
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)

    except Exception as e:
        xbmcgui.Dialog().notification("Erro", f"Não foi possível carregar os dados: {e}", xbmcgui.NOTIFICATION_ERROR, 5000)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_generos():
    """Exibe a lista de gêneros disponíveis."""
    xbmcplugin.setContent(HANDLE, 'genres')
    for genre in GENRES:
        url = f"plugin://plugin.video.cineroom/?action=filmes_por_genero&genero={genre['key']}"
        list_item = xbmcgui.ListItem(label=genre['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def filmes_por_genero(genero):
    """Filtra e exibe filmes de um gênero específico, incluindo mais informações."""
    xbmcplugin.setPluginCategory(HANDLE, f'Gênero / {genero}')
    xbmcplugin.setContent(HANDLE, 'movies')
    
    filmes = carregar_dados_filmes(URL_FILMES)  # Agora a URL vem da variável global
    filmes_filtrados = [
        filme for filme in filmes
        if genero.lower() in [g.strip().lower() for g in filme.get("genres", "").split(",")]
    ]

    for filme in filmes_filtrados:
        list_item = xbmcgui.ListItem(label=filme["title"])
        
        # Definindo as informações do filme
        list_item.setInfo('video', {
            "genre": filme.get("genres", "Gênero não especificado"),
            "title": filme["title"],
            "plot": filme.get("synopsis", "Descrição não disponível"),
            "rating": filme.get("rating", "N/A"),
            "director": filme.get("director", "Desconhecido"),
            "studio": filme.get("studio", "Desconhecido"),
            "runtime": filme.get("runtime", "Duração não disponível"),
            "year": filme.get("year", "Ano não disponível"),
            "aired": filme.get("premiered", "Ano não disponível"),
            'mediatype': 'movie'
        })
        
        # Definindo as artes (poster e fanart)
        list_item.setArt({
            'poster': filme["poster"],
            'fanart': filme["backdrop"],
            'clearlogo': filme.get("clearlogo", "")  # Adiciona o clearlogo se disponível
        })
        list_item.setProperty('IsPlayable', 'true')
        
        # Garantindo que a URL seja uma lista antes de serializar em JSON
        urls = filme['url'] if isinstance(filme['url'], list) else [filme['url']]
        url = get_url(action='play', video=json.dumps(urls))

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.endOfDirectory(addon_handle)


def list_estudios():
    xbmcplugin.setContent(HANDLE, 'genres')
    """
    Exibe a lista de estúdios de filmes.
    """
    estudios = ESTUDIOS_FILMES
    xbmcplugin.setContent(HANDLE, 'genres')

    # Exibe a lista de estúdios
    for estudio in estudios:
        list_item = xbmcgui.ListItem(label=estudio)
        list_item.setArt({'icon': 'default.png', 'fanart': 'fanart.jpg'})
        list_item.setInfo('video', {'title': estudio, 'genre': 'Estúdio', 'plot': f'Estúdio de filmes: {estudio}'})
        # Correção na URL para passar parâmetros de forma correta
        url = get_url(action='filmes_por_estudio', estudio=estudio)  # Passando apenas o estúdio
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    

def filmes_por_estudio(paramstring):
    xbmcplugin.setContent(HANDLE, 'movies')
    """
    Lista filmes de um estúdio específico.
    :param paramstring: String com os parâmetros da URL, incluindo o nome do estúdio
    """
    params = dict(parse_qsl(paramstring))
    estudio = params.get('estudio')

    # Fazendo requisição para obter os filmes
    filmes_response = urllib.request.urlopen(URL_ESTUDIO)  # Usando a variável global
    filmes_data = filmes_response.read()
    filmes = json.loads(filmes_data)

    # Mostrar os filmes do estúdio
    category_name = f"Filmes do estúdio {estudio}"  # Nome dinâmico para a categoria
    xbmcplugin.setPluginCategory(HANDLE, category_name)
    xbmcplugin.setContent(HANDLE, 'movies')  # Define o tipo de mídia como 'movies'

    for filme in filmes:
        if filme['studio'] == estudio:  # Filtra os filmes pelo estúdio
            list_item = xbmcgui.ListItem(label=filme['title'])
            list_item.setArt({
                'poster': filme["poster"], 
                'fanart': filme['backdrop']
            })
            list_item.setInfo('video', {
                'title': filme['title'], 
                'genre': filme['genres'], 
                "rating": filme.get("rating", "N/A"),
                "runtime": filme.get("runtime", "Duração não disponível"),
                'plot': filme.get('synopsis', 'Sem sinopse disponível'),
                'mediatype': 'movie'
            })
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
            list_item.setProperty('IsPlayable', 'true')
            urls = filme['url'] if isinstance(filme['url'], list) else [filme['url']]
            url = get_url(action='play', video=json.dumps(urls))
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    


def carregar_dados_filmes(url=None):
    """Carrega todos os filmes do JSON especificado na URL."""
    if url is None:
        url = URL_FILMES  # Define a URL padrão se nenhuma for informada

    with urllib.request.urlopen(url) as response:
        filmes = json.load(response)
    
    return filmes

def listar_anos():
    """Exibe a lista de anos disponíveis nos filmes."""
    xbmcplugin.setContent(HANDLE, 'years')

    filmes = carregar_dados_filmes()
    anos = sorted(set(filme.get('year') for filme in filmes if 'year' in filme and filme['year']))

    for ano in anos:
        url = f"plugin://plugin.video.cineroom/?action=filmes_por_ano&ano={ano}"
        list_item = xbmcgui.ListItem(label=str(ano))
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def filmes_por_ano(ano):
    """Filtra e exibe filmes de um ano específico."""
    xbmcplugin.setPluginCategory(HANDLE, f'Ano / {ano}')
    xbmcplugin.setContent(HANDLE, 'movies')

    filmes = carregar_dados_filmes()
    filmes_filtrados = [filme for filme in filmes if str(filme.get('year')) == ano]

    for filme in filmes_filtrados:
        list_item = xbmcgui.ListItem(label=filme["title"])

        list_item.setInfo('video', {
            "genre": filme.get("genres", "Gênero não especificado"),
            "title": filme["title"],
            "plot": filme.get("synopsis", "Descrição não disponível"),
            "rating": filme.get("rating", "N/A"),
            "director": filme.get("director", "Desconhecido"),
            "studio": filme.get("studio", "Desconhecido"),
            "runtime": filme.get("runtime", "Duração não disponível"),
            "year": filme.get("year", "Ano não disponível"),
            'mediatype': 'movie'
        })

        list_item.setArt({
            'poster': filme["poster"],
            'fanart': filme["backdrop"]
        })
        list_item.setProperty('IsPlayable', 'true')

        urls = filme['url'] if isinstance(filme['url'], list) else [filme['url']]
        url = get_url(action='play', video=json.dumps(urls))
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.endOfDirectory(HANDLE)

def listar_colecoes():
    """
    Lista as coleções de filmes no Kodi a partir de um arquivo JSON hospedado.
    """
    xbmcplugin.setContent(HANDLE, 'movies')

    handle = int(sys.argv[1])

    try:
        # Fazendo o download e carregando o JSON
        with urllib.request.urlopen(URL_COLECOES) as response:
            data = json.load(response)

        # Verifica se a lista está desativada
        if isinstance(data.get("collections", [])[0], dict) and data["collections"][0].get("status", "").lower() == "off":
            xbmcgui.Dialog().notification("Aguarde...", "A lista de coleções está em manutenção!", xbmcgui.NOTIFICATION_WARNING, 3000)
            return  # Encerra a função sem listar os itens

        colecoes = data.get("collections", [])[1:]  # Remove o primeiro item (status)

        for colecao in colecoes:
            collection_id = colecao.get("collection_id")
            collection_title = colecao.get("collection_title")
            poster = colecao.get("poster")
            backdrop = colecao.get("backdrop")
            rate = colecao.get("rate", 0)
            plot = colecao.get("plot", "Sem descrição disponível.")

            # Criando um item de lista para a coleção
            list_item = xbmcgui.ListItem(label=collection_title)
            list_item.setArt({
                'poster': poster,
                'fanart': backdrop
            })
            list_item.setInfo('video', {
                'title': collection_title,
                'plot': plot,
                'rating': rate,
                'mediatype': 'set'
            })

            # URL para exibir os filmes da coleção
            url_filmes = f"{sys.argv[0]}?action=listar_filmes_colecao&collection_id={collection_id}"
            xbmcplugin.addDirectoryItem(handle=handle, url=url_filmes, listitem=list_item, isFolder=True)

        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
        xbmcplugin.endOfDirectory(handle)

    except Exception as e:
        xbmcgui.Dialog().notification("Erro", f"Falha ao carregar coleções: {e}", xbmcgui.NOTIFICATION_ERROR)


def listar_filmes_colecao(collection_id):
    """
    Lista os filmes de uma coleção específica.
    """
    xbmcplugin.setContent(HANDLE, 'movies')
    handle = int(sys.argv[1])

    try:
        with urllib.request.urlopen(URL_COLECOES) as response:
            data = json.load(response)
        
        colecoes = data.get("collections", [])
        
        # Encontrar a coleção correspondente
        for colecao in colecoes:
            if colecao.get("collection_id") == collection_id:
                filmes = colecao.get("movies", [])
                for filme in filmes:
                    titulo = filme.get("titulo")
                    url_video = filme.get("url")
                    poster = filme.get("poster")
                    backdrop = filme.get("backdrop")
                    rate = filme.get("rate", 0)
                    plot = filme.get("plot", "Sem descrição disponível.")
                    
                    # Criando um list item para o filme
                    list_item = xbmcgui.ListItem(label=titulo)
                    list_item.setArt({
                        'poster': poster,
                        'fanart': backdrop
                    })
                    list_item.setInfo('video', {
                        'title': titulo,
                        'plot': plot,
                        'rating': rate,
                        'mediatype': 'movie'
                    })
                    list_item.setProperty('IsPlayable', 'true')
                    
                    # Adicionando ao menu
                    xbmcplugin.addDirectoryItem(handle=handle, url=url_video, listitem=list_item, isFolder=False)
                    
        xbmcplugin.endOfDirectory(handle)
    
    except Exception as e:
        xbmcgui.Dialog().notification("Erro", f"Falha ao carregar filmes: {e}", xbmcgui.NOTIFICATION_ERROR)

import urllib.request
import json
import xbmcplugin
import xbmcgui
import sys
import os
import xbmcaddon

from urllib.parse import urlencode, parse_qsl

# Configurações do plugin
URL = sys.argv[0]
HANDLE = int(sys.argv[1])

def get_url(**kwargs):
    """
    Cria uma URL para chamar o plugin recursivamente a partir dos argumentos fornecidos.
    """
    return '{}?{}'.format(URL, urlencode(kwargs))

def check_maintenance_status(menu):
    """
    Verifica se o addon está em manutenção.
    Retorna True se o status for "off", caso contrário, retorna False.
    """
    if menu and isinstance(menu, list) and len(menu) > 0:
        first_item = menu[0]
        if isinstance(first_item, dict) and first_item.get("status", "").lower() == "off":
            return True
    return False

def get_menu():
    """
    Busca o menu principal do arquivo JSON hospedado no GitHub.
    """
    from resources.images.config.urls import data_feed, credenciais
    
    try:
        with urllib.request.urlopen(data_feed) as response:
            menu = json.load(response)
            # Validação básica do JSON
            if not isinstance(menu, list):
                xbmcgui.Dialog().ok('Erro de JSON', 'O arquivo JSON não contém uma lista válida.')
                return []
            return menu
    except urllib.error.URLError as e:
        xbmcgui.Dialog().ok('Erro de Rede', f'Erro ao conectar ao servidor: {e}')
    except json.JSONDecodeError as e:
        xbmcgui.Dialog().ok('Erro de JSON', f'Erro ao decodificar os dados: {e}')
    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Erro inesperado: {e}')
    return []

def list_menu():
    """
    Lista os menus principais (Filmes, Séries, Pesquisar, etc.) na interface do Kodi.
    Verifica se cada categoria está ativada nas configurações do usuário (settings.xml), usando menu_key como chave fixa.
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Menu Principal')
    xbmcplugin.setContent(HANDLE, "addons")
    menu = get_menu()
    if not menu:
        return

    # Lê as configurações do usuário
    show_filmes = xbmcaddon.Addon().getSettingBool('mostrar_filmes')
    show_series = xbmcaddon.Addon().getSettingBool('mostrar_series')
    show_pesquisar = xbmcaddon.Addon().getSettingBool('mostrar_pesquisar')
    show_canais = xbmcaddon.Addon().getSettingBool('mostrar_canais')
    show_explorar = xbmcaddon.Addon().getSettingBool('mostrar_explorar')
    show_favoritos = xbmcaddon.Addon().getSettingBool('mostrar_favoritos')

    # Mapeamento fixo das chaves
    settings_map = {
        "Filmes": show_filmes,
        "Séries": show_series,
        "Pesquisar": show_pesquisar,
        "Canais": show_canais,
        "Explorar": show_explorar,
        "Minha_Lista": show_favoritos
    }

    for index, menu_info in enumerate(menu[1:], start=1):
        title = menu_info.get("menu_title", "")  # Nome exibido
        key = menu_info.get("menu_key", "")  # Nome interno fixo

        mostrar_categoria = settings_map.get(key, True)
        if not mostrar_categoria:
            continue  # Ignora a categoria desativada pelo usuário

        if menu_info.get("status", "").lower() == "off":
            list_item = xbmcgui.ListItem(label=f"{title} [COLOR red]•[/COLOR] (Em Manutenção)")
            list_item.setInfo('video', {
                'title': f'{title} - Indisponível',
                'plot': 'Esta categoria está temporariamente fora de serviço.'
            })
            list_item.setArt({
                'icon': menu_info.get('poster', ''),
                'fanart': menu_info.get('fanart', '')
            })
            xbmcplugin.addDirectoryItem(HANDLE, '', list_item, isFolder=True)
        else:
            list_item = xbmcgui.ListItem(label=title)
            list_item.setInfo('video', {
                'title': f'{title} - Disponível',
                'plot': 'Esta categoria está disponível para visualização.'
            })
            list_item.setArt({
                'icon': menu_info.get('poster', ''),
                'fanart': menu_info.get('fanart', '')
            })

            # Verifica se há subcategorias
            if 'subcategorias' in menu_info:
                url = get_url(action='list_subcategories', menu_index=index)
            elif isinstance(menu_info.get("externallink"), list):
                url = get_url(action='list_sub_external_links', menu_index=index)
            else:
                action = menu_info.get('action', '')
                external_link = menu_info.get('externallink', '')
                url = get_url(action=action, external_link=external_link) if external_link else get_url(action=action)

            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


import urllib.parse

def list_sub_external_links(menu_index):
    """
    Exibe sublistas de canais com base nos links múltiplos.
    Suporta também a opção 'search(Pesquisar Canal)'.
    """
    menu = get_menu()
    item = menu[menu_index]

    links = item.get('externallink', [])
    if not links:
        xbmcgui.Dialog().ok("Erro", "Nenhum link externo encontrado.")
        return

    for link in links:
        if "(" in link and ")" in link:
            base_url = link.split("(")[0].strip()
            nome = link.split("(")[-1].replace(")", "").strip()
        else:
            base_url = link.strip()
            nome = "Lista"

        if base_url.lower() == "search":
            search_url = f"{sys.argv[0]}?action=search_canais"
            search_item = xbmcgui.ListItem(label=f"[COLOR yellow]{nome}[/COLOR]")
            search_item.setArt({
                'icon': "https://archive.org/download/em_alta/search.png",
                'fanart': item.get('fanart', '')
            })
            xbmcplugin.addDirectoryItem(HANDLE, search_url, search_item, isFolder=True)
            continue
        # Só executa daqui pra baixo se não for 'search'
        quoted_url = urllib.parse.quote_plus(base_url)
    
       # Item para atualizar a lista
        refresh_url = f"{sys.argv[0]}?action=refresh&external_link={quoted_url}"
        refresh_item = xbmcgui.ListItem(label=f'[COLOR blue][B]- Atualizar Lista ({nome})[/B][/COLOR]')
        refresh_item.setArt({
            'icon': "https://archive.org/download/em_alta/ChatGPT%20Image%205%20de%20abr.%20de%202025%2C%2014_35_24.png",
            'fanart': item.get('fanart', '')
        })
        xbmcplugin.addDirectoryItem(HANDLE, refresh_url, refresh_item, isFolder=True)

        # Cria item normal
        list_item = xbmcgui.ListItem(label=nome)
        list_item.setArt({
            'icon': item.get('poster', ''),
            'fanart': item.get('fanart', '')
        })
        list_item.setInfo('video', {'title': nome})

        url = get_url(action='list_canais', external_link=base_url)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def list_subcategories(menu_index):
    """
    Lista as subcategorias do menu selecionado.
    """
    menu = get_menu()
    if not menu or menu_index >= len(menu):
        return
    
    subcategories = menu[menu_index].get('subcategorias', [])
    if not subcategories:
        xbmcgui.Dialog().ok('Erro', 'Subcategorias não encontradas!')
        return
    
    xbmcplugin.setPluginCategory(HANDLE, 'Subcategorias')
    xbmcplugin.setContent(HANDLE, "addons")

    for subcategory in subcategories:
        list_item = xbmcgui.ListItem(label=subcategory['categories'])
        list_item.setArt({'icon': subcategory['poster']})
        list_item.setInfo('video', {'title': subcategory['categories'], 'plot': subcategory.get('description', '')})
        
        # Verifica se a subcategoria tem uma ação definida
        if 'action' in subcategory:
            url = get_url(action=subcategory['action'])
            is_folder = True  # Gêneros serão tratados como pastas
        else:
            external_link = subcategory.get('externallink')
            content_type = subcategory.get('type', 'movie')
            sort_method = subcategory.get('sort_method', '')  # Obtém o método de ordenação

            if content_type == 'tvshow':
                xbmcplugin.setContent(HANDLE, 'tvshows')
                url = get_url(action='list_seasons', serie=json.dumps(subcategory), sort_method=sort_method)
            elif content_type == 'set':  # Para coleções
                xbmcplugin.setContent(HANDLE, 'set')
                url = get_url(action='list_collection', collection=json.dumps(subcategory), sort_method=sort_method)
            else:  # Para filmes padrão
                url = get_url(action='list_videos', external_link=external_link, sort_method=sort_method)

            is_folder = True

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)
    
from resources.action.donation_window import DonationDialog

def show_donation():
    dialog = DonationDialog("DonationDialog.xml", xbmcaddon.Addon().getAddonInfo("path"), "Default", "720p")
    dialog.doModal()
    del dialog

import os
import json
import hashlib
import concurrent.futures
from datetime import datetime, timedelta
import xbmc
import xbmcvfs
import xbmcaddon
import base64

# Configurações do cache
ADDON = xbmcaddon.Addon()
CACHE_DIR = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo('profile'), 'cache/'))
os.makedirs(CACHE_DIR, exist_ok=True)

class VideoCache:
    """Classe principal para gerenciamento de cache de vídeos"""
    
    def __init__(self):
        self.cache_index = {}
        self.load_index()
        self.enabled = True
        xbmc.log(f"[VideoCache] Inicializado. Status: {'Ativado' if self.enabled else 'Desativado'}", xbmc.LOGINFO)
    
    def is_expired(self, url, ignore_missing=False):
        """Verifica se um item do cache está expirado"""
        try:
            cache_key = hashlib.md5(url.encode('utf-8')).hexdigest()
            if cache_key in self.cache_index:
                expiry_time = datetime.fromisoformat(self.cache_index[cache_key]['expires'])
                return datetime.now() > expiry_time
            return ignore_missing
        except Exception as e:
            xbmc.log(f"[VideoCache] Erro ao verificar expiração: {str(e)}", xbmc.LOGERROR)
            return True
            
    def exists(self, url):
        """Verifica rápida se uma URL existe no cache"""
        cache_key = hashlib.md5(url.encode('utf-8')).hexdigest()
        return cache_key in self.cache_index        
    
    def _obfuscate_url(self, url):
        """Ofusca uma URL para armazenamento seguro"""
        if not url:
            return url
        return base64.b64encode(url[::-1].encode('utf-8')).decode('utf-8')

    def _deobfuscate_url(self, obfuscated_url):
        """Desofusca uma URL armazenada"""
        if not obfuscated_url:
            return obfuscated_url
        try:
            return base64.b64decode(obfuscated_url.encode('utf-8')).decode('utf-8')[::-1]
        except:
            return obfuscated_url

    def _obfuscate_item(self, item):
        """Ofusca campos sensíveis em um item"""
        if isinstance(item, dict):
            sensitive_fields = ['url', 'external_link', 'poster', 'backdrop', 'clearlogo']
            for field in sensitive_fields:
                if field in item:
                    if isinstance(item[field], str):
                        item[field] = self._obfuscate_url(item[field])
                    elif isinstance(item[field], list):
                        item[field] = [self._obfuscate_url(x) if isinstance(x, str) else x for x in item[field]]
            return item
        return item

    def _deobfuscate_item(self, item):
        """Desofusca campos sensíveis em um item"""
        if isinstance(item, dict):
            sensitive_fields = ['url', 'external_link', 'poster', 'backdrop', 'clearlogo']
            for field in sensitive_fields:
                if field in item:
                    if isinstance(item[field], str):
                        item[field] = self._deobfuscate_url(item[field])
                    elif isinstance(item[field], list):
                        item[field] = [self._deobfuscate_url(x) if isinstance(x, str) else x for x in item[field]]
            return item
        return item

    def _obfuscate_data(self, data):
        """Ofusca os dados completos"""
        try:
            if isinstance(data, list):
                data = [self._obfuscate_item(item) for item in data]
            elif isinstance(data, dict):
                data = self._obfuscate_item(data)
            
            json_str = json.dumps(data)
            reversed_str = json_str[::-1]
            return base64.b64encode(reversed_str.encode('utf-8')).decode('utf-8')
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao ofuscar dados: {str(e)}", xbmc.LOGERROR)
            return None

    def _deobfuscate_data(self, obfuscated_data):
        """Desofusca os dados completos"""
        try:
            decoded = base64.b64decode(obfuscated_data.encode('utf-8')).decode('utf-8')
            original_str = decoded[::-1]
            data = json.loads(original_str)
            
            if isinstance(data, list):
                return [self._deobfuscate_item(item) for item in data]
            elif isinstance(data, dict):
                return self._deobfuscate_item(data)
            return data
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao desofuscar dados: {str(e)}", xbmc.LOGERROR)
            return None
            
    def get_cache_size(self):
        """Retorna o tamanho total do cache"""
        total_size = 0
        for filename in os.listdir(CACHE_DIR):
            filepath = os.path.join(CACHE_DIR, filename)
            if os.path.isfile(filepath):
                total_size += os.path.getsize(filepath)
        return total_size
    
    def load_index(self):
        """Carrega o índice do cache com URLs ofuscadas"""
        index_file = os.path.join(CACHE_DIR, 'index.json')

        if not os.path.exists(index_file):
            self.cache_index = {}
            return

        try:
            with open(index_file, 'r', encoding='utf-8') as f:
                obfuscated_index = json.load(f)

            self.cache_index = {}

            def process_entry(item):
                key, entry = item
                try:
                    url = self._deobfuscate_url(entry.get('url', ''))
                    if url and 'expires' in entry:
                        entry['url'] = url
                        return key, entry
                except Exception as e:
                    xbmc.log(f"[VideoCache] Erro ao processar entrada {key}: {str(e)}", xbmc.LOGDEBUG)
                return None

            try:
                threads_str = ADDON.getSetting('threads_cache')
                threads = int(threads_str) if threads_str.isdigit() else 4
            except Exception:
                threads = 4

            with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as executor:
                results = list(executor.map(process_entry, obfuscated_index.items()))

            self.cache_index = {key: entry for result in results if result for key, entry in [result]}

            xbmc.log(f"[VideoCache] Índice carregado com {len(self.cache_index)} entradas usando {threads} threads", xbmc.LOGDEBUG)

        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao carregar índice: {str(e)}", xbmc.LOGERROR)
            self.cache_index = {}

    def save_index(self):
        """Salva o índice do cache"""
        index_file = os.path.join(CACHE_DIR, 'index.json')
        try:
            obfuscated_index = {}
            for key, entry in self.cache_index.items():
                obfuscated_entry = entry.copy()
                obfuscated_entry['url'] = self._obfuscate_url(entry.get('url', ''))
                obfuscated_index[key] = obfuscated_entry

            temp_file = index_file + '.tmp'
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(obfuscated_index, f, indent=2, ensure_ascii=False)
            
            if os.path.getsize(temp_file) > 0:
                if os.path.exists(index_file):
                    os.remove(index_file)
                os.rename(temp_file, index_file)
                xbmc.log("[VideoCache] Índice salvo com sucesso", xbmc.LOGDEBUG)
            else:
                xbmc.log("[VideoCache] AVISO: Índice vazio não foi salvo", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao salvar índice: {str(e)}", xbmc.LOGERROR)
    
    def get_cache_path(self, url):
        """Retorna o caminho do arquivo de cache"""
        return os.path.join(CACHE_DIR, hashlib.sha256(url.encode('utf-8')).hexdigest() + '.dat')
    
    def get(self, url, ignore_expiry=False):
        """Obtém dados do cache"""
        if not self.enabled:
            xbmc.log(f"[VideoCache] Cache DESATIVADO (ignorando): {url}", xbmc.LOGDEBUG)
            return None
        
        cache_key = hashlib.md5(url.encode('utf-8')).hexdigest()

        if cache_key not in self.cache_index:
            xbmc.log(f"[VideoCache] Cache MISS (não encontrado): {url}", xbmc.LOGDEBUG)
            return None
            
        try:
            if not ignore_expiry:
                expiry_time = datetime.fromisoformat(self.cache_index[cache_key]['expires'])
                if datetime.now() > expiry_time:
                    xbmc.log(f"[VideoCache] Cache EXPIRADO: {url}", xbmc.LOGDEBUG)
                    self.delete(url)
                    return None
            
            cache_file = self.get_cache_path(url)
            if not os.path.exists(cache_file):
                xbmc.log(f"[VideoCache] AVISO: Arquivo de cache não existe: {cache_file}", xbmc.LOGWARNING)
                return None
            
            with open(cache_file, 'r', encoding='utf-8') as f:
                obfuscated_data = f.read()
                data = self._deobfuscate_data(obfuscated_data)
                
                if not data or not isinstance(data, list):
                    xbmc.log(f"[VideoCache] AVISO: Dados inválidos em cache: {cache_file}", xbmc.LOGWARNING)
                    return None
                
                xbmc.log(f"[VideoCache] Cache HIT: {url} ({len(data)} itens)", xbmc.LOGINFO)
                return data
                
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao ler cache: {str(e)}", xbmc.LOGERROR)
            return None
    
    def set(self, url, data, expiry_hours=72):
        """Armazena dados no cache"""
        if not self.enabled:
            xbmc.log("[VideoCache] Cache DESATIVADO (não salvando)", xbmc.LOGDEBUG)
            return False

        if not data or not isinstance(data, list):
            xbmc.log("[VideoCache] AVISO: Tentativa de cachear dados inválidos", xbmc.LOGWARNING)
            return False
            
        cache_key = hashlib.md5(url.encode('utf-8')).hexdigest()
        cache_file = self.get_cache_path(url)
        
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
            
            obfuscated_data = self._obfuscate_data(data)
            if not obfuscated_data:
                return False
            
            temp_file = cache_file + '.tmp'
            with open(temp_file, 'w', encoding='utf-8') as f:
                f.write(obfuscated_data)
            
            if os.path.exists(temp_file) and os.path.getsize(temp_file) > 0:
                if os.path.exists(cache_file):
                    os.remove(cache_file)
                os.rename(temp_file, cache_file)
                
                self.cache_index[cache_key] = {
                    'url': url,
                    'expires': (datetime.now() + timedelta(hours=expiry_hours)).isoformat(),
                    'size': len(data)
                }
                self.save_index()
                
                xbmc.log(f"[VideoCache] Dados cacheados: {url} ({len(data)} itens, expira em {expiry_hours}h)", xbmc.LOGINFO)
                return True
            else:
                xbmc.log("[VideoCache] ERRO: Arquivo de cache não foi criado", xbmc.LOGERROR)
                return False
                
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao salvar cache: {str(e)}", xbmc.LOGERROR)
            if os.path.exists(temp_file):
                os.remove(temp_file)
            return False
    
    def delete(self, url):
        """Remove um item do cache"""
        cache_key = hashlib.md5(url.encode('utf-8')).hexdigest()
        try:
            cache_file = self.get_cache_path(url)
            if os.path.exists(cache_file):
                os.remove(cache_file)
            if cache_key in self.cache_index:
                del self.cache_index[cache_key]
            self.save_index()
            xbmc.log(f"[VideoCache] Cache removido: {url}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao remover cache: {str(e)}", xbmc.LOGERROR)
    
    def clear(self):
        """Limpa completamente o cache"""
        try:
            for filename in os.listdir(CACHE_DIR):
                file_path = os.path.join(CACHE_DIR, filename)
                try:
                    if os.path.isfile(file_path):
                        os.unlink(file_path)
                except Exception as e:
                    xbmc.log(f"[VideoCache] ERRO ao remover {file_path}: {str(e)}", xbmc.LOGERROR)
            
            self.cache_index = {}
            self.save_index()
            xbmc.log("[VideoCache] Cache completamente limpo", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[VideoCache] ERRO ao limpar cache: {str(e)}", xbmc.LOGERROR)
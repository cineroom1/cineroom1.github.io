# video_listing.py

import json
import xbmcgui
import xbmcplugin
import sys
import xbmc
import time
import json
import xbmc
import urllib.parse
import urllib.request
import hashlib

from urllib.parse import urlencode, parse_qsl
from resources.action.favorites import load_favorites
from resources.lib.utils import get_all_videos, VIDEO_CACHE, FILTERED_CACHE
from resources.lib.utils_view import set_view_mode

# No final da função, depois de xbmcplugin.endOfDirectory(HANDLE)




HANDLE = int(sys.argv[1])
URL = sys.argv[0]

def get_url(**kwargs) -> str:
    """
    Cria uma URL para chamar o plugin recursivamente.
    Otimizado para serialização automática de objetos.
    """
    params = {}
    for key, value in kwargs.items():
        if isinstance(value, (dict, list)):
            params[key] = json.dumps(value)
        else:
            params[key] = value
    return f"{URL}?{urlencode(params)}"


MEDIA_TYPES = {
    'movie': {'content_type': 'movies', 'playable': True, 'folder': False},
    'tvshow': {'content_type': 'tvshows', 'playable': False, 'folder': True},
    'set': {'content_type': 'movies', 'playable': False, 'folder': True}
}

def load_videos(external_link):
    """Carrega os vídeos a partir de uma URL externa."""
    try:
        with urllib.request.urlopen(external_link) as response:
            return json.load(response)
    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Erro ao carregar vídeos: {e}')
        return None

def check_maintenance(data):
    """Verifica se a lista está em manutenção."""
    if isinstance(data[0], dict) and data[0].get("status", "").lower() == "off":
        xbmcgui.Dialog().notification("Aguarde...", "A lista está em manutenção!", xbmcgui.NOTIFICATION_WARNING, 3000)
        return True
    return False

def set_content_type(videos):
    """Define o tipo de conteúdo com base nos vídeos."""
    types = {video['type'] for video in videos}
    if types == {'movie'}:
        xbmcplugin.setContent(HANDLE, 'movies')
    elif types == {'tvshow'}:
        xbmcplugin.setContent(HANDLE, 'tvshows')
    elif types == {'set'}:
        xbmcplugin.setContent(HANDLE, 'movies')
    else:
        xbmcplugin.setContent(HANDLE, 'movies')


def create_video_item(video):
    """Cria um ListItem para exibir na interface do Kodi."""
    try:
        list_item = xbmcgui.ListItem(label=video['title'])
        list_item.setArt({
            'poster': video.get('poster', ''),
            'thumb': video.get('poster', ''),
            'fanart': video.get('backdrop', ''),
            'clearlogo': video.get('clearlogo', '')
        })

        mediatype = video['type']
        media_info = MEDIA_TYPES.get(mediatype, {})
        is_folder = media_info.get('folder', False)

        list_item.setProperty('IsPlayable', 'true' if media_info.get('playable', False) else 'false')

        if mediatype == 'movie':
            urls = video.get('url', [])
            if isinstance(urls, str):
                urls = [urls]
            url = get_url(action='play', video=','.join(urls), tmdb_id=video.get('tmdb_id', ''), title=video.get('title', ''), movie_poster=video.get('poster', ''), movie_synopsis=video.get('synopsis', ''))
        elif mediatype == 'set':
            url = get_url(action='list_collection', collection=json.dumps(video))
        elif mediatype == 'tvshow':
            url = get_url(action='list_seasons', serie=video)
        else:
            url = ''

        info_tag = list_item.getVideoInfoTag()

        # Setters diretos no InfoTagVideo (os que funcionam)
        info_tag.setTitle(video['title'])
        try:
            rating = float(video.get('rating', 0))  # rating pode ser float
        except (ValueError, TypeError):
            rating = 0
        info_tag.setRating(rating)

        try:
            year = int(video.get('year', 0))
        except (ValueError, TypeError):
            year = 0
        info_tag.setYear(year)
        info_tag.setGenres(video.get('genres', []))
        info_tag.setPremiered(video.get("premiered", "Ano não disponível"))
        info_tag.setPlot(video.get('synopsis', ''))
        info_tag.setDateAdded(video.get('date_added', ''))
        info_tag.setMediaType(mediatype) # Este geralmente funciona no InfoTagVideo

        # --- Tratamento de 'director' ---
        raw_director_data = video.get("director")
        directors_for_infotag = []
        if isinstance(raw_director_data, list):
            directors_for_infotag = [str(d).strip() for d in raw_director_data if d is not None and str(d).strip()]
        elif isinstance(raw_director_data, str) and raw_director_data.strip():
            directors_for_infotag = [raw_director_data.strip()]
        else:
            directors_for_infotag = ["Desconhecido"]
        info_tag.setDirectors(directors_for_infotag)
        # --- Fim do tratamento de 'director' ---


        # --- Tratamento de 'studio' e 'runtime' para setInfo (que não têm setters diretos no InfoTagVideo) ---
        studio_data = video.get('studio', [])
        joined_studio = ''
        if isinstance(studio_data, list):
            joined_studio = ', '.join([str(s).strip() for s in studio_data if s is not None and str(s).strip()])
        elif isinstance(studio_data, str):
            joined_studio = studio_data.strip()
        
        list_item.setInfo('video', {
            'studio': joined_studio,           # 'studio' de volta para setInfo
            'duration': video.get("runtime", 0), # 'runtime' de volta para setInfo (com a chave 'duration')
            # Outras propriedades que você tinha aqui originalmente e que não estão no InfoTagVideo
        })
        # --- Fim do tratamento de 'studio' e 'runtime' ---

        list_item.setProperty('mediatype', mediatype) # Mantenha esta propriedade para skins

        favorites = load_favorites()
        if any(fav['title'] == video['title'] for fav in favorites):
            list_item.addContextMenuItems([('Remover da sua lista', f'RunPlugin({get_url(action="remove_from_favorites", video=json.dumps(video))})')])
        else:
            list_item.addContextMenuItems([('Adicionar a sua lista', f'RunPlugin({get_url(action="add_to_favorites", video=json.dumps(video))})')])
        
        xbmc.log(f"DEBUG: create_video_item - Valor final de is_folder antes do retorno: {is_folder} (Tipo: {type(is_folder)})", xbmc.LOGDEBUG)
        return list_item, url, is_folder

    except Exception as e:
        xbmc.log(f"Erro ao criar item de vídeo: {e}", xbmc.LOGERROR)
        return None, None, False


def list_videos(external_link, sort_method=None, page=1, items_per_page=100):
    """Lista os vídeos com cache otimizado e tratamento de erros robusto"""
    progress = xbmcgui.DialogProgressBG()
    progress.create('Carregando vídeos', 'Otimizando...')
    
    try:
        # 1. Configuração inicial segura
        try:
            page = max(1, int(page))
            items_per_page = max(10, min(int(items_per_page), 200))
        except (ValueError, TypeError):
            page = 1
            items_per_page = 100

        # 2. Função auxiliar para verificar memória
        def get_system_memory():
            mem_str = xbmc.getInfoLabel('System.Memory(total)')
            if 'MB' in mem_str:
                return int(mem_str.replace('MB', '').strip())
            elif 'GB' in mem_str:
                return int(float(mem_str.replace('GB', '').strip()) * 1024)
            return 1024  # Default seguro para 1GB se não puder detectar

        # 3. Cache inteligente com verificação de memória segura
        cache_key = f"v4_{hashlib.md5(external_link.encode()).hexdigest()}_{sort_method or 'none'}"
        videos = []
        ram_cache_active = False
        
        # Verifica se há memória suficiente para cache RAM (>1GB)
        if get_system_memory() > 1024:  # Mais de 1GB
            ram_cache_active = True
            if hasattr(list_videos, '_ram_cache'):
                cached = list_videos._ram_cache.get(cache_key)
                if cached and time.time() - cached['time'] < 300:  # 5 minutos
                    videos = cached['data']
                    progress.update(30, 'Dados da RAM')

        # Cache em disco se RAM não disponível ou vazio
        if not videos and VIDEO_CACHE.enabled:
            progress.update(20, 'Verificando cache...')
            try:
                cached = VIDEO_CACHE.get(cache_key)
                if cached:
                    videos = json.loads(cached)
                    # Atualiza cache RAM se disponível
                    if ram_cache_active:
                        if not hasattr(list_videos, '_ram_cache'):
                            list_videos._ram_cache = {}
                        list_videos._ram_cache[cache_key] = {
                            'data': videos,
                            'time': time.time()
                        }
            except Exception as e:
                xbmc.log(f"[CACHE] Limpando cache corrompido: {str(e)}", xbmc.LOGWARNING)
                VIDEO_CACHE.delete(cache_key)

        # 4. Carregamento dos dados se cache vazio
        if not videos:
            progress.update(40, 'Carregando dados...')
            videos = load_videos(external_link)
            
            if videos:
                if VIDEO_CACHE.enabled:
                    progress.update(60, 'Armazenando cache...')
                    try:
                        VIDEO_CACHE.set(cache_key, json.dumps(videos), expiry_hours=12)
                    except Exception as e:
                        xbmc.log(f"[ERRO] Cache não salvo: {str(e)}", xbmc.LOGERROR)
                
                if ram_cache_active:
                    if not hasattr(list_videos, '_ram_cache'):
                        list_videos._ram_cache = {}
                    list_videos._ram_cache[cache_key] = {
                        'data': videos,
                        'time': time.time()
                    }

        # 5. Verificações de conteúdo
        if not videos:
            progress.close()
            xbmcgui.Dialog().ok('Erro', 'Nenhum vídeo encontrado')
            return

        if check_maintenance(videos):
            progress.close()
            return

        # 6. Processamento otimizado dos vídeos
        progress.update(70, 'Processando...')
        video_items = videos[1:] if isinstance(videos[0], dict) and "status" in videos[0] else videos
        set_content_type(video_items)

        # 7. Ordenação segura
        sort_options = {
            'year': lambda x: int(x.get('year', 0)),
            'rating': lambda x: float(x.get('rating', 0)),
            'label': lambda x: str(x.get('title', '')).lower(),
            'genre': lambda x: ', '.join(str(g) for g in x.get('genres', [])).lower()
        }
        
        if sort_method in sort_options:
            try:
                video_items.sort(key=sort_options[sort_method], 
                               reverse=sort_method in ['year', 'rating'])
            except Exception as e:
                xbmc.log(f"[ERRO] Ordenação falhou: {str(e)}", xbmc.LOGWARNING)

        # 8. Paginação e exibição
        total_items = len(video_items)
        start_index = (page - 1) * items_per_page
        end_index = start_index + items_per_page
        
        progress.update(80, 'Preparando exibição...')
        added_items = 0
        
        for i in range(start_index, min(end_index, total_items)):
            video = video_items[i]
            
            # Atualização de progresso otimizada
            if i % 5 == 0 or i == end_index - 1:
                progress.update(80 + int((i-start_index)/items_per_page*20), 
                              f'Item {i+1}/{total_items}')
            
            if not isinstance(video, dict):
                continue
                
            try:
                list_item, url, is_folder = create_video_item(video)
                if list_item and url:
                    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)
                    added_items += 1
            except Exception as e:
                xbmc.log(f"[ERRO] Item inválido: {str(e)}", xbmc.LOGDEBUG)

        # 9. Próxima página se aplicável
        if end_index < total_items and added_items > 0:
            next_page_item = xbmcgui.ListItem(label='Próxima Página >>')
            next_page_url = get_url(
                action='list_videos',
                external_link=external_link,
                sort_method=sort_method,
                page=page + 1,
                items_per_page=items_per_page
            )
            xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE)
        set_view_mode()

    except Exception as e:
        xbmc.log(f"[ERRO CRÍTICO] list_videos: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Erro', 'Verifique os logs', xbmcgui.NOTIFICATION_ERROR)
    finally:
        progress.close()


def list_collection(collection_data):
    """Lista os filmes de uma coleção, com estrutura semelhante à de temporadas de séries."""

    try:
        # 1. Desserialização segura
        if isinstance(collection_data, str):
            collection = json.loads(collection_data)
        else:
            collection = collection_data

        # 2. Validação básica
        if not isinstance(collection, dict) or not collection.get('movies'):
            raise ValueError("Dados da coleção inválidos ou 'movies' ausentes.")

        # 3. Nome da coleção para exibição e organização
        collection_title = collection.get('title', 'Coleção')
        xbmcplugin.setPluginCategory(HANDLE, collection_title)
        xbmcplugin.setContent(HANDLE, 'movies')

        # 4. Itera pelos filmes da coleção
        for movie in collection.get('movies', []):
            movie['type'] = 'movie'  # Força o tipo correto
            list_item, url, is_folder = create_video_item(movie)
            if list_item and url:
                xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=is_folder)

        # 5. Finaliza a listagem
        xbmcplugin.endOfDirectory(HANDLE)

    except Exception as e:
        xbmc.log(f"[CINEROOM] Erro ao listar coleção: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Erro', 'Não foi possível exibir a coleção.', xbmcgui.NOTIFICATION_ERROR, 3000)



def list_seasons(serie_data):
    """Lista temporadas com desempenho máximo para grandes catálogos"""
    try:
        # 1. Desserialização Rápida
        if isinstance(serie_data, str):
            serie = json.loads(serie_data)
        else:
            serie = serie_data

        # 2. Validação Rápida
        if not isinstance(serie, dict) or not serie.get('temporadas'):
            raise ValueError("Dados da série inválidos ou 'temporadas' ausentes.")

        # 3. Codificação do título da série para uso interno
        serie_title = serie.get('title', '')
        encoded_title = urllib.parse.quote(serie_title)

        # 4. Usando o título original para exibição no Kodi (sem codificação)
        title_for_display = serie.get('title', '')

        # 5. Configurações Iniciais
        xbmcplugin.setPluginCategory(HANDLE, title_for_display)
        xbmcplugin.setContent(HANDLE, 'seasons')
        
        # 6. Cache de Artes
        poster = serie.get('poster', '')
        fanart = serie.get('backdrop', '')

        # 7. Processamento Acelerado
        for temp in serie['temporadas']:
            if not temp.get('title'):
                continue

            # Verifica disponibilidade
            episodios_url = temp.get('episodios_link', '')
            episodios_inline = temp.get('episodios', [])
            is_disponivel = bool(episodios_url or episodios_inline)

            # Ajuste do título
            title = temp['title']
            if not is_disponivel:
                title += ' (Offline)'

            # Criação mínima do item
            li = xbmcgui.ListItem(label=title)

            # Arte essencial apenas
            li.setArt({
                'poster': temp.get('poster', poster),
                'fanart': fanart
            })
            li.setInfo('video', {
                'title': title,
                'plot': temp.get('synopsis', ''),
                'rating': temp.get('rating', 0),
                'premiered': temp.get('air_date', ''),
                'mediatype': 'seasons'
            })

            # Passando a URL de episódios ou dados inline
            if episodios_url or episodios_inline:
                url = get_url(
                    action='list_episodes',
                    serie=json.dumps({
                        'title': encoded_title,
                        'episodios_url': episodios_url,  # Passa a URL diretamente
                        'episodios_inline': episodios_inline,
                        'poster': temp.get('poster', poster)
                    }),
                    season_title=temp['title']
                )
                xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE)
        return True

    except Exception as e:
        xbmc.log(f"Erro list_seasons: {str(e)}", xbmc.LOGERROR)
        return False

def list_episodes(season_data, season_title):
    """Lista episódios com suporte a duração (runtime)"""
    try:
        # 1. Desserialização Rápida
        if isinstance(season_data, str):
            season = json.loads(season_data)
        else:
            season = season_data

        # 2. Verificação Rápida
        episodios_url = season.get('episodios_url', '')
        episodios_inline = season.get('episodios_inline', [])
        if not episodios_url and not episodios_inline:
            xbmc.log(f"Erro ao processar temporada: {season_title}. Dados incorretos ou ausentes.", xbmc.LOGERROR)
            return False

        # 3. Carregar dados dos episódios
        episodios_data = []
        if episodios_url:
            try:
                with urllib.request.urlopen(episodios_url) as response:
                    episodios_data = json.loads(response.read().decode()).get('episodios', [])
            except Exception as e:
                xbmc.log(f"Erro ao carregar dados dos episódios para a temporada {season_title}: {str(e)}", xbmc.LOGERROR)
        elif episodios_inline:
            episodios_data = episodios_inline

        # 4. Configuração Básica
        xbmcplugin.setPluginCategory(HANDLE, season_title)
        xbmcplugin.setContent(HANDLE, 'episodes')

        # 5. Cache de Arte
        poster = season.get('poster', '')

        # 6. Processamento Direto
        for ep in episodios_data:
            if not ep or not ep.get('url'):
                continue

            # Criação do ListItem
            li = xbmcgui.ListItem(label=ep.get('title', ''))
            
            # Preparação das informações
            info = {
                'title': ep.get('title', ''),
                'plot': ep.get('synopsis', ''),
                'mediatype': 'episode'
            }

            # Adiciona campos condicionais
            if ep.get('air_date'):
                info['date'] = ep['air_date']
            if ep.get('rating'):
                info['rating'] = float(ep['rating'])
            if ep.get('runtime'):
                info['duration'] = int(ep['runtime']) * 60  # Converte minutos para segundos
            if ep.get('aired'):
                info['premiered'] = ep['aired']
            else:
                info['premiered'] = "Ano não disponível"

            li.setInfo('video', info)

            # Configuração de arte
            art = {}
            if 'poster' in ep:
                art['thumb'] = ep['poster']
            elif poster:
                art['thumb'] = poster
            li.setArt(art)

            # Configuração de propriedades
            li.setProperty('IsPlayable', 'true')
            li.setProperty('mediatype', 'episode')

            # Preparação da URL
            url = ep['url']
            if isinstance(url, str):
                url = [url]
            elif not isinstance(url, list):
                xbmc.log(f"Formato de URL inválido para: {ep.get('title', 'Desconhecido')}", xbmc.LOGERROR)
                continue

            # Adiciona o item à lista
            xbmcplugin.addDirectoryItem(
                HANDLE,
                get_url(action='play', video=json.dumps(url)),
                li,
                isFolder=False
            )

        xbmcplugin.endOfDirectory(HANDLE)
        return True

    except Exception as e:
        xbmc.log(f"Erro em list_episodes: {str(e)}", xbmc.LOGERROR)
        return False


